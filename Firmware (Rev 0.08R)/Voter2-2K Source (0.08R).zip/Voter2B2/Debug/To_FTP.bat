ren Voter2B2.srec Voter2B2-0.07R.srec
del C:\OpenTFTPServer\Voter2B2-0.07R.srec
move Voter2B2-0.07R.srec C:\OpenTFTPServer