################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/AnalogIO.c \
../Core/Src/Backup.c \
../Core/Src/Bootloader.c \
../Core/Src/Bootloader2.c \
../Core/Src/Codecs.c \
../Core/Src/ConsoleTask.c \
../Core/Src/DialSettings.c \
../Core/Src/DialTaskIn.c \
../Core/Src/DialTaskOut.c \
../Core/Src/EthernetTask.c \
../Core/Src/GPS.c \
../Core/Src/Gpio.c \
../Core/Src/Histograms.c \
../Core/Src/I2C.c \
../Core/Src/ITCMSetup.c \
../Core/Src/KSZ8081.c \
../Core/Src/MainTask.c \
../Core/Src/MtrSpi.c \
../Core/Src/Ping.c \
../Core/Src/QSPINORSetup.c \
../Core/Src/RSSIFilter.c \
../Core/Src/RTC.c \
../Core/Src/Rx_DSP.c \
../Core/Src/SPINOR.c \
../Core/Src/Ser2NetTask.c \
../Core/Src/SetShow.c \
../Core/Src/Settings.c \
../Core/Src/Status.c \
../Core/Src/TTones.c \
../Core/Src/Tftp.c \
../Core/Src/Timers.c \
../Core/Src/Tx_DSP.c \
../Core/Src/UartIO.c \
../Core/Src/Update.c \
../Core/Src/Utils.c \
../Core/Src/Vcxo.c \
../Core/Src/VoiceFilter.c \
../Core/Src/freertos.c \
../Core/Src/logger2rt.c \
../Core/Src/main.c \
../Core/Src/stm32h7xx_hal_msp.c \
../Core/Src/stm32h7xx_hal_timebase_tim.c \
../Core/Src/stm32h7xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32h7xx.c \
../Core/Src/xuart.c 

OBJS += \
./Core/Src/AnalogIO.o \
./Core/Src/Backup.o \
./Core/Src/Bootloader.o \
./Core/Src/Bootloader2.o \
./Core/Src/Codecs.o \
./Core/Src/ConsoleTask.o \
./Core/Src/DialSettings.o \
./Core/Src/DialTaskIn.o \
./Core/Src/DialTaskOut.o \
./Core/Src/EthernetTask.o \
./Core/Src/GPS.o \
./Core/Src/Gpio.o \
./Core/Src/Histograms.o \
./Core/Src/I2C.o \
./Core/Src/ITCMSetup.o \
./Core/Src/KSZ8081.o \
./Core/Src/MainTask.o \
./Core/Src/MtrSpi.o \
./Core/Src/Ping.o \
./Core/Src/QSPINORSetup.o \
./Core/Src/RSSIFilter.o \
./Core/Src/RTC.o \
./Core/Src/Rx_DSP.o \
./Core/Src/SPINOR.o \
./Core/Src/Ser2NetTask.o \
./Core/Src/SetShow.o \
./Core/Src/Settings.o \
./Core/Src/Status.o \
./Core/Src/TTones.o \
./Core/Src/Tftp.o \
./Core/Src/Timers.o \
./Core/Src/Tx_DSP.o \
./Core/Src/UartIO.o \
./Core/Src/Update.o \
./Core/Src/Utils.o \
./Core/Src/Vcxo.o \
./Core/Src/VoiceFilter.o \
./Core/Src/freertos.o \
./Core/Src/logger2rt.o \
./Core/Src/main.o \
./Core/Src/stm32h7xx_hal_msp.o \
./Core/Src/stm32h7xx_hal_timebase_tim.o \
./Core/Src/stm32h7xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32h7xx.o \
./Core/Src/xuart.o 

C_DEPS += \
./Core/Src/AnalogIO.d \
./Core/Src/Backup.d \
./Core/Src/Bootloader.d \
./Core/Src/Bootloader2.d \
./Core/Src/Codecs.d \
./Core/Src/ConsoleTask.d \
./Core/Src/DialSettings.d \
./Core/Src/DialTaskIn.d \
./Core/Src/DialTaskOut.d \
./Core/Src/EthernetTask.d \
./Core/Src/GPS.d \
./Core/Src/Gpio.d \
./Core/Src/Histograms.d \
./Core/Src/I2C.d \
./Core/Src/ITCMSetup.d \
./Core/Src/KSZ8081.d \
./Core/Src/MainTask.d \
./Core/Src/MtrSpi.d \
./Core/Src/Ping.d \
./Core/Src/QSPINORSetup.d \
./Core/Src/RSSIFilter.d \
./Core/Src/RTC.d \
./Core/Src/Rx_DSP.d \
./Core/Src/SPINOR.d \
./Core/Src/Ser2NetTask.d \
./Core/Src/SetShow.d \
./Core/Src/Settings.d \
./Core/Src/Status.d \
./Core/Src/TTones.d \
./Core/Src/Tftp.d \
./Core/Src/Timers.d \
./Core/Src/Tx_DSP.d \
./Core/Src/UartIO.d \
./Core/Src/Update.d \
./Core/Src/Utils.d \
./Core/Src/Vcxo.d \
./Core/Src/VoiceFilter.d \
./Core/Src/freertos.d \
./Core/Src/logger2rt.d \
./Core/Src/main.d \
./Core/Src/stm32h7xx_hal_msp.d \
./Core/Src/stm32h7xx_hal_timebase_tim.d \
./Core/Src/stm32h7xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32h7xx.d \
./Core/Src/xuart.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m7 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32H750xx -DUSE_PWR_LDO_SUPPLY -c -I../Core/Inc -I../Drivers/STM32H7xx_HAL_Driver/Inc -I../Drivers/STM32H7xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32H7xx/Include -I../Drivers/CMSIS/Include -I../LWIP/App -I../LWIP/Target -I../Middlewares/Third_Party/LwIP/src/include -I../Middlewares/Third_Party/LwIP/system -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I../Middlewares/Third_Party/LwIP/src/include/netif/ppp -I../Middlewares/Third_Party/LwIP/src/include/lwip -I../Middlewares/Third_Party/LwIP/src/include/lwip/apps -I../Middlewares/Third_Party/LwIP/src/include/lwip/priv -I../Middlewares/Third_Party/LwIP/src/include/lwip/prot -I../Middlewares/Third_Party/LwIP/src/include/netif -I../Middlewares/Third_Party/LwIP/src/include/compat/posix -I../Middlewares/Third_Party/LwIP/src/include/compat/posix/arpa -I../Middlewares/Third_Party/LwIP/src/include/compat/posix/net -I../Middlewares/Third_Party/LwIP/src/include/compat/posix/sys -I../Middlewares/Third_Party/LwIP/src/include/compat/stdc -I../Middlewares/Third_Party/LwIP/system/arch -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -o "$@"
Core/Src/Bootloader.o: ../Core/Src/Bootloader.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m7 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32H750xx -DUSE_PWR_LDO_SUPPLY -c -I../Core/Inc -I../Drivers/STM32H7xx_HAL_Driver/Inc -I../Drivers/STM32H7xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32H7xx/Include -I../Drivers/CMSIS/Include -I../LWIP/App -I../LWIP/Target -I../Middlewares/Third_Party/LwIP/src/include -I../Middlewares/Third_Party/LwIP/system -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I../Middlewares/Third_Party/LwIP/src/include/netif/ppp -I../Middlewares/Third_Party/LwIP/src/include/lwip -I../Middlewares/Third_Party/LwIP/src/include/lwip/apps -I../Middlewares/Third_Party/LwIP/src/include/lwip/priv -I../Middlewares/Third_Party/LwIP/src/include/lwip/prot -I../Middlewares/Third_Party/LwIP/src/include/netif -I../Middlewares/Third_Party/LwIP/src/include/compat/posix -I../Middlewares/Third_Party/LwIP/src/include/compat/posix/arpa -I../Middlewares/Third_Party/LwIP/src/include/compat/posix/net -I../Middlewares/Third_Party/LwIP/src/include/compat/posix/sys -I../Middlewares/Third_Party/LwIP/src/include/compat/stdc -I../Middlewares/Third_Party/LwIP/system/arch -Og -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/AnalogIO.cyclo ./Core/Src/AnalogIO.d ./Core/Src/AnalogIO.o ./Core/Src/AnalogIO.su ./Core/Src/Backup.cyclo ./Core/Src/Backup.d ./Core/Src/Backup.o ./Core/Src/Backup.su ./Core/Src/Bootloader.cyclo ./Core/Src/Bootloader.d ./Core/Src/Bootloader.o ./Core/Src/Bootloader.su ./Core/Src/Bootloader2.cyclo ./Core/Src/Bootloader2.d ./Core/Src/Bootloader2.o ./Core/Src/Bootloader2.su ./Core/Src/Codecs.cyclo ./Core/Src/Codecs.d ./Core/Src/Codecs.o ./Core/Src/Codecs.su ./Core/Src/ConsoleTask.cyclo ./Core/Src/ConsoleTask.d ./Core/Src/ConsoleTask.o ./Core/Src/ConsoleTask.su ./Core/Src/DialSettings.cyclo ./Core/Src/DialSettings.d ./Core/Src/DialSettings.o ./Core/Src/DialSettings.su ./Core/Src/DialTaskIn.cyclo ./Core/Src/DialTaskIn.d ./Core/Src/DialTaskIn.o ./Core/Src/DialTaskIn.su ./Core/Src/DialTaskOut.cyclo ./Core/Src/DialTaskOut.d ./Core/Src/DialTaskOut.o ./Core/Src/DialTaskOut.su ./Core/Src/EthernetTask.cyclo ./Core/Src/EthernetTask.d ./Core/Src/EthernetTask.o ./Core/Src/EthernetTask.su ./Core/Src/GPS.cyclo ./Core/Src/GPS.d ./Core/Src/GPS.o ./Core/Src/GPS.su ./Core/Src/Gpio.cyclo ./Core/Src/Gpio.d ./Core/Src/Gpio.o ./Core/Src/Gpio.su ./Core/Src/Histograms.cyclo ./Core/Src/Histograms.d ./Core/Src/Histograms.o ./Core/Src/Histograms.su ./Core/Src/I2C.cyclo ./Core/Src/I2C.d ./Core/Src/I2C.o ./Core/Src/I2C.su ./Core/Src/ITCMSetup.cyclo ./Core/Src/ITCMSetup.d ./Core/Src/ITCMSetup.o ./Core/Src/ITCMSetup.su ./Core/Src/KSZ8081.cyclo ./Core/Src/KSZ8081.d ./Core/Src/KSZ8081.o ./Core/Src/KSZ8081.su ./Core/Src/MainTask.cyclo ./Core/Src/MainTask.d ./Core/Src/MainTask.o ./Core/Src/MainTask.su ./Core/Src/MtrSpi.cyclo ./Core/Src/MtrSpi.d ./Core/Src/MtrSpi.o ./Core/Src/MtrSpi.su ./Core/Src/Ping.cyclo ./Core/Src/Ping.d ./Core/Src/Ping.o ./Core/Src/Ping.su ./Core/Src/QSPINORSetup.cyclo ./Core/Src/QSPINORSetup.d ./Core/Src/QSPINORSetup.o ./Core/Src/QSPINORSetup.su ./Core/Src/RSSIFilter.cyclo ./Core/Src/RSSIFilter.d ./Core/Src/RSSIFilter.o ./Core/Src/RSSIFilter.su ./Core/Src/RTC.cyclo ./Core/Src/RTC.d ./Core/Src/RTC.o ./Core/Src/RTC.su ./Core/Src/Rx_DSP.cyclo ./Core/Src/Rx_DSP.d ./Core/Src/Rx_DSP.o ./Core/Src/Rx_DSP.su ./Core/Src/SPINOR.cyclo ./Core/Src/SPINOR.d ./Core/Src/SPINOR.o ./Core/Src/SPINOR.su ./Core/Src/Ser2NetTask.cyclo ./Core/Src/Ser2NetTask.d ./Core/Src/Ser2NetTask.o ./Core/Src/Ser2NetTask.su ./Core/Src/SetShow.cyclo ./Core/Src/SetShow.d ./Core/Src/SetShow.o ./Core/Src/SetShow.su ./Core/Src/Settings.cyclo ./Core/Src/Settings.d ./Core/Src/Settings.o ./Core/Src/Settings.su ./Core/Src/Status.cyclo ./Core/Src/Status.d ./Core/Src/Status.o ./Core/Src/Status.su ./Core/Src/TTones.cyclo ./Core/Src/TTones.d ./Core/Src/TTones.o ./Core/Src/TTones.su ./Core/Src/Tftp.cyclo ./Core/Src/Tftp.d ./Core/Src/Tftp.o ./Core/Src/Tftp.su ./Core/Src/Timers.cyclo ./Core/Src/Timers.d ./Core/Src/Timers.o ./Core/Src/Timers.su ./Core/Src/Tx_DSP.cyclo ./Core/Src/Tx_DSP.d ./Core/Src/Tx_DSP.o ./Core/Src/Tx_DSP.su ./Core/Src/UartIO.cyclo ./Core/Src/UartIO.d ./Core/Src/UartIO.o ./Core/Src/UartIO.su ./Core/Src/Update.cyclo ./Core/Src/Update.d ./Core/Src/Update.o ./Core/Src/Update.su ./Core/Src/Utils.cyclo ./Core/Src/Utils.d ./Core/Src/Utils.o ./Core/Src/Utils.su ./Core/Src/Vcxo.cyclo ./Core/Src/Vcxo.d ./Core/Src/Vcxo.o ./Core/Src/Vcxo.su ./Core/Src/VoiceFilter.cyclo ./Core/Src/VoiceFilter.d ./Core/Src/VoiceFilter.o ./Core/Src/VoiceFilter.su ./Core/Src/freertos.cyclo ./Core/Src/freertos.d ./Core/Src/freertos.o ./Core/Src/freertos.su ./Core/Src/logger2rt.cyclo ./Core/Src/logger2rt.d ./Core/Src/logger2rt.o ./Core/Src/logger2rt.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/stm32h7xx_hal_msp.cyclo ./Core/Src/stm32h7xx_hal_msp.d ./Core/Src/stm32h7xx_hal_msp.o ./Core/Src/stm32h7xx_hal_msp.su ./Core/Src/stm32h7xx_hal_timebase_tim.cyclo ./Core/Src/stm32h7xx_hal_timebase_tim.d ./Core/Src/stm32h7xx_hal_timebase_tim.o ./Core/Src/stm32h7xx_hal_timebase_tim.su ./Core/Src/stm32h7xx_it.cyclo ./Core/Src/stm32h7xx_it.d ./Core/Src/stm32h7xx_it.o ./Core/Src/stm32h7xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32h7xx.cyclo ./Core/Src/system_stm32h7xx.d ./Core/Src/system_stm32h7xx.o ./Core/Src/system_stm32h7xx.su ./Core/Src/xuart.cyclo ./Core/Src/xuart.d ./Core/Src/xuart.o ./Core/Src/xuart.su

.PHONY: clean-Core-2f-Src

