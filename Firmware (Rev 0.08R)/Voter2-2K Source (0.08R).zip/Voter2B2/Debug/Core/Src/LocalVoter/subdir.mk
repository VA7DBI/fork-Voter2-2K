################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/LocalVoter/LocalMode.c \
../Core/Src/LocalVoter/LocalSettings.c 

OBJS += \
./Core/Src/LocalVoter/LocalMode.o \
./Core/Src/LocalVoter/LocalSettings.o 

C_DEPS += \
./Core/Src/LocalVoter/LocalMode.d \
./Core/Src/LocalVoter/LocalSettings.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/LocalVoter/%.o Core/Src/LocalVoter/%.su Core/Src/LocalVoter/%.cyclo: ../Core/Src/LocalVoter/%.c Core/Src/LocalVoter/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m7 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32H750xx -DUSE_PWR_LDO_SUPPLY -c -I../Core/Inc -I../Drivers/STM32H7xx_HAL_Driver/Inc -I../Drivers/STM32H7xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32H7xx/Include -I../Drivers/CMSIS/Include -I../LWIP/App -I../LWIP/Target -I../Middlewares/Third_Party/LwIP/src/include -I../Middlewares/Third_Party/LwIP/system -I../Middlewares/Third_Party/FreeRTOS/Source/include -I../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS -I../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F -I../Middlewares/Third_Party/LwIP/src/include/netif/ppp -I../Middlewares/Third_Party/LwIP/src/include/lwip -I../Middlewares/Third_Party/LwIP/src/include/lwip/apps -I../Middlewares/Third_Party/LwIP/src/include/lwip/priv -I../Middlewares/Third_Party/LwIP/src/include/lwip/prot -I../Middlewares/Third_Party/LwIP/src/include/netif -I../Middlewares/Third_Party/LwIP/src/include/compat/posix -I../Middlewares/Third_Party/LwIP/src/include/compat/posix/arpa -I../Middlewares/Third_Party/LwIP/src/include/compat/posix/net -I../Middlewares/Third_Party/LwIP/src/include/compat/posix/sys -I../Middlewares/Third_Party/LwIP/src/include/compat/stdc -I../Middlewares/Third_Party/LwIP/system/arch -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv5-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src-2f-LocalVoter

clean-Core-2f-Src-2f-LocalVoter:
	-$(RM) ./Core/Src/LocalVoter/LocalMode.cyclo ./Core/Src/LocalVoter/LocalMode.d ./Core/Src/LocalVoter/LocalMode.o ./Core/Src/LocalVoter/LocalMode.su ./Core/Src/LocalVoter/LocalSettings.cyclo ./Core/Src/LocalVoter/LocalSettings.d ./Core/Src/LocalVoter/LocalSettings.o ./Core/Src/LocalVoter/LocalSettings.su

.PHONY: clean-Core-2f-Src-2f-LocalVoter

