#ifndef INC_MTRSPI_H_
#define INC_MTRSPI_H_

extern char* cmd_mtrspi_cmd   ;
extern char* cmd_mtrspi_cmdsc ;
extern char* cmd_mtrspi_help  ;

extern int  Cmd_mtrspi(int, char**) ;
extern void My_MtrSpi_FinishInit(void) ;
extern void OPTIRQ_Wiggler(void) ;

#endif /* INC_MTRSPI_H_ */
