/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define ETHERNET_MEM 0X30000000
#define SPINOR_MEM 0X90000000
#define QSPI_IO2_Pin GPIO_PIN_2
#define QSPI_IO2_GPIO_Port GPIOE
#define ETH_IRQ_Pin GPIO_PIN_3
#define ETH_IRQ_GPIO_Port GPIOE
#define ETH_RST_Pin GPIO_PIN_4
#define ETH_RST_GPIO_Port GPIOE
#define OSC25_IN_Pin GPIO_PIN_0
#define OSC25_IN_GPIO_Port GPIOH
#define OSC25_OUT_Pin GPIO_PIN_1
#define OSC25_OUT_GPIO_Port GPIOH
#define MCU_RSSI_Pin GPIO_PIN_0
#define MCU_RSSI_GPIO_Port GPIOC
#define MCU_AUDOUT_Pin GPIO_PIN_4
#define MCU_AUDOUT_GPIO_Port GPIOA
#define ADEBUG_Pin GPIO_PIN_5
#define ADEBUG_GPIO_Port GPIOA
#define MCU_AUDIN_Pin GPIO_PIN_6
#define MCU_AUDIN_GPIO_Port GPIOA
#define QSPI_CLK_Pin GPIO_PIN_2
#define QSPI_CLK_GPIO_Port GPIOB
#define RPTR_UART_RX_Pin GPIO_PIN_7
#define RPTR_UART_RX_GPIO_Port GPIOE
#define RPTR_UART_TX_Pin GPIO_PIN_8
#define RPTR_UART_TX_GPIO_Port GPIOE
#define REF_10MHZ_Pin GPIO_PIN_9
#define REF_10MHZ_GPIO_Port GPIOE
#define LED_HB_Pin GPIO_PIN_10
#define LED_HB_GPIO_Port GPIOE
#define LED_RSSI_G_Pin GPIO_PIN_11
#define LED_RSSI_G_GPIO_Port GPIOE
#define LED_RSSI_R_Pin GPIO_PIN_12
#define LED_RSSI_R_GPIO_Port GPIOE
#define IN_DISR_Pin GPIO_PIN_13
#define IN_DISR_GPIO_Port GPIOE
#define IN_TISR_Pin GPIO_PIN_14
#define IN_TISR_GPIO_Port GPIOE
#define IN_AISR_Pin GPIO_PIN_15
#define IN_AISR_GPIO_Port GPIOE
#define QSPI_NCS_Pin GPIO_PIN_10
#define QSPI_NCS_GPIO_Port GPIOB
#define MTRSPI_MISO_Pin GPIO_PIN_14
#define MTRSPI_MISO_GPIO_Port GPIOB
#define MTRSPI_MOSI_Pin GPIO_PIN_15
#define MTRSPI_MOSI_GPIO_Port GPIOB
#define GPS_UART_TX_Pin GPIO_PIN_8
#define GPS_UART_TX_GPIO_Port GPIOD
#define GPS_UART_RX_Pin GPIO_PIN_9
#define GPS_UART_RX_GPIO_Port GPIOD
#define QSPI_IO0_Pin GPIO_PIN_11
#define QSPI_IO0_GPIO_Port GPIOD
#define QSPI_IO1_Pin GPIO_PIN_12
#define QSPI_IO1_GPIO_Port GPIOD
#define QSPI_IO3_Pin GPIO_PIN_13
#define QSPI_IO3_GPIO_Port GPIOD
#define LED_TX_Pin GPIO_PIN_14
#define LED_TX_GPIO_Port GPIOD
#define LED_CONN_Pin GPIO_PIN_15
#define LED_CONN_GPIO_Port GPIOD
#define LED_GPS_Pin GPIO_PIN_6
#define LED_GPS_GPIO_Port GPIOC
#define RDSTAT_Pin GPIO_PIN_7
#define RDSTAT_GPIO_Port GPIOC
#define ACFAIL_Pin GPIO_PIN_8
#define ACFAIL_GPIO_Port GPIOC
#define CLK_25M_Pin GPIO_PIN_9
#define CLK_25M_GPIO_Port GPIOC
#define OPT_IRQ_Pin GPIO_PIN_8
#define OPT_IRQ_GPIO_Port GPIOA
#define DEBUG_TX_Pin GPIO_PIN_9
#define DEBUG_TX_GPIO_Port GPIOA
#define DEBUG_RX_Pin GPIO_PIN_10
#define DEBUG_RX_GPIO_Port GPIOA
#define SPARE_RX_Pin GPIO_PIN_11
#define SPARE_RX_GPIO_Port GPIOA
#define SPARE_TX_Pin GPIO_PIN_12
#define SPARE_TX_GPIO_Port GPIOA
#define SWDIO_Pin GPIO_PIN_13
#define SWDIO_GPIO_Port GPIOA
#define SWCLK_Pin GPIO_PIN_14
#define SWCLK_GPIO_Port GPIOA
#define GPS_1PPS_Pin GPIO_PIN_15
#define GPS_1PPS_GPIO_Port GPIOA
#define FSPI_CLK_Pin GPIO_PIN_10
#define FSPI_CLK_GPIO_Port GPIOC
#define FSPI_MISO_Pin GPIO_PIN_11
#define FSPI_MISO_GPIO_Port GPIOC
#define FSPI_MOSI_Pin GPIO_PIN_12
#define FSPI_MOSI_GPIO_Port GPIOC
#define FSPI_NCS_Pin GPIO_PIN_0
#define FSPI_NCS_GPIO_Port GPIOD
#define MTRSPI_SCK_Pin GPIO_PIN_3
#define MTRSPI_SCK_GPIO_Port GPIOD
#define MCU_COR_Pin GPIO_PIN_5
#define MCU_COR_GPIO_Port GPIOD
#define MCU_PTT_Pin GPIO_PIN_6
#define MCU_PTT_GPIO_Port GPIOD
#define RPTR_VSENSE14_Pin GPIO_PIN_7
#define RPTR_VSENSE14_GPIO_Port GPIOD
#define MTRSPI_NSS_Pin GPIO_PIN_4
#define MTRSPI_NSS_GPIO_Port GPIOB
#define MTRSPI_CSID_Pin GPIO_PIN_5
#define MTRSPI_CSID_GPIO_Port GPIOB
#define CONSOLE_RX_Pin GPIO_PIN_0
#define CONSOLE_RX_GPIO_Port GPIOE
#define CONSOLE_TX_Pin GPIO_PIN_1
#define CONSOLE_TX_GPIO_Port GPIOE

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
