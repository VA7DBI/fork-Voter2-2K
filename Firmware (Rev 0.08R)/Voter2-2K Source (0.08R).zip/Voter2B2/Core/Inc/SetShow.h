#ifndef INC_SETSHOW_H_
#define INC_SETSHOW_H_

typedef enum
{
   PROBE_NONE = 0,
   PROBE_RXIN,
   PROBE_RXDEM,
   PROBE_RXVOICE,
   PROBE_TXSRC,
   PROBE_TXPL,
   PROBE_TXTONE,
   PROBE_TXOUT,
   PROBE_RSSSIG,
   PROBE_RSSLVL,
} PROBE_ENUMS ;

extern char* cmd_set_cmd    ;
extern char* cmd_set_cmdsc  ;
extern char* cmd_show_cmd   ;
extern char* cmd_show_cmdsc ;
extern char* cmd_ss_help    ;

/* Parameter lists needed in other places */
extern TOKENLIST Booleans[] ;
extern TOKENLIST GPS_Edges[] ;
extern TOKENLIST MyIPModes[] ;
extern TOKENLIST RxModes[] ;
extern TOKENLIST RssiModes[] ;

extern uint8_t AnalogProbe ;

extern int  Cmd_set(int, char**) ;
extern int  Cmd_show(int, char**) ;
extern void SetShowHelp(char*,char*) ;

extern void SetNum   (char*,char*,int32_t,int32_t,int32_t* ) ;
extern void SetD6Num (char*,char*,int32_t,int32_t,int32_t* ) ;
extern void SetList  (char*,char*,uint8_t*,TOKENLIST*,int) ;
extern void SetOnOff (char*,char*,uint8_t* ) ;
extern void SetStr   (char*,char*,char*,int) ;
extern void SetIP    (char*,char*,uint32_t*) ;
extern void SetNot   (void                 ) ;
extern void ShowIP   (char*,uint32_t) ;

#endif /* INC_SETSHOW_H_ */
