#ifndef INC_HISTOGRAMS_H_
#define INC_HISTOGRAMS_H_

extern char* cmd_jitter_cmd   ;
extern char* cmd_jitter_cmdsc ;
extern char* cmd_jitter_help  ;

extern char* cmd_netdelay_cmd   ;
extern char* cmd_netdelay_cmdsc ;
extern char* cmd_netdelay_help  ;

extern int  Cmd_jitter(int, char**) ;
extern void Jitter_Log(void) ;

extern int  Cmd_netdelay(int, char**) ;
extern void NetDelay_Log(uint32_t) ;

#endif /* INC_HISTOGRAMS_H_ */
