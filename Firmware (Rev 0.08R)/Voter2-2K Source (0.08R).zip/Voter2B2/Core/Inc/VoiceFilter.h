#ifndef VOICEFILTER_H_
#define VOICEFILTER_H_

/*

FIR filter designed with
 http://t-filter.appspot.com

sampling frequency: 8000 Hz

fixed point precision: 16 bits

* 64 Hz - 375 Hz
  gain = 0
  desired attenuation = -40 dB
  actual attenuation = n/a

* 475 Hz - 4000 Hz
  gain = 1
  desired ripple = 3 dB
  actual ripple = n/a

*/

/******************************************************************************/
/* I really wanted to block 0-250Hz and pass 300Hz-4KHz, but can't seem to    */
/* get that with the filter generator below.  Something about getting the     */
/* blocking down to 0Hz was making it go crazy.  The compromise was to not    */
/* block less than 64Hz and block up to 375Hz.  Even with that it is a pretty */
/* big filter at 91 taps!  There may be a better way to generate the filter,  */
/* but this is good for now.                                                  */
/******************************************************************************/

#define VOICEFILTER_TAP_NUM 91

extern int16_t VoiceFilter_taps[VOICEFILTER_TAP_NUM] ;

#if 0
typedef struct {
  int16_t history[VOICEFILTER_TAP_NUM];
  unsigned int last_index;
} VoiceFilterFilter;

void VoiceFilter_init(VoiceFilter* f);
void VoiceFilter_put(VoiceFilter* f, int16_t input);
int16_t VoiceFilter_get(VoiceFilter* f);
#endif

#endif
