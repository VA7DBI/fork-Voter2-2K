#ifndef INC_TFTP_H_
#define INC_TFTP_H_

#define FNAMELEN     40 /* TFTP File name length */
#define TFTP_BUFLEN 516 /* TFTP packet length    */
#define TFTP_PAYLOAD (TFTP_Buf+4)
#define TFTP_DUP     -1 /* Duplicate packet flag */

#define TFTP_RRQ 0x0001 /* Read  request header bytes */
#define TFTP_WRQ 0x0002 /* Write request header bytes */

typedef enum
{
   TFTP_MODE_NONE = 0,
   TFTP_MODE_ASCII,
   TFTP_MODE_OCTET
} TFTP_MODES;

typedef enum
{
   TFTP_OPCODE_RRQ = 1,
   TFTP_OPCODE_WRQ,
   TFTP_OPCODE_DATA,
   TFTP_OPCODE_ACK,
   TFTP_OPCODE_ERR
} TFTP_OPCODES;

typedef enum
{
   TFTPERR_NONE = 0,
   TFTPERR_TFTPCODE,
   TFTPERR_TIMEOUT,
   TFTPERR_BADTID,
   TFTPERR_BADHDR,
   TFTPERR_BADLEN,
   TFTPERR_BADBLOCK,
   TFTPERR_BADSREC,
   TFTPERR_BADADDR
} TFTP_ERRCODES ;

typedef struct
{
   uint16_t Mode        ; /* currently not used, always netascii */
   uint16_t Opcode      ;
   uint16_t SrcTID      ;
   uint16_t DstTID      ;
   uint16_t Block       ;
   uint16_t Error       ;
   uint16_t TFTP_Error  ;
   struct netconn *TFTPconn ;
   ip_addr_t TFTP_Server_IP ;
} TFTP_CONTEXT ;

extern uint8_t TFTP_Buf[TFTP_BUFLEN] ;

extern void TFTP_Init(uint32_t,TFTP_CONTEXT*) ;
extern void TFTP_SendRWRQ(char*,int,int,TFTP_CONTEXT*) ;
extern int  TFTP_GetData(TFTP_CONTEXT*) ;
extern void TFTP_SendData(TFTP_CONTEXT*,int) ;
extern void TFTP_SendAck(TFTP_CONTEXT*) ;
extern void TFTP_SendErr(TFTP_CONTEXT*) ;
extern void TFTP_Terminate(TFTP_CONTEXT*) ;
extern void Show_TFTP_Err(TFTP_CONTEXT*) ;

#endif /* INC_TFTP_H_ */
