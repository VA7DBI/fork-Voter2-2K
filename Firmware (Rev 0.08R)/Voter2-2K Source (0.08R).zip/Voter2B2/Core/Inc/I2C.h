#ifndef INC_I2C_H_
#define INC_I2C_H_

extern void I2C_SharedMemWrite(uint16_t,uint16_t,uint16_t,uint8_t*,uint16_t,int) ;
extern void I2C_SharedMemRead (uint16_t,uint16_t,uint16_t,uint8_t*,uint16_t,int) ;
extern int  I2C_SharedIsReady (uint16_t,uint32_t,uint32_t,int) ;

#endif /* INC_I2C_H_ */
