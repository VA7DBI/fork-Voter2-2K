#ifndef INC_TIMERS_H_
#define INC_TIMERS_H_

#define GPS_1PPS_FALLING 0
#define GPS_1PPS_RISING 1

/* Timer 2 important constants: for counting at 40MHz (sysclk/6).   */
/* Sysclk/6 was picked as it is the smallest divider that yields    */
/* an integer number of ns/tick (25).                               */
#define   TIM2_FREQ 40000000  /* TIM2 count frequency (40MHz)       */
#define   TIM2_NS_PER_TICK 25 /* ns per tick.                       */
#define   TIM2_ERRB 4000      /* TIM2 frequency error band (100ppm) */

extern int      GPSLocked    ; /* GPS Locked flag                 */
extern int      GPSUsed      ; /* GPS being used flag             */
extern uint32_t TicksP1PPS   ; /* TIM2 ticks per 1PPS             */
extern uint32_t ClocksP1PPS  ; /* CPU clocks per GPS1PPS          */
extern int      New_CP1PPS_L ; /* GPS1PPS new value flag (loop)   */
extern int      New_CP1PPS_D ; /* GPS1PPS new value flag (display)*/

extern void MY_TIM2_FinishInit(void) ;
#ifndef DUMBTIMERMODE
extern void MY_TIM2_Svc(void) ;
#endif
extern void MY_TIM7_Svc(void);
extern void MY_TIM15_FinishInit(void) ;
extern void MainTaskWatchdogPet(void) ;
extern void RebootNow(void) ;

/* For FreeRTOS Runtime monitoring */
extern uint32_t RunTime   ; /* For RTOS profiling  */

#endif /* INC_TIMERS_H_ */
