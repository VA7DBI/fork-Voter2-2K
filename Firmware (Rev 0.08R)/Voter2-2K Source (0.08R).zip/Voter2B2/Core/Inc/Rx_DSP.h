#ifndef INC_RX_DSP_H_
#define INC_RX_DSP_H_

typedef enum
{
   RXMODE_OFF,
   RXMODE_COR,
   RXMODE_CTCSS,
   RXMODE_BOTH,
   RXMODE_ON
} RXMODES ;

typedef enum
{
   RSSI_ANALOG = 0,
   RSSI_HPF,
   RSSI_BEW1,
   RSSI_BEW2
} RSSI_ENUMS ;

#define FFT_BLOCKLEN 32
#define FFT_BINLEN (FFT_BLOCKLEN/2)

extern int      LocalDeemph  ;
extern int      RxDiags      ;

/* These are all status variables for the Rx path for diagnostics */
extern uint16_t VinPP        ;
extern uint16_t VinPP_Max    ;
extern uint32_t Hpf_RSSI     ;
extern int      RxTToneMode  ;
extern int32_t  RxFFT_Bins[FFT_BLOCKLEN] ;
extern int      BEW_Event    ;
extern int32_t RxFFT_SigSum  ;

void Rx_FilterInit(void) ;
void Rx_EnqPacket(uint16_t*,uint32_t) ;

#endif /* INC_RX_DSP_H_ */
