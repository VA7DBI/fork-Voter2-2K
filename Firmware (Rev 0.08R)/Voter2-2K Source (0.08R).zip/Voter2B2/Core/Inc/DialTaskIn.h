#ifndef INC_DIALTASKIN_H_
#define INC_DIALTASKIN_H_

/* Sync Check support */
extern uint8_t  SyncCheck    ; /* Sync check flag     */
extern uint32_t MySecs       ; /* Event local seconds */
extern uint32_t MynSecs      ; /* Event local ns      */
extern uint32_t DSSecs       ; /* DIAL server seconds */
extern uint32_t DSnSecs      ; /* DIAL server ns      */

extern uint32_t RxPackets[PAYLOAD_CNTRS] ; /* Rx packet count by type */

#endif /* INC_DIALTASKIN_H_ */
