#ifndef INC_TTONES_H_
#define INC_TTONES_H_

extern char* cmd_txtone_cmd   ;
extern char* cmd_txtone_cmdsc ;
extern char* cmd_txtone_help  ;

extern char* cmd_rxtest_cmd   ;
extern char* cmd_rxtest_cmdsc ;
extern char* cmd_rxtest_help  ;

extern int  Cmd_txtone(int, char**) ;
extern int  Cmd_rxtest(int, char**) ;

#endif /* INC_TTONES_H_ */
