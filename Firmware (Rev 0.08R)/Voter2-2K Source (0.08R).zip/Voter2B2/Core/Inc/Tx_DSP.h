#ifndef INC_TX_DSP_H_
#define INC_TX_DSP_H_

#define MAINBUF  0 /* Tx buffer main  channel */
#define DEBUGBUF 1 /* Tx buffer debug channel */

#define PROBE_AUDIO 0 /* Probe data is signed audio */
#define PROBE_RAW   1 /* Probe data is raw data     */

/* AddATONE mixer modes and formats */
#define TONE_BYPASS     0
#define TONE_REPLACE    1
#define TONE_ADD        2
#define TONE_MIX        3

typedef enum
{
   CTCSS_670 = 0,
   CTCSS_719,
   CTCSS_744,
   CTCSS_770,
   CTCSS_797,
   CTCSS_825,
   CTCSS_854,
   CTCSS_885,
   CTCSS_915,
   CTCSS_948,
   CTCSS_974,
   CTCSS_1000,
   CTCSS_1035,
   CTCSS_1072,
   CTCSS_1109,
   CTCSS_1148,
   CTCSS_1188,
   CTCSS_1230,
   CTCSS_1273,
   CTCSS_1318,
   CTCSS_1365,
   CTCSS_1413,
   CTCSS_1462,
   CTCSS_1514,
   CTCSS_1567,
   CTCSS_1622,
   CTCSS_1679,
   CTCSS_1738,
   CTCSS_1799,
   CTCSS_1862,
   CTCSS_1928,
   CTCSS_2035,
   CTCSS_2107,
   CTCSS_2181,
   CTCSS_2257,
   CTCSS_2336,
   CTCSS_2418,
   CTCSS_2503
} CTCSS_ENUMS ;

typedef enum
{
   GENERAL_TIMED,
   GPS_TIMED,
   LOCAL_TIMED
} TIMING_TYPES ;

typedef struct
{
   uint32_t phase ;
   uint32_t freq ;
   uint8_t  level ;
   uint8_t  mix ;
} TONE_CONTEXT ;

extern uint32_t GlobDialTxBufDly ;
extern uint32_t GlobLocTxBufDly ;
extern uint8_t  Local_CTCSS_Lvl  ;
extern uint8_t  Local_CTCSS_Freq ;
extern uint16_t ProbeBuf[APKT_SAMPLES] ; /* Probe data buffer */
extern int      LocalOverride ;
extern TONE_CONTEXT TTone_Context ;

extern void Tx_ClearPacket(uint16_t*,int) ;
extern void Tx_DeqPacket(uint16_t*,uint32_t) ;
extern void Tx_EnqPacket(int16_t*,int,uint32_t,uint32_t) ;
extern void AddATone16s(int16_t*,int16_t*,TONE_CONTEXT*) ;
extern void AddATone12u(uint16_t*,uint16_t*,TONE_CONTEXT*) ;
extern void ProbeCheck(void*,int8_t,int) ;

#endif /* INC_TX_DSP_H_ */
