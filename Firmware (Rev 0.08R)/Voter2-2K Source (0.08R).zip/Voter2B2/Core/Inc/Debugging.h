#ifndef INC_DEBUGGING_H_
#define INC_DEBUGGING_H_

/******************************************************************************/
/* This is the common header for the following debugging features:            */
/*  - The error count logger - an array of counters to catch rare events      */
/*  - RtFlags - A way for the hard real-time code to report events/errors     */
/*  - DbFlags - debugging flags - flags that can be set by code or the user   */
/*  - Error data logger - Logs data for an error event.                       */
/*                                                                            */
/* The variables and functions are scattered around in other source files,    */
/* but I want just this header for using them.  It saves me from having to    */
/* have things like CLI includes in code that has nothing to do with the CLI. */
/* I do note where the actual variable/code is below.                         */
/******************************************************************************/

/******************************************************************************/
/* The error logger is for code to log any critical errors that are likely    */
/* very rare but need tracking for long term stability enhancing. Rather than */
/* error messages to a console that is likely not connected anyway, a value   */
/* in an array is incremented and the user can check the status with the show */
/* errlogs CLI command.  The user can clear it too with the set errlogs       */
/* command.  The nice part is minimal code and an incremental cost of one     */
/* byte for each event to track, so very scaleable.  The enum below is the    */
/* list of events being tracked.                                              */
/* The IncErrLog() routine and array are defined in SetShow.c                 */
/******************************************************************************/
#define ERRLOGENTRIES 32

#define ERRLOG_SHOW 0
#define ERRLOG_NOSHOW 1

extern uint8_t ErrLog[ERRLOGENTRIES] ;
extern void IncErrLog(int,int) ;

/* These are the enumerations for Error logging */
typedef enum
{
   /*  0 */ ERRLOG_SENDDIALPACKET_NETBUF_NEW = 0,
   /*  1 */ ERRLOG_SENDDIALPACKET_NETBUF_ALLOC,
   /*  2 */ ERRLOG_SENDDIALPACKET_PBUF_TAKE,
   /*  3 */ ERRLOG_SENDDIALPACKET_NETCONN_SENDTO,
   /*  4 */ ERRLOG_SENDTFTPPACKET_NETBUF_NEW,
   /*  5 */ ERRLOG_SENDTFTPPACKET_NETBUF_ALLOC,
   /*  6 */ ERRLOG_SENDTFTPPACKET_PBUF_TAKE,
   /*  7 */ ERRLOG_SENDTFTPPACKET_NETCONN_SENDTO,
   /*  8 */ ERRLOG_CONSOLE_PUTSD_NETCONN_WRITE,
   /*  9 */ ERRLOG_LOGGGER2TASK_NETCONN_WRITE1,
   /* 10 */ ERRLOG_LOGGGER2TASK_NETCONN_WRITE2,
   /* 11 */ ERRLOG_LOGGGER2TASK_NETCONN_WRITE3,
   /* 12 */ ERRLOG_SER2NETTASK_NETCONN_WRITE,
   /* 13 */ ERRLOG_SER2NETTASK_CMDACK_NETCONN_WRITE,
   /* 14 */ ERRLOG_SER2NETTASK_TXDO_CMDACK_NETCONN_WRITE,
   /* 15 */ ERRLOG_SER2NETTASK_TXDONT_CMDACK_NETCONN_WRITE,
   /* 16 */ ERRLOG_DIALETHRXTASK_NETCONN_RECV,
   /* 17 */ ERRLOG_SER2NETRXTASK_NETCONN_RECV,
   /* 18 */ ERRLOG_TFTP_GETDATA_NETCONN_RECV,
   /* 19 */ ERRLOG_TIM2GPSTRIG_TOLERANCE,
   /* 20 */ ERRLOG_TXENQUEUE_FIFOFULL,
   /* 21 */ ERRLOG_CONSOLE_CHECKFORBROKENLINK,
   /* 22 */ ERRLOG_TIM2GPSTRIG_GPSLOSTLOCKWPPS,
   /* 23 */ ERRLOG_TFTP_DUPLICATE_BLOCKNUM,
   /* 24 */ ERRLOG_CONSOLE_WRITE_NETCONN_WRITE,
} ERRLOG_ENUMS ;

/******************************************************************************/
/* RtFlags are for the hard real time code (currently timer2 code) that runs  */
/* "under" the RTOS.  They can't make any RTOS calls, so they just set these  */
/* flags that are then picked up by higher level timer code in the HAL        */
/* sequencer that can make RTOS calls and that code generates the report.     */
/* See the comment by each flag index as to its use.                          */
/* The array is instantiated in Settings.c                                    */
/******************************************************************************/
#define NRTFLAGS 8
extern uint8_t RtFlags[NRTFLAGS] ;

#define RTFLAG_GPSLOCKED  0 /* (Timers) GPS locked/unlocked status      */
#define RTFLAG_DIALDELTA  1 /* (TxDSP) Dial Packet TS delta (if bad)    */
#define RTFLAG_GPS1PPS    2 /* (Timers) GPS 1PPS reporting (if enabled) */
/*                             3 - 7 Currently unused                   */

/******************************************************************************/
/* DbFlags are for low level debugging work, not intended for "regular" users.*/
/* These flags can be changed by the CLI and/or debugging code and can be     */
/* reported on-demand or queried by the CLI as well.  These flags can and will*/
/* change as debugging is happening, so extremely dynamic.                    */
/* The array is instantiated in Settings.c                                    */
/******************************************************************************/
#define NDBFLAGS 8
extern uint8_t DbFlags[NDBFLAGS] ;

#define DBFLAG_TSDELTAS   0 /* Log timestamp deltas (value meaning below)     */
/*                              - 0 - Don't log nuthin                        */
/*                              - 1 - Log packetTS vs realtime TS delta       */
/*                              - 2 - Log Rx packet TS deltas                 */
/*                              - 3 - Log Tx packet TS deltas                 */
/*                             1 - 7 Currently unused                         */

#endif /* INC_DEBUGGING_H_ */

/******************************************************************************/
/* The error data logger notes and event ID, when it happened, and some data  */
/* associated with the event.  The event ID and data are 32-bit integers with */
/* no pre-set format other than don't use 0 for an event ID as that is used   */
/* to flag no data.  The time is based on the HAL timer tick, a 32-bit value  */
/* that starts at 0 at boot and rolls over in just under 50 days.             */
/* A call provides the event ID and data and the timer value is added to a    */
/* FIFO.                                                                      */
/* The data and routines are in SetShow.c                                     */
/******************************************************************************/
#define NDLOGGERIDS 32

typedef struct
{
   uint32_t Event_Timestamp ;
   uint32_t Event_ID ;
   uint32_t Event_Data ;
} DLOGGER_STRUCT ;

extern DLOGGER_STRUCT DLogger_Data[NDLOGGERIDS] ;

#define DLOGGER_TSDELTANS   0x00000001
#define DLOGGER_TXFIFOSLIP  0x00000002
#define DLOGGER_TXDIALTSERR 0x00000003
#define DLOGGER_TXDACTERR   0x00000004

extern void DLogger_Event(uint32_t,uint32_t) ;
