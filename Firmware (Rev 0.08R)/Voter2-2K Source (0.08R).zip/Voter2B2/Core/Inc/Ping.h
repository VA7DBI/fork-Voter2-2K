#ifndef INC_PING_H_
#define INC_PING_H_

extern char* cmd_ping_cmd   ;
extern char* cmd_ping_cmdsc ;
extern char* cmd_ping_help  ;

extern int  Cmd_Ping(int, char**) ;

#endif /* INC_PING_H_ */
