#ifndef INC_ANALOGIO_H_
#define INC_ANALOGIO_H_

#define APKT_SAMPLERATE 8000 /* Audio sample rate */
#define APKT_SAMPLES SAMPLESIZE /* Samples in a standard Audio Packet */
#define APKT_RXDMABUF_SIZE (APKT_SAMPLES*2) /* Rx Audio DMA buffer (Ping+Pong buffers)  */
#define APKT_TXDMABUF_SIZE (APKT_SAMPLES*4) /* Tx Audio DMA buffer (Ping+Pong & stereo) */
#define RSSI_DMABUF_SIZE 5

#define A2DDAC_CLK_LOCAL 0
#define A2DDAC_CLK_GPS   1

#define ADAC_0V 0x0800 /* Analog ADC/DAC 0V */

#define ANALOG_RSSI_RAW 0
#define ANALOG_RSSI_INTERPOLATED 1

extern void     MY_ADC1_FinishInit(void) ;
extern void     MY_DAC1_FinishInit(void) ;
extern void     MY_DAC2_FinishInit(void) ;
extern void     MY_Analog_DMA_FinishInit(void) ;
extern void     Update_ARSSI_Table(void) ;
extern uint16_t Get_Analog_RSSI(int) ;

#endif /* INC_ANALOGIO_H_ */
