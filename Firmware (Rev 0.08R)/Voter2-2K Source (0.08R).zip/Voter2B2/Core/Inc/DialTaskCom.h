#ifndef INC_DIALTASKCOM_H_
#define INC_DIALTASKCOM_H_

/* These are the shared #defines, structs, and globals JUST BETWEEN           */
/* DIALTASKIN and DIALTASKOUT.  There is very little common code between the  */
/* the two paths, so this is mainly #defines and structs.  There are some     */
/* shared globals as noted below.  This include should not be called out in   */
/* any code other than DialTaskIn and DialTaskOut.                            */

/* DIAL packet sizes */
#define VOTER_MINPLEN       24 /* DIAL Packet minimum size              */
#define VOTER_MAXPLEN      225 /* DIAL Packet maximum size              */
#define VOTER_PACKLEN_T0GP  25 /* Authorization packet size (Type 0 GP) */
#define VOTER_PACKLEN_T0GPS 24 /* Authorization packet size (Type 0 GPS)*/
#define VOTER_PACKLEN_T1   185 /* MuLaw packet size (Type 1)            */
#define VOTER_PACKLEN_T2GP  24 /* GPS packet size (Type 2 GP)           */
#define VOTER_PACKLEN_T2GPS 50 /* GPS packet size (Type 2 GPS)          */
#define VOTER_PACKLEN_T3   188 /* ADPCM packet size (Type 3)            */
#define VOTER_PACKLEN_T5   224 /* Ping packet size (Type 5) (variable!) */

#define DIAL_AUD_MAXPACKETSIZE 163 /* for uLaw or ADPCM (ADPCM biggest) */


/* These are the Voter packet structures.  The header is the same for  */
/* all of them, then have structures for each packet type starting     */
/* the common header.                                                  */
typedef struct
{
   uint32_t time_s        ; /* Time in seconds                     */
   uint32_t time_ns       ; /* Time in ns (voting) or counter (GP) */
   uint8_t  challenge[10] ; /* Challenge message                   */
   uint8_t  response[4]   ; /* Challenge response                  */
   uint16_t Payload_Type  ; /* Payload type identifier             */
} HEADER_T ;

typedef struct
{
   HEADER_T header        ; /* Payload header (common)             */
   uint8_t  FlagByte      ; /* Flags byte                          */
} PAYLOAD_T0_STRUCT  ;

typedef struct
{
   HEADER_T header        ; /* Payload header (common)             */
   uint8_t  Rssi          ; /* RSSI value                          */
   uint8_t  Audio[160]    ; /* Audio samples (160 samples or 20ms) */
} PAYLOAD_T1_STRUCT ;

typedef struct
{
   HEADER_T header        ; /* Payload header (common)             */
   uint8_t  Longitude[9]  ; /* GPS Longitude                       */
   uint8_t  Latitude[10]  ; /* GPS Latitude                        */
   uint8_t  Altitude[7]   ; /* GPS Altitude                        */
} PAYLOAD_T2_STRUCT ;

typedef struct
{
   HEADER_T header        ; /* Payload header (common)             */
   uint8_t  Rssi          ; /* RSSI value                          */
   uint8_t  Audio[163]    ; /* Audio data (163 bytes/320 samples)  */
} PAYLOAD_T3_STRUCT ;

typedef struct
{
   HEADER_T header        ; /* Payload header (common)             */
   uint8_t  PingData[200] ; /* Ping data (200 bytes max)           */
} PAYLOAD_T5_STRUCT ;


extern int            EnableDialOut  ; /* Enable sending to DIAL         */
extern struct netconn *DIALconn      ; /* netconn handle for DIAL server */
extern ip_addr_t      DIAL_Server_IP ; /* DIAL Sever IP address          */

extern int      DialWatchdog  ; /* DIAL Comms watchdog counter */
extern int      DIAL_Offline  ; /* DIAL Offline flag           */
extern int      DIAL_State    ; /* DIAL connection state       */
extern uint8_t  DIAL_flagbyte ; /* DIAL Server flag byte       */
extern uint32_t FKGPS_Time    ; /* Fake GPS Time (seconds)     */
extern uint32_t FKGPS_Tns     ; /* Fake GPS Time (ns)          */
extern uint32_t GP_SeqNum     ; /* GP mode packet counter      */
extern uint8_t  DIAL_Challenge[SETTINGS_CHALLENGE_LEN] ;/* Challenge string from the DIAL server */

extern int CheckSyncCheck(void) ;
extern long    crc32_bufs(unsigned char *buf, unsigned char *buf1) ;
extern void Tx_Ping_Packet (void*,uint16_t) ;

#endif /* INC_DIALTASKCOM_H_ */
