#ifndef INC_DIALTASK_H_
#define INC_DIALTASK_H_

/******************************************************************************/
/* Defines (including enums)                                                  */
/******************************************************************************/
/* Stream IDs into DialTask */
#define DIALTASK_STREAMID_RXAUDIO 0x0001
#define DIALTASK_STREAMID_ETHRX   0x0002

/* Buffer IDs into DialTask */
#define DIALTASK_BUFID_ADC1 0x0001
#define DIALTASK_BUFID_ADC2 0x0002
#define DIALTASK_BUFID_DAC  0x0003
#define DIALTASK_BUFID_ETH  0x0004

/* Compression modes */
#define COMPRESSION_MULAW 0
#define COMPRESSION_ADPCM 1

/* DIAL Server flag bits.  All but GENPURPOSE are sent by host only */
#define DIALFLAG_FLATAUDIO   1
#define DIALFLAG_ALWAYSAUDIO 2
#define DIALFLAG_NOSUBAUDIO  4
#define DIALFLAG_IMMASTER    8
#define DIALFLAG_USEADPCM   16
#define DIALFLAG_GENPURPOSE 32

/* Make checks easier */
#define DIAL_FLATAUDIO   (DIAL_flagbyte&DIALFLAG_FLATAUDIO)
#define DIAL_ALWAYSAUDIO (DIAL_flagbyte&DIALFLAG_ALWAYSAUDIO)
#define DIAL_NOSUBAUDIO  (DIAL_flagbyte&DIALFLAG_NOSUBAUDIO)
#define DIAL_IMMASTER    (DIAL_flagbyte&DIALFLAG_IMMASTER)
#define DIAL_USEADPCM    (DIAL_flagbyte&DIALFLAG_USEADPCM)
#define DIAL_GENPURPOSE  (DIAL_flagbyte&DIALFLAG_GENPURPOSE)

/* Besides knowing each of the four individual states, it is also handy to    */
/* know overall if you are authorized regardless of the codec or knowing if   */
/* you are not authorized regardless of if it is due to being disconnected or */
/* connected but failing the authentication.  These #defines make that easier.*/
#define DIAL_NOTAUTHORIZED ((DIAL_DISC ==DIAL_State)||(DIAL_UNAUTH==DIAL_State))
#define DIAL_AUTHORIZED    ((DIAL_MULAW==DIAL_State)||(DIAL_ADPCM ==DIAL_State))

/* You can be authorized, but still can't send data if you are in GPS mode    */
/* and GPS isn't valid yet.                                                   */
#define DIAL_ACTIVE (DIAL_AUTHORIZED && ((DIAL_GENPURPOSE) || (GPSUsed)))

/* DIAL Server connection states.  See #defines further down for aggregate    */
/* state definitions.                                                         */
typedef enum{
   DIAL_DISC = 0, /* Disconnected                        */
   DIAL_UNAUTH,   /* Connected, not authorized (bad pwd) */
   DIAL_MULAW,    /* Connected, authorized, uLaw codec   */
   DIAL_ADPCM     /* Connected, authorized, ADPCM codec  */
} DIALSTATES;

/* Packet timing modes */
typedef enum{
   PKTTIM_GP = 0, /* General purpose mode         */
   PKTTIM_GPS,    /* GPS timed mode               */
   PKTTIM_FKGPS   /* Fake GPS mode (for bring-up) */
} PLTTIM_LIST;

typedef enum{
   SYNCCHECK_IDLE = 0, /* Idle mode */
   SYNCCHECK_START,    /* Started   */
   SYNCCHECK_RUNNING   /* Running   */
} SYNCCHECK_SEQ;

typedef enum
{
   DIALIPMODE_STATIC = 0,
   DIALIPMODE_DNS
} DIALIPMODES ;

typedef enum{
   PAYLOAD_T0AUTH = 0, /* Authorization packet Tag */
   PAYLOAD_T1MULAW,    /* uLaw audio packet tag    */
   PAYLOAD_T2GPSINFO,  /* GPS/Keepalive packet tag */
   PAYLOAD_T3ADPCM,    /* ADPCM audio packet tag   */
   PAYLOAD_T4NA,       /* Tag not used             */
   PAYLOAD_T5PING,     /* Ping packet tag          */
   PAYLOAD_ERR,        /* Bad tag ID (err count)   */
   PAYLOAD_CNTRS       /* Counter array size       */
} PAYLOAD_TYPES;


/******************************************************************************/
/* Structures                                                                 */
/******************************************************************************/

/******************************************************************************/
/* Global Variables                                                           */
/******************************************************************************/

extern uint32_t TxPackets[PAYLOAD_CNTRS] ; /* Tx packet count by type */
extern uint8_t  DIAL_flagbyte            ; /* DIAL Server flags       */

extern uint32_t DIAL_ip      ; /* DIAL server resolved IP */
extern int      DIAL_State   ; /* DIAL connection state   */

extern int PreComp_Vpp       ; /* Pre-compression p-p value */

/******************************************************************************/
/* Global Routines                                                            */
/******************************************************************************/
extern void Dial_Enqueue(int16_t*,uint32_t,uint8_t,uint8_t) ;
extern void DIAL_Assert_Restart(void) ;

#endif /* INC_DIALTASK_H_ */
