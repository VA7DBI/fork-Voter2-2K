#ifndef INC_VCXO_H_
#define INC_VCXO_H_

#define DISP_HISTORY    25 /* Display history size */
#define PPT_PHZ      25000 /* PPT per Hz at 40MHz  */

extern int      Vcxo_present ;
extern uint16_t Vcxo_DACval  ;
extern int      VcxoDValid ;

extern uint32_t disp_history[DISP_HISTORY] ; /* Sample history for display */

void Find_Vcxo(void) ;
void Vcxo_Loop(void) ;

#endif /* INC_VCOCXO_H_ */
