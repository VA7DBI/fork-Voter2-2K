#ifndef INC_BACKUP_H_
#define INC_BACKUP_H_

extern int  Settings_Backup(char*) ;
extern int  Settings_Restore(char*) ;
extern char Backup_getc(void) ;

/* externs so optional settings (local, dial, etc) can use them */
extern int Backup_IP(char*, char* ,uint32_t) ;
extern int Backup_int(char*, char* ,int) ;
extern int Backup_list(char*, char* ,int,TOKENLIST*) ;
extern int Backup_str(char*, char* ,char*) ;

#endif /* INC_BACKUP_H_ */
