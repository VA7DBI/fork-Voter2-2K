#ifndef __CONSOLETASK_H
#define __CONSOLETASK_H

/* There is an available external #define called CONSOLE_NOLOGIN that will    */
/* bypass the login sequence if there is no need for that feature.  If        */
/* defined, there is just a prompt 'OK>' on connecting and after each command */
/* is complete.  In this mode, the state is root mode as well.                */
/* For This project, the (optional) place for that #define is in the          */
/* Options.h file.                                                            */

#define LEN_EOS -1 /* "length" that says data is a null-terminated string.    */
#define CONSOLE_NOCHAR -1 /* Console_getc() flag for no char                  */
#define CONSOLE_GETC_WAIT true /* Console_getc wait for char (blocking)       */
#define CONSOLE_GETC_NOWAIT false /* Console_getc don't wait for char         */

typedef enum { /* Console Queue Flags */
   CONSOLEIO_FLAGS_COLLECTING = 0,
   CONSOLEIO_FLAGS_DISCONNECT,
   CONSOLEIO_FLAGS_CONNECT,
   CONSOLEIO_FLAGS_TIMEOUT,
   CONSOLEIO_FLAGS_DATA,
} CONSOLE_FLAGS;


extern uint8_t UART_RxChar    ;
extern int     RootMode       ;
extern int     Console_Script ;

/* The four system command descriptors */
extern char* cmd_cls_cmd      ;
extern char* cmd_cls_cmdsc    ;
extern char* cmd_cls_help     ;
extern char* cmd_help_cmd     ;
extern char* cmd_help_cmdsc   ;
extern char* cmd_help_help    ;
extern char* cmd_logout_cmd   ;
extern char* cmd_logout_cmdsc ;
extern char* cmd_logout_help  ;
extern char* cmd_reboot_cmd   ;
extern char* cmd_reboot_cmdsc ;
extern char* cmd_reboot_help  ;

/* The four system CLI commands */
extern int  Cmd_cls   (int, char**) ;
extern int  Cmd_help  (int, char**) ;
extern int  Cmd_logout(int, char**) ;
extern int  Cmd_reboot(int, char**) ;

extern void ConEthRxTask(void const*) ;
extern void ConsoleTask(void const*) ;
extern int  MyCLI_Register(char*,char*,char*,int (*cmd_routine)(int,char**)) ;
extern int  ParseLine(char*,int*,char**) ;

extern int  Console_printf(const char* format, ...) ;
extern void Console_puts(char*) ;
extern void Consoleio_purge(void) ;
extern int  Consoleio_kbhit(void) ;
extern int  Consoleio_getc(int) ;
extern int  Consoleio_gets(char*,int) ;

extern void Consoleio_write(uint8_t*,int) ;
extern int  Consoleio_read(uint8_t*,int,int) ;

extern void ConUARTRxComplete(void) ;
extern void ConUARTTxComplete(void) ;

#endif /* __CONSOLETASK_H */
