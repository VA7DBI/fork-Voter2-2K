#ifndef INC_UTILS_H_
#define INC_UTILS_H_

/* For ReadHex */
#define SOLOPARAM 0
#define JUSTDIGITS 1

typedef struct
{
   char* token   ; /* Token string to match     */
   char* shortcut; /* Token Shortcut (or NULL)  */
   int   tag     ; /* 0 reserved for no match!! */
} TOKENLIST;

typedef struct
{
   int inval  ; /* Interpolation in value  */
   int outval ; /* Interpolation out value */
} INTERPOLATE_PT;

int      parse_token (TOKENLIST*,char*,int*) ;
int      parse_num (char*,int,int,int*) ;
int32_t  parse_dnum (char*,int,int,int*,int) ;
uint32_t ReadHex (char*,int,int,int*) ;
uint32_t ReadHexVar (char*,int*) ;
void     strntcpy(char*,char*,int) ;
int      interpolate(int,INTERPOLATE_PT*,int) ;
void     stolower(char*) ;

#endif /* INC_UTILS_H_ */
