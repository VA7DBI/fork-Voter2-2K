#include "Options.h"

#include "VoiceFilter.h"

int16_t VoiceFilter_taps[VOICEFILTER_TAP_NUM] = {
  1827,
  -513,
  -521,
  -354,
  -368,
  -204,
  -211,
  -40,
  -39,
  133,
  127,
  277,
  241,
  340,
  248,
  287,
  134,
  117,
  -76,
  -114,
  -299,
  -304,
  -430,
  -356,
  -385,
  -212,
  -143,
  110,
  230,
  495,
  585,
  771,
  738,
  762,
  538,
  356,
  -69,
  -434,
  -1004,
  -1464,
  -2067,
  -2492,
  -2992,
  -3249,
  -3529,
  29240,
  -3529,
  -3249,
  -2992,
  -2492,
  -2067,
  -1464,
  -1004,
  -434,
  -69,
  356,
  538,
  762,
  738,
  771,
  585,
  495,
  230,
  110,
  -143,
  -212,
  -385,
  -356,
  -430,
  -304,
  -299,
  -114,
  -76,
  117,
  134,
  287,
  248,
  340,
  241,
  277,
  127,
  133,
  -39,
  -40,
  -211,
  -204,
  -368,
  -354,
  -521,
  -513,
  1827
};

#if 0
void VoiceFilter_init(VoiceFilterFilter* f) {
  int i;
  for(i = 0; i < VOICEFILTER_TAP_NUM; ++i)
    f->history[i] = 0;
  f->last_index = 0;
}

void VoiceFilter_put(VoiceFilter* f, int16_t input) {
  f->history[f->last_index++] = input;
  if(f->last_index == VOICEFILTER_TAP_NUM)
    f->last_index = 0;
}

int16_t VoiceFilter_get(VoiceFilter* f) {
  int32_t acc = 0;
  int index = f->last_index, i;
  for(i = 0; i < VOICEFILTER_TAP_NUM; ++i) {
    index = index != 0 ? index-1 : VOICEFILTER_TAP_NUM-1;
    acc += (int32_t)f->history[index] * VoiceFilter_taps[i];
  };
  return acc >> 16;
}
#endif
