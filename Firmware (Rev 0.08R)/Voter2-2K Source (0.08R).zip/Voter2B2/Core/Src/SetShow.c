/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Set/Show file.  It is in charge changing and showing various   */
/* system settings for the Voter2.  This is all via the set and show CLI      */
/* commands.                                                                  */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_set - Change settings CLI command                                   */
/*  - Cmd_show - Show settings CLI command                                    */
/*                                                                            */
/******************************************************************************/
// TO DO:
// More error checking on SetNum?

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>

#include "lwip.h"

#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "Settings.h"
#include "Utils.h"
#include "DialTaskOut.h"
#include "EthernetTask.h"
#include "Logger2rt.h"
#include "LocalMode.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "Setshow.h"
#include "SPINOR.h"
#include "Debugging.h"
#include "Vcxo.h"

#ifdef LOCALVOTER
#include "LocalVoter/LocalSettings.h"
#endif
#ifndef NODIALTASK
#include "DIALSettings.h"
#endif

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern RNG_HandleTypeDef hrng ;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
/* Right now no on/off commands to show, but rather than deleting the code,   */
/* just #ifdefing it out to avoid compiler complaints as I'll likely need it  */
/* later.                                                                     */
//#define SHOWONOF

enum
{
   CMD_OOPS = 0,
   CMD_MYSTATICIP,
   CMD_MYSTATICSUBNET,
   CMD_MYSTATICGATEWAY,
   CMD_MYSTATICDNS,
   CMD_MYSERIALNUM,
   CMD_MYIPMODE,
   CMD_ETHERNET,
   CMD_MYHWREV,
   CMD_GUESTPASSWORD,
   CMD_ROOTPASSWORD,
   CMD_LOGGING,
   CMD_CREDITS,
   CMD_GPSDEV,
   CMD_GPSBAUD,
   CMD_GPSEDGE,
   CMD_PROBE,
   CMD_S2NPORT,
   CMD_S2NPTIME,
   CMD_RXMODE,
   CMD_RSSIMODE,
   CMD_RXCAL,
   CMD_VCXOV,
   CMD_MYNAME,
   CMD_FLAGS,
   CMD_DLOGGER,
   CMD_TFTPADDR,
#ifndef NODIALTASK
   CMD_DIAL,
#endif
#ifdef LOCALVOTER
   CMD_LOCAL,
#endif
   CMD_ERRLOG,
   CMD_ALL, /* Should be the last one */
} SETSHOW_ENUMS ;

enum
{
   LOG_BOOT = 1,
   LOG_MAINAPP,
   LOG_ETHAPP,
   LOG_ETHLL_IO,
   LOG_KSZ8081,
   LOG_CONSOLE,
   LOG_I2C,
   LOG_DIALTASK,
   LOG_GPSCODE,
   LOG_LOGTELNET,
   LOG_LOCAL,
   LOG_SER2NET,
   LOG_SPINOR,
   LOG_SPIMTR,
   LOG_TFTP,
   LOG_VCXO
} LOGGERBLOCK_ENUMS ;

enum
{
   GPS_LIV4F = 0,
   GPS_M8N
} GPSDEV_ENUMS ;

#define LINE_SIZE 6 /* Console input line length */

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
uint8_t AnalogProbe = PROBE_NONE ;


/* A few of these parameter tables are needed elsewhere, so not local-only    */
TOKENLIST Booleans[] =
{
   {"off"  ,"0", false},
   {"on"   ,"1", true },
   {"false",NULL,false},
   {"true" ,NULL,true },
   {NULL   ,NULL,0    }
} ;

TOKENLIST GPS_Edges[] =
{
   {"falling","fal",GPS_1PPS_FALLING},
   {"rising" ,"ris",GPS_1PPS_RISING },
   {NULL     ,NULL,0                }
} ;

TOKENLIST MyIPModes[] =
{
   {"static",NULL,MYIPMODE_STATIC},
   {"dhcp"  ,NULL,MYIPMODE_DHCP  },
   {NULL    ,NULL,0              }
} ;

TOKENLIST RxModes[] =
{
   {"off"     ,NULL,RXMODE_OFF   },
   {"cor"     ,NULL,RXMODE_COR   },
   {"ctcss"   ,"ctc",RXMODE_CTCSS},
   {"corctcss","cct",RXMODE_BOTH },
   {"on"      ,NULL,RXMODE_ON    },
   {NULL      ,NULL,0            }
} ;

TOKENLIST RssiModes[] =
{
   {"analog" ,"ana",RSSI_ANALOG},
   {"hpf"    ,NULL ,RSSI_HPF   },
   {"bew1"   ,NULL ,RSSI_BEW1  },
   {"bew2"   ,NULL ,RSSI_BEW2  },
   {NULL     ,NULL ,0          }
} ;

/******************************************************************************/
/* IMPORTANT!!!  ErrLog[] below is *NOT* initialized to 0 on boot!!  This is  */
/* on purpose, I want to preserve counter values across reboots--and indeed   */
/* even across power cycles if a battery is installed.                        */
/******************************************************************************/
uint8_t ErrLog[ERRLOGENTRIES] IN_BBSRAM ;

DLOGGER_STRUCT DLogger_Data[NDLOGGERIDS] = {0} ;


char* cmd_set_cmd    = "set" ;
char* cmd_set_cmdsc  = "set" ;
char* cmd_show_cmd   = "show" ;
char* cmd_show_cmdsc = "show" ;
char* cmd_ss_help    = "set/show - setting [value] Change/show Voter2 setting\n"
                       " ============= - NETWORK SETTINGS ======================\n"
                       "    mystaticip (msi) - Voter2 IP address (if static)\n"
                       "    mystaticsn (msn) - Voter2 Subnet (if static)\n"
                       "    mystaticgw (msg) - Voter2 Gateway IP (if static)\n"
                       "   mystaticdns (msd) - Voter2 DNS Address (if static)\n"
                       "      myipmode (mim) - Voter2 IP acquisition mode\n"
                       "      ethernet (eth) - Voter2 IP summary (show only)\n"
                       "      tftpaddr (tad) - TFTP server address\n"
                       "   myserialnum (msn) - Voter2 serial number (show only)\n"
                       "       myhwrev (mhw) - Voter2 Hardware Revision (show only)\n"
                       "       s2nport (s2p) - Ser2Net IP Port\n"
                       "      s2nptime (s2p) - Ser2Net Rx Poll time (ms)\n"
                       "      guestpwd (gpw) - Guest login password\n"
                       "       rootpwd (rpw) - Root login password\n"
                       " ============= - DIAL, LOCAL, GPS AND MISC SETTINGS ====\n"
#ifndef NODIALTASK
                       "          dial (dia) - [param value] DIAL server settings\n"
#endif
#ifdef LOCALVOTER
                       "         local (loc) - [param value] local mode settings\n"
#endif
                       "        gpsdev (gdv) - GPS params by device\n"
                       "       gpsbaud (gbd) - GPS interface baud rate\n"
                       "       gpsedge (ged) - GPS interface 1PPS edge (rising/falling)\n"
                       "        rxmode (rxm) - Receive active mode\n"
                       "      rssimode (rsm) - RSSI detect mode\n"
                       "         rxcal (rxc) - RSSI calibration\n"
                       "       vcxoval (vcv) - VCXO Calibration value\n"
                       "       logging (log) - [block value] Debugging logger level\n"
                       "         probe (prb) - Analog probe source\n"
                       "         flags (flg) - Debug flags\n"
                       "       dlogger (dlg) - Data logger\n"
                       "       errlogs (erl) - Error logs\n"
                       "        myname (mnm) - Voters command prompt name\n"
                       "       credits (crd) - Project credits\n"
                       "           all (all) - All params (show only)\n" ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST SSCmds[] =
{
   {"mystaticip"   ,"msi",CMD_MYSTATICIP     },
   {"mystaticsn"   ,"mss",CMD_MYSTATICSUBNET },
   {"mystaticgw"   ,"msg",CMD_MYSTATICGATEWAY},
   {"mystaticdns"  ,"msd",CMD_MYSTATICDNS    },
#ifdef LOCALVOTER
   {"local"        ,"loc",CMD_LOCAL          },
#endif
#ifndef NODIALTASK
   {"dial"         ,"dia",CMD_DIAL           },
#endif
   {"tftpaddr"     ,"tad",CMD_TFTPADDR       },
   {"gpsdev"       ,"gdv",CMD_GPSDEV         },
   {"gpsbaud"      ,"gbd",CMD_GPSBAUD        },
   {"gpsedge"      ,"ged",CMD_GPSEDGE        },
   {"myipmode"     ,"mim",CMD_MYIPMODE       },
   {"ethernet"     ,"eth",CMD_ETHERNET       },
   {"myserialnum"  ,"msn",CMD_MYSERIALNUM    },
   {"myhwrev"      ,"mhw",CMD_MYHWREV        },
   {"guestpwd"     ,"gpw",CMD_GUESTPASSWORD  },
   {"rootpwd"      ,"rpw",CMD_ROOTPASSWORD   },
   {"logging"      ,"log",CMD_LOGGING        },
   {"probe"        ,"prb",CMD_PROBE          },
   {"s2nport"      ,"s2p",CMD_S2NPORT        },
   {"s2nptime"     ,"s2t",CMD_S2NPTIME       },
   {"credits"      ,"crd",CMD_CREDITS        },
   {"rxmode"       ,"rxm",CMD_RXMODE         },
   {"rssimode"     ,"rsm",CMD_RSSIMODE       },
   {"rxcal"        ,"rxc",CMD_RXCAL          },
   {"vcxoval"      ,"vcv",CMD_VCXOV          },
   {"myname"       ,"mnm",CMD_MYNAME         },
   {"flags"        ,"flg",CMD_FLAGS          },
   {"dlogger"      ,"dlg",CMD_DLOGGER        },
   {"errlogs"      ,"erl",CMD_ERRLOG         },
   {"all"          ,NULL ,CMD_ALL            }, /* Keep this one last */
   {NULL           ,NULL ,0                  }
} ;

static TOKENLIST LoggerBlocks[] =
{
   {"boot",   NULL,LOG_BOOT     },
   {"mainapp",NULL,LOG_MAINAPP  },
   {"ethapp", NULL,LOG_ETHAPP   },
   {"ethlwip",NULL,LOG_ETHLL_IO },
   {"ksz8081",NULL,LOG_KSZ8081  },
   {"console",NULL,LOG_CONSOLE  },
   {"i2c",    NULL,LOG_I2C      },
   {"dial",   NULL,LOG_DIALTASK },
   {"gps",    NULL,LOG_GPSCODE  },
   {"telnet", NULL,LOG_LOGTELNET},
   {"local",  NULL,LOG_LOCAL    },
   {"ser2net",NULL,LOG_SER2NET  },
   {"spinor" ,NULL,LOG_SPINOR   },
   {"spimtr" ,NULL,LOG_SPIMTR   },
   {"tftp"   ,NULL,LOG_TFTP     },
   {"vcxo"   ,NULL,LOG_VCXO     },
   {NULL     ,NULL,0            }
} ;

static TOKENLIST LoggerLevels[] =
{
   {"none"   ,"non",LOG_NONE   },
   {"major"  ,"maj",LOG_MAJOR  },
   {"support","sup",LOG_SUPPORT},
   {"io"     ,NULL ,LOG_REGIO  },
   {NULL     ,NULL ,0          }
};

static TOKENLIST Probes[] =
{
   {"none"    ,NULL,PROBE_NONE   },
   {"rxin"    ,NULL,PROBE_RXIN   },
   {"rxdem"   ,NULL,PROBE_RXDEM  },
   {"rxvoice" ,NULL,PROBE_RXVOICE},
   {"txsrc"   ,NULL,PROBE_TXSRC  },
   {"txpl"    ,NULL,PROBE_TXPL   },
   {"txtone"  ,NULL,PROBE_TXTONE },
   {"txout"   ,NULL,PROBE_TXOUT  },
   {"rsssig"  ,NULL,PROBE_RSSSIG },
   {"rsslvl"  ,NULL,PROBE_RSSLVL },
   {NULL      ,NULL,0            }
} ;

static TOKENLIST GPS_Devices[] =
{
   {"liv4f" ,NULL,GPS_LIV4F},
   {"m8n"   ,NULL,GPS_M8N  },
   {NULL    ,NULL,0        }
} ;

/* WARNING! If you mess with SETSHOW_ENUMS, keep this in sync with it!! */
static char* HelpTopics[] =
   {/* CMD_OOPS            */ "N/A\n",
    /* CMD_MYSTATICIP      */ "mystaticip [ipaddr] - Voter2 IP address (if myipmode is static)\n",
    /* CMD_MYSTATICSUBNET  */ "mystaticsn [ipaddr] - Voter2 subnet (if myipmode is static)\n",
    /* CMD_MYSTATICGATEWAY */ "mystaticgw [ipaddr] - Voter2 gateway address (if myipmode is static)\n",
    /* CMD_MYSTATICDNS     */ "mystaticdn [ipaddr] - Voter2 DNS address (if myipmode is static)\n",
    /* CMD_MYIPMODE        */ "myipmode [static | dhcp] The Voter2s local IP acquisition mode\n",
    /* CMD_ETHERNET        */ "ethernet - Show summery of Ethnernet settings (show only)\n",
    /* CMD_MYSERIALNUM     */ "myserialnum - Show thus Voter2s serial number (show only)\n",
    /* CMD_MYHWREV         */ "myhwrev - Show this Voter2s hardware revision (show only)\n",
    /* CMD_GUESTPASSWORD   */ "guestpwd [password] - The guest login password (15 characters max)\n",
    /* CMD_ROOTPASSWORD    */ "rootpwd [password] - The root login password (15 characters max)\n",
    /* CMD_LOGGING         */ "logging [block value ] - Enable debug logging by block.  Blocks are:\n"
                              " -    boot : Boot process\n"
                              " - mainapp : Main sequencer\n"
                              " -  ethapp : Ethernet sequencer\n"
                              " - ethlwip : LwIP diagnostics\n"
                              " - ksz8081 : Ethernet PHY diagnostics\n"
                              " - console : Console interface\n"
                              " -     i2c : I2C interface\n"
                              " -    dial : DIAL interface\n"
                              " -     gps : GPS interface\n"
                              " -  telnet : telnet interface\n"
                              " -   local : Local repeater mode sequencer\n"
                              " - ser2net : RFC2217 interface to the repeater\n"
                              " -  spinor : SPI Nor drivers\n"
                              " -  spimtr : MTR2000 SPI interface\n"
                              " -    tftp : TFTP driver\n\n"
                              " -    vcxo : VCXO driver\n\n"
                              " Values for logging information are:\n"
                              " -    none : Logging disabled (for that block)\n"
                              " -   major : Major events (mainly serious errors)\n"
                              " - support : More detailed logging (not just erors)\n"
                              " -      io : very low level io\n",
    /* CMD_CREDITS         */ "credits - Giving credit where it is due! (show only)\n",
    /* CMD_GPSDEV          */ "gpsdev [liv4f|m8n] - The GPS baud and active edge by module\n",
    /* CMD_GPSBAUD         */ "gpsbaud [baudrate] - GPS interface baud rate\n",
    /* CMD_GPSEDGE         */ "gpsedge [rising | falling] - GPS 1PPS active edge\n",
    /* CMD_PROBE           */ "probe [point] - Sets the internal analog probe output.  Points are:\n"
                              " -    none : Probe disabeld\n"
                              " -    rxin : Raw value from ADC input\n"
                              " -   rxdem : Post de-emphasis\n"
                              " - rxvoice : Post voiceband filter\n"
                              " -   txsrc : As delivered by the DIAL server (post decompression)\n"
                              " -    txpl : After CTCSS adder (if enabled)\n"
                              " -  txtone : After Test Tone adder (if enabled)\n"
                              " -   txout : As sent to the DAC\n"
                              " -  rsssig : High-pass signal used to determine above-band RSSI value\n"
                              " -  rsslvl : RSSI value (not audio, analog representation of RSSI)\n",
    /* CMD_S2NPORT         */ "s2nport [portnum] - MTR2000 serial interface IP port (default is 2000)\n",
    /* CMD_S2NPTIME        */ "s2nptime [ms] - MTR2000 serial port IP polling time (default is 100ms)\n",
    /* CMD_RXMODE          */ "rxmode [off|cor|ctcss|corctcss|on] - Sets what conditions make for a\n"
                              "valid Rx (and gets retransmitted)\n"
                              "Valid modes are:\n"
                              " -      off : Nothing (Rx will never be valid)\n"
                              " -      cor : Only a valid MTR2000 COR signal triggers Rx\n"
                              " -    ctcss : Only a valid MTR2000 CTCSS signal triggers Rx\n"
                              " - corctcss : Both COR and CTCSS must be valid to trigger Rx\n"
                              " -       on : Rx always valid (!!!) for testing. Tx timeout is disabled\n",
    /* CMD_RSSIMODE        */ "rssimode [analog|hpf] - RSSI value source.  Source are:\n"
                              " - analog - MTR2000 RSSI signal pin\n"
                              " - hpf - Upper band noise level (similar to Voter/RTCM)\n"
                              "   This is still being fine tuned\n",
    /* CMD_RXCAL           */ "rxcal - RSSI calibration process.\n",
    /* CMD_VCXOV           */ "vcxoval - VCXO Calibration value.\n",
    /* CMD_MYNAME          */ "myname [name] - Optional name to put in front of the command prompt.\n"
                              "   Handy if you have many Voter2s and need a reminder which one you\n"
                              "   are logged in to.",
    /* CMD_FLAGS           */ "flags [flagnum value] - For debugging purposes.  These are eight\n"
                              "   flags that can be set by the user or internally.  Their use will\n"
                              "   change over time, only use if asked to do so by a developer.\n",
    /* CMD_DLOGGER         */ "dlogger [no params] - The Voter2 has an internal data logger for\n"
                              "   real-time debugging.  Error codes and timestamps are stored in a\n"
                              "   FIFO buffer.  The meanings of the codes will vary between\n"
                              "   firmware releases as needs arise.  This is for developers only.\n"
                              "  - show dlogger shows the contents of the data logger FIFO.\n"
                              "  - set dlogger clears out the data logger\n",
    /* CMD_TFTPADDR        */ "tfptaddr [ipaddr] - Sets the IP address for the TFTP server\n",
#ifndef NODIALTASK
    /* CMD_DIAL            */ "Sets/shows parameters for the DIAL (ASL) communications\n"
                              " - Enter 'show dial' to see all the parameters\n"
                              " - Enter 'help show dial [param]' for details on a specific parameter\n",
#endif
#ifdef LOCALVOTER
    /* CMD_LOCAL           */ "Sets/shows parameters for the local repeater functions\n"
                               " - Enter 'show local' to see all the parameters\n"
                               " - Enter 'help show local [param]' for a specific parameter\n",
#endif
    /* CMD_ERRLOG          */ "errlogs [no params] - The Voter2 has an internal error accumulator\n"
                               "   for rare errors. There is an array of error counters. The meaning\n"
                               "   of the codes will vary between firmware releases as needs arise.\n"
                               "   This is for developers only.\n"
                               "  - show errlogs shows the contents of the error loggers.\n"
                               "  - set errlogs clears out the error logger\n",
    /* CMD_ALL             */  "all - Shows all the show commands\n" /* Should be the last one */
   } ;

static uint8_t OTPdata[16] IN_DMADD2 = {0} ;  /* The data to program in OTP */
static int DLogger_Index = 0 ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/
static void ShowNum    (char*,uint32_t) ;
static void ShowList   (char*,uint8_t,TOKENLIST*) ;
#ifdef SHOWONOF
static void ShowOnOff  (char*,uint8_t ) ;
#endif
static void ShowHwRev  (void          ) ;
static void ShowStr    (char*,char*   ) ;
static void ShowCreds  (void          ) ;
static void ShowLogs   (void          ) ;
static void ShowFlags  (void          ) ;
static void ShowDLogger(void          ) ;
static void ShowErrLogs(void          ) ;
static void ShowAllEth (void          ) ;
static void ShowRxCal  (void          ) ;

static void SetLog    (int,char**) ;
static void SetGpsDev (int,char**) ;
static void SetFlags  (int,char**) ;
static void SetDLogger(int,char**) ;
static void SetErrLogs(int,char**) ;
static void SetOTP    (int,char**) ;
static void SetRxCal  (void      ) ;
static void SetVcxoV  (int,char**) ;
static void ProgramOTP(uint32_t,uint8_t,uint8_t) ;

/*******************************************************************************
* Routine  : Cmd_set
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command sets a parameter.
*******************************************************************************/
int Cmd_set(int argc, char* argv[])
{
   int     error = false ; /* Parsing error flag */
   int     Token = 0     ; /* Command token      */
   int32_t tmp   = 0     ; /* Temporary value    */

   /* See which settings command */
   stolower(argv[1]) ; /* To lower case first */
   Token = parse_token(SSCmds,argv[1],&error) ;

   if (error)
   {
      Console_printf("Not a recognized parameter, try help set.\n") ;
   }
   else
   {
      /* If a not a list command, then it needs a parameter. (List commands   */
      /* will list the parameters if no parameter is given)                   */
      /* Also a few set command have no command line parameter.               */
      if ((argc<3) && ((Token!=CMD_MYIPMODE)&&(Token!=CMD_GPSEDGE)&&(Token!=CMD_PROBE)&&(Token!=CMD_ERRLOG)&&(Token!=CMD_DLOGGER)&&
                       (Token!=CMD_ETHERNET)&&(Token!=CMD_MYHWREV)&&(Token!=CMD_RXCAL)&&(Token!=CMD_ALL)&&(Token!=CMD_VCXOV)    ))
      {
         Console_printf("Missing setting for the parameter\n") ;
      }
      else
      {
          /* Take care of a few special cases first... */
         if (!RootMode && ((CMD_GUESTPASSWORD==Token)||(CMD_ROOTPASSWORD==Token)))
         {
            Console_printf("Sorry, not accessible with guest login.\n") ;
            Token = 0 ; /* so it won't get processed */
         }

         switch(Token)
         {
            case CMD_MYSTATICIP     : SetIP     ("Voter2 IP Address:"               ,argv[2],                   &Settings.My_StaticIP                  ) ; break ;
            case CMD_MYSTATICSUBNET : SetIP     ("Voter2 Subnet:"                   ,argv[2],                   &Settings.My_StaticSubnet              ) ; break ;
            case CMD_MYSTATICGATEWAY: SetIP     ("Voter2 Gateway IP:"               ,argv[2],                   &Settings.My_StaticGateway             ) ; break ;
            case CMD_MYSTATICDNS    : SetIP     ("Voter2 DNS:"                      ,argv[2],                   &Settings.My_StaticDNS                 ) ; break ;
            case CMD_ETHERNET       : SetNot    ()                                                                                                       ; break ;
            case CMD_TFTPADDR       : SetIP     ("TFTP Server Address:"             ,argv[2],                   &Settings.TFTP_Addr                    ) ; break ;
            case CMD_GPSBAUD        : tmp = Settings.GPS_Baud ;
                                      SetNum    ("GPS Baud rate:"                   ,argv[2],2400,115200,&tmp) ; Settings.GPS_Baud    = tmp              ; break ;
#ifdef LOCALVOTER
            case CMD_LOCAL          : SetLocal  (argc,argv)                                                                                              ; break ;
#endif
#ifndef NODIALTASK
            case CMD_DIAL           : SetDIAL   (argc,argv)                                                                                              ; break ;
#endif
            case CMD_MYSERIALNUM    : SetOTP    (argc,argv)                                                                                              ; break ;
            case CMD_MYHWREV        : SetNot    ()                                                                                                       ; break ;
            case CMD_MYIPMODE       : SetList   ("Voter2 IP Acquisition mode:"      ,argv[2],                   &Settings.My_IPMode,MyIPModes,true     ) ; break ;
            case CMD_GUESTPASSWORD  : SetStr    ("Guest Login Password:"            ,argv[2],                    Settings.Guest_Password ,SETTINGS_PASSWORD_LEN ) ; break ;
            case CMD_ROOTPASSWORD   : SetStr    ("Root Login Password:"             ,argv[2],                    Settings.Root_Password  ,SETTINGS_PASSWORD_LEN ) ; break ;
            case CMD_MYNAME         : SetStr    ("Voters name (for CLI):"           ,argv[2],                    Settings.Voter_Name     ,SETTINGS_NAME_LEN     ) ; break ;
            case CMD_LOGGING        : SetLog    (argc,argv)                                                                                              ; break ;
            case CMD_CREDITS        : SetNot    ()                                                                                                       ; break ;
            case CMD_GPSEDGE        : SetList   ("GPS 1PPS active edge:"            ,argv[2],                   &Settings.GPS_PPSEdge,GPS_Edges,true   ) ; break ;
            case CMD_GPSDEV         : SetGpsDev (argc,argv)                                                                                              ; break ;
            case CMD_PROBE          : SetList   ("Analog Probe Source:"             ,argv[2],                   &AnalogProbe,Probes,false              ) ; break ;
            case CMD_S2NPORT        : tmp = Settings.S2N_Port ;
                                      SetNum    ("Ser2Net IP Port:"                 ,argv[2],1,65535,&tmp)     ; Settings.S2N_Port = tmp                 ; break ;
            case CMD_S2NPTIME       : tmp = Settings.S2N_PollTime ;
                                      SetNum    ("Ser2Net Rx Poll time (ms):"       ,argv[2],1,1000,&tmp)      ; Settings.S2N_PollTime = tmp             ; break ;
            case CMD_RXMODE         : SetList   ("Rx Detect:"                       ,argv[2],                   &Settings.RxMode,RxModes,true          ) ; break ;
            case CMD_RSSIMODE       : SetList   ("RSSI Method:"                     ,argv[2],                   &Settings.RssiMode,RssiModes,true      ) ; break ;
            case CMD_RXCAL          : SetRxCal  ()                                                                                                       ; break ;
            case CMD_VCXOV          : SetVcxoV  (argc,argv)                                                                                              ; break ;
            case CMD_FLAGS          : SetFlags  (argc,argv)                                                                                              ; break ;
            case CMD_DLOGGER        : SetDLogger(argc,argv)                                                                                              ; break ;
            case CMD_ERRLOG         : SetErrLogs(argc,argv)                                                                                              ; break ;
            case CMD_ALL            : SetNot    ()                                                                                                       ; break ;
            default                 : /* Unsupported tokens */                                                                                             break ;
         }

         /* Take care of a few post-setting notices too... */
         if ((CMD_MYSTATICIP   ==Token) || (CMD_MYSTATICSUBNET==Token) || (CMD_MYSTATICGATEWAY==Token) ||
             (CMD_MYIPMODE     ==Token) ||
             (CMD_GPSBAUD      ==Token) || (CMD_GPSEDGE       ==Token) || (CMD_S2NPORT        ==Token) ||
             (CMD_GPSDEV       ==Token) || (CMD_S2NPORT       ==Token)
            )
         {
            Console_printf("The parameter you just changed requires a reboot to take effect.\n") ;
            Console_printf("Saving settings first would be a good idea too.") ;
            Console_printf("Unsaved changes are lost on reboot! :)\n") ;
         }
      }
   }
   return (0) ;
}

/*******************************************************************************
* Routine  : Cmd_show
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command shows a parameter
*******************************************************************************/
int Cmd_show(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag    */
   int Token  = 0    ; /* Command token (users) */
   int Token2 = 0    ; /* Command token (shown) */

   /* See which settings command */
   stolower(argv[1]) ; /* To lower case first */
   Token = parse_token(SSCmds,argv[1],&error) ;

   if (error)
   {
      Console_printf("Not a recognized parameter, try help show.\n") ;
   }
   else
   {
      /* Fancy conditionals to show just one parameter unless the token is    */
      /* "all".  If "all", show all parameters.                               */
      for (Token2=(CMD_ALL==Token)?CMD_MYSTATICIP:Token ; Token2<((CMD_ALL==Token)?CMD_ALL:Token+1) ; Token2++)
      {
         /* Take care of a few special cases first... */
         if (!RootMode && ((CMD_GUESTPASSWORD==Token2)||(CMD_ROOTPASSWORD==Token2)))
         {
            Console_printf("Sorry, not accessible with guest login.\n") ;
            Token2 = 0 ; /* so it won't get processed */
         }

         switch(Token2)
         {
            case CMD_MYSTATICIP     : ShowIP     ("Voter2 IP Address:"               ,Settings.My_StaticIP     ) ; break ;
            case CMD_MYSTATICSUBNET : ShowIP     ("Voter2 Subnet:"                   ,Settings.My_StaticSubnet ) ; break ;
            case CMD_MYSTATICGATEWAY: ShowIP     ("Voter2 Gateway IP:"               ,Settings.My_StaticGateway) ; break ;
            case CMD_MYSTATICDNS    : ShowIP     ("Voter2 DNS:"                      ,Settings.My_StaticDNS    ) ; break ;
            case CMD_ETHERNET       : ShowAllEth (                                                             ) ; break ;
            case CMD_TFTPADDR       : ShowIP     ("TFTP Server Adddress:"            ,Settings.TFTP_Addr       ) ; break ;
            case CMD_GPSBAUD        : ShowNum    ("GPS Receiver baud rate:"          ,Settings.GPS_Baud        ) ; break ;
#ifdef LOCALVOTER
            case CMD_LOCAL          : ShowLocal  (                                                             ) ; break ;
#endif
#ifndef NODIALTASK
            case CMD_DIAL           : ShowDIAL   (                                                             ) ; break ;
#endif
            case CMD_MYSERIALNUM    : ShowNum    ("Voter2 serial number:"            ,Settings.MySerialNum     ) ; break ;
            case CMD_MYHWREV        : ShowHwRev  (                                                             ) ; break ;
            case CMD_MYIPMODE       : ShowList   ("Voter2 IP acquisition mode:"      ,Settings.My_IPMode,MyIPModes) ; break ;
            case CMD_GUESTPASSWORD  : ShowStr    ("Guest Login Password:"            ,Settings.Guest_Password  ) ; break ;
            case CMD_ROOTPASSWORD   : ShowStr    ("Root Login Password:"             ,Settings.Root_Password   ) ; break ;
            case CMD_MYNAME         : ShowStr    ("Voters name (for CLI):"           ,Settings.Voter_Name      ) ; break ;
            case CMD_LOGGING        : ShowLogs   (                                                             ) ; break ;
            case CMD_CREDITS        : ShowCreds  (                                                             ) ; break ;
            case CMD_GPSEDGE        : ShowList   ("GPS 1PPS active edge:"            ,Settings.GPS_PPSEdge,GPS_Edges) ; break ;
            case CMD_PROBE          : ShowList   ("Analog Probe Source:"             ,AnalogProbe,Probes       ) ; break ;
            case CMD_S2NPORT        : ShowNum    ("Ser2Net IP Port:"                 ,Settings.S2N_Port        ) ; break ;
            case CMD_S2NPTIME       : ShowNum    ("Ser2Net Rx Poll Time (ms):"       ,Settings.S2N_PollTime    ) ; break ;
            case CMD_GPSDEV         : Console_printf("See gpsbaud and gpsedge\n"                               ) ; break ;
            case CMD_RXMODE         : ShowList   ("Rx Detect Mode:"                  ,Settings.RxMode,RxModes  ) ; break ;
            case CMD_RSSIMODE       : ShowList   ("RSSI Method:"                     ,Settings.RssiMode,RssiModes) ; break ;
            case CMD_RXCAL          : ShowRxCal  ()                                                              ; break ;
            case CMD_VCXOV          : ShowNum    ("VCXO Calibration Value:"          ,Settings.Vcxo_DACval     ) ; break ;
            case CMD_FLAGS          : ShowFlags  (                                                             ) ; break ;
            case CMD_DLOGGER        : ShowDLogger(                                                             ) ; break ;
            case CMD_ERRLOG         : ShowErrLogs(                                                             ) ; break ;
            default                 : /* Shouldn't happen */                                                       break ;
         }
      }
   }
   return (0) ;
}

/*******************************************************************************
* Routine  : Show(...)
*   Inputs : id - parameter identifier
*          : (varies) - The variable to show
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* These are the commands to show the various parameter types
*******************************************************************************/
void ShowIP(char*id,uint32_t IPAddr)
{
   Console_printf("%s %d.%d.%d.%d\n",id,IPAddr>>24,(IPAddr>>16)&0xff,(IPAddr>>8)&0xff,(IPAddr)&0xff) ;
}

static void ShowNum(char*id,uint32_t Num)
{
   Console_printf("%s %u\n",id,Num) ;
}

static void ShowList(char*id,uint8_t entry,TOKENLIST* Tokens)
{
   Console_printf("%s %s\n",id,Tokens[entry].token) ;
}

#ifdef SHOWONOF
static void ShowOnOff(char*id,uint8_t token)
{
   Console_printf("%s %s\n",id,token?"On":"Off") ;
}
#endif

static void ShowHwRev(void)
{
   Console_printf("Voter2 Hardware Revision: %d.%2.2d\n",Settings.MyHwRev>>8,Settings.MyHwRev&0xff) ;
}

static void ShowStr(char*id,char* str)
{
   /* THIS ASSUMES A NULL TERMINATED STRING! */
   Console_printf("%s %s\n",id,str) ;
}

static void ShowCreds(void)
{
   /* THIS ASSUMES A NULL TERMINATED STRING! */
   Console_printf("Voter2-2K Rev 1.10\n") ;
   Console_printf("====================\n") ;
   Console_printf("Sponsored by:\n") ;
   Console_printf("Wayne (W0ARP)\n") ;
   Console_printf("Colorado Connection (colcon.org)\n") ;
   Console_printf("Rocky Mountain Ham (rmham.org)\n") ;
   Console_printf("====================\n") ;
   Console_printf("Design team:\n") ;
   Console_printf("  Ben (KC2VJW)\n") ;
   Console_printf(" Dave (WA1JHK)\n") ;
   Console_printf(" Doug (K2AD)\n") ;
   Console_printf("James (KI0KN)\n") ;
   Console_printf(" Jeff (K0JSC)\n") ;
   Console_printf(" Mark (N7CTM)\n") ;
   Console_printf(" Will (N0XGA)\n") ;
   Console_printf("====================\n") ;
   Console_printf("Open Source Hardware\n") ;
   Console_printf("Open Source Software\n") ;
   Console_printf("====================\n") ;
}

static void ShowLogs (void)
{
   /* For showing logging levels, just show them all */
   Console_printf("%7s: %s\n",LoggerBlocks[ 0].token,LoggerLevels[Logger.Boot   ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 1].token,LoggerLevels[Logger.MainApp].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 2].token,LoggerLevels[Logger.EthApp ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 3].token,LoggerLevels[Logger.EthLWIP].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 4].token,LoggerLevels[Logger.KSZ8081].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 5].token,LoggerLevels[Logger.Console].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 6].token,LoggerLevels[Logger.i2c    ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 7].token,LoggerLevels[Logger.Dial   ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 8].token,LoggerLevels[Logger.GPS    ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[ 9].token,LoggerLevels[Logger.LogTel ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[10].token,LoggerLevels[Logger.Local  ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[11].token,LoggerLevels[Logger.Ser2Net].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[12].token,LoggerLevels[Logger.SpiNor ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[13].token,LoggerLevels[Logger.SpiMtr ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[14].token,LoggerLevels[Logger.Tftp   ].token) ;
   Console_printf("%7s: %s\n",LoggerBlocks[15].token,LoggerLevels[Logger.Vcxo   ].token) ;
   Console_printf("Logging levels are none, major, support, and io.\n") ;
   Console_printf("Note that logging levels are not saved across reboots.\n") ;
}

static void ShowFlags (void)
{
   int i = 0 ;
   for (i=0;i<NDBFLAGS;i++)
   {
      Console_printf("Debug Flag %d = %d\n",i,DbFlags[i]) ;
   }
}

static void ShowErrLogs (void)
{
   int i = 0 ;
   int numbad = 0 ;

   for (i=0;i<ERRLOGENTRIES;i++)
   {
      if (0!=ErrLog[i])
      {
         Console_printf("Log[%2d]=%3d, ",i,ErrLog[i]) ;
         numbad++ ;
         if (numbad%6==5) Console_printf("\n") ;
      }
   }

   if (0==numbad)
   {
      Console_printf("All error log entries are zero!\n") ;
   }
   else if (i%6!=5) Console_printf("\n") ;
}

static void ShowDLogger (void)
{
   int i = 0 ;
   int j = 0 ;
   int GotOne = false ;
   uint32_t Now = 0 ;

   Now = HAL_GetTick() ;

   Console_printf("Current HAL Timestamp (s): %7d.%3.3d\n",Now/1000,Now%1000) ;

   /* Tricky bit here is to go from the current log entry backwards! */
   for (i=0;i<NDLOGGERIDS;i++)
   {
      j = (DLogger_Index - i - 1 + NDLOGGERIDS)%NDLOGGERIDS ;
      if (DLogger_Data[j].Event_ID)
      {
         if (!GotOne)
         {
            Console_printf("Timestamp(s)    Time Ago       ID   Data (dec) Data (hex)\n") ;
            Console_printf("============ =========== ========== ========== ==========\n") ;
            GotOne = true ;
         }
         Console_printf(" %7d.%3.3d %7d.%3.3d %10d %10d 0x%8.8x\n",
                        DLogger_Data[j].Event_Timestamp/1000,
                        DLogger_Data[j].Event_Timestamp%1000,
                        (Now-DLogger_Data[j].Event_Timestamp)/1000,
                        (Now-DLogger_Data[j].Event_Timestamp)%1000,
                        DLogger_Data[j].Event_ID,
                        DLogger_Data[j].Event_Data,
                        DLogger_Data[j].Event_Data
                       ) ;
      }
   }

   if (!GotOne)
   {
      Console_printf("No Events!\n") ;
   }
   else
   {
      Console_printf("Be aware that timestamps roll over every 49 days (~1,300,000 seconds).\n") ;
   }
}

static void ShowAllEth (void)
{
   Console_printf("Below is a summary of the user Ethernet settings--used or not.\n") ;
   ShowIP     (" - Voter2 Static IP Address :",Settings.My_StaticIP     ) ;
   ShowIP     (" -     Voter2 Static Subnet :",Settings.My_StaticSubnet ) ;
   ShowIP     (" - Voter2 Static Gateway IP :",Settings.My_StaticGateway) ;
   ShowIP     (" -        Voter2 Static DNS :",Settings.My_StaticDNS    ) ;
   ShowList   (" - Voter2 IP acquisition mode:",Settings.My_IPMode,MyIPModes) ;

  if (MYIPMODE_DHCP==Settings.My_IPMode)
  {
     Console_printf("*** Static settings are ignored in DHCP mode. ***\n") ;
  }

  Console_printf("Enter 'status ethernet' to see resolved addresses.\n") ;
}

/*******************************************************************************
* Routine  : Set(...)
*   Inputs : id - parameter identifier
*      IOs : (varies) - The variable to set
*  Returns : Nothing
*  Globals : None
*
* These are the commands to set the various parameter types
* Routines start off as static, then become extern as needed.
*******************************************************************************/
void SetIP(char*id, char* newval, uint32_t* IPAddr)
{
   ip_addr_t NewAddr = {0} ; /* IP address in LWIP format */
   uint32_t  Addr32  =  0  ; /* IP address in my format   */
   int       err     =  0  ; /* Error accumulator         */

   /* LWIP has a nice function to parse a text IP address */
   err = ipaddr_aton(newval,&NewAddr) ;

   if (!err)
   {
	   Console_printf("Invalid IP address\n") ;
   }
   else
   {
      /* Get the address from the LWIP struct and convert to host format */
      Addr32 = ntohl(NewAddr.addr) ;
      *IPAddr = Addr32 ;
      Console_printf("%s now %d.%d.%d.%d\n",id,Addr32>>24,(Addr32>>16)&0xff,(Addr32>>8)&0xff,(Addr32)&0xff) ;
      Settings.Dirty = true ;
   }
}

void SetNum(char*id, char* newval,int32_t min, int32_t max, int32_t* value)
{
   int32_t Val32 = 0     ; /* New value         */
   int     err   = false ; /* Error accumulator */

   /* Go get the number */
   Val32=parse_num(newval,min,max,&err) ;

   if (err)
   {
	   Console_printf("Invalid or out of range number, range is %d to %d.\n",min,max) ;
   }
   else
   {
      *value = Val32 ;
      Console_printf("%s now %u\n",id,Val32) ;
      Settings.Dirty = true ;
   }
}

/* This one is a bit weird!  It is scanning for a decimal number and returns  */
/* an integer values that is in millionths, so 1.0 will return 1,000,000.     */
/* I couuld and maybe should make this more generic.  If I ever need another  */
/* decimal parameter I will.                                                  */
void SetD6Num(char*id, char* newval,int32_t min, int32_t max, int32_t* value)
{
   int32_t Val32 = 0     ; /* New value (decimal)        */
   int     err   = false ; /* Error accumulator          */

   /* Go get the number with up to six digits after the decimal */
   Val32=parse_dnum(newval,min*1000000,max*1000000,&err,6) ;

   if (err)
   {
      Console_printf("Invalid or out of range number, range is %d to %d.\n",min,max) ;
   }
   else
   {
      *value = Val32 ;
      Console_printf("%s now %u.%6.6u\n",id,Val32/1000000,Val32%1000000) ;
      Settings.Dirty = true ;
   }
}

void SetList(char*id, char* newval, uint8_t* value,TOKENLIST* Tokens,int SetDirty)
{
   int8_t Token = 0     ; /* New value         */
   int    err   = false ; /* Error accumulator */
   int    i     = 0     ; /* index             */

   /* See which settings command */
   stolower(newval) ; /* To lower case first */
   Token = parse_token(Tokens,newval,&err) ;

   if (err)
   {
	   /* If error, show list of possible parameters */
	   Console_printf("Invalid parameter.\nParameters can be: ") ;
	   while (Tokens[i].token) Console_printf("%s ",Tokens[i++].token) ;
	   Console_printf("\n") ;
   }
   else
   {
      *value = Token ;
      Console_printf("%s now %s\n",id,Tokens[Token].token) ;
      if (SetDirty) Settings.Dirty = true ;
   }
}

void SetOnOff(char*id, char* newval, uint8_t* value)
{
   int8_t Token = 0     ; /* New value         */
   int    err   = false ; /* Error accumulator */

   /* See which settings command */
   Token = parse_token(Booleans,newval,&err) ;

   if (err)
   {
	   /* If error, show list of possible parameters */
	   Console_printf("Invalid parameter.\nParameters can be: on/off, true/false, or 1/0\n") ;
   }
   else
   {
      *value = Token ;
      Console_printf("%s now %s\n",id,newval) ;
      Settings.Dirty = true ;
   }
}

void SetNot(void)
{
   Console_printf("Sorry, this parameter isn't changeable.\n") ;
}

void SetStr(char*id, char* newval, char* target, int targlen)
{
   int len = 0 ; /* incoming string length */

   /* Get the length, if null, the default of 0 is fine */
   if (NULL!=newval) len = strlen(newval) ;

   if (0==len)
   {
      Console_printf("Missing parameter\n") ;
   }
   else if (len>targlen-1)
   {
      /* -1 on length for EOS */
      Console_printf("String too long\n") ;
   }
   else /* Good! */
   {
      /* Clear out the old value completely, then put in new */
      memset(target,0,targlen) ;
      strcpy(target,newval) ;
      Console_printf("%s now %s\n",id,newval) ;
      Settings.Dirty = true ;
   }
}

static void SetLog (int argc,char** argv)
{
   int err = false ;
   int module = 0 ;
   int level = 0 ;

   /* Parameters for logging settings are the functional block and the        */
   /* logging level.                                                          */

   if (4!=argc)
   {
      Console_printf("Parameters are Module and debug level (type show logging to see settings).\n") ;
   }
   else
   {
      module = parse_token(LoggerBlocks,argv[2],&err) ;
      level  = parse_token(LoggerLevels,argv[3],&err) ;

      if (err)
      {
         Console_printf("Parameter error (type show logging to see parameters).\n") ;
      }
      else
      {
         switch(module)
         {
            case LOG_BOOT      : Logger.Boot    = level ; break ;
            case LOG_MAINAPP   : Logger.MainApp = level ; break ;
            case LOG_ETHAPP    : Logger.EthApp  = level ; break ;
            case LOG_ETHLL_IO  : Logger.EthLWIP = level ; break ;
            case LOG_KSZ8081   : Logger.KSZ8081 = level ; break ;
            case LOG_CONSOLE   : Logger.Console = level ; break ;
            case LOG_I2C       : Logger.i2c     = level ; break ;
            case LOG_DIALTASK  : Logger.Dial    = level ; break ;
            case LOG_GPSCODE   : Logger.GPS     = level ; break ;
            case LOG_LOGTELNET : Logger.LogTel  = level ; break ;
            case LOG_LOCAL     : Logger.Local   = level ; break ;
            case LOG_SER2NET   : Logger.Ser2Net = level ; break ;
            case LOG_SPINOR    : Logger.SpiNor  = level ; break ;
            case LOG_SPIMTR    : Logger.SpiMtr  = level ; break ;
            case LOG_TFTP      : Logger.Tftp    = level ; break ;
            case LOG_VCXO      : Logger.Vcxo    = level ; break ;
            default            :                          break ;
         }
      }
   }
}

static void SetGpsDev (int argc,char** argv)
{
   int     error = false ; /* Parsing error flag */
   int     Token = 0     ; /* Command token      */

   if (3!=argc)
   {
      Console_printf("GPS Devices supported are liv4f and m8n.\n") ;
   }
   else
   {
      /* See which settings command */
      stolower(argv[2]) ; /* To lower case first */
      Token = parse_token(GPS_Devices,argv[2],&error) ;
      if (error)
      {
         Console_printf("GPS Devices supported are liv4f and m8n.\n") ;
      }
      else
      {
         switch (Token)
         {
            case GPS_LIV4F: Settings.GPS_Baud = 115200 ;
                            Settings.GPS_PPSEdge = GPS_1PPS_RISING ;
                            break ;
            case GPS_M8N  : Settings.GPS_Baud = 9600 ;
                            Settings.GPS_PPSEdge = GPS_1PPS_RISING ;
                            break ;
            default       : break ; /* Shouldn't happen */
         }
         Console_printf("For %s, Baud set to %d, edge set to %s.\n",GPS_Devices[Token].token,Settings.GPS_Baud,GPS_Edges[Settings.GPS_PPSEdge].token) ;
         Settings.Dirty = true ;
      }
   }
}

static void SetFlags (int argc,char** argv)
{
   int err = false ;
   int Flagnum = 0 ;
   int Flagval = 0 ;

   /* Exactly two parameters, the flag number (0-NFLAGS) and value (0-255)    */

   if (4!=argc)
   {
      Console_printf("Flag parameters are flag number (0-%d) and value (0-255)\n",NDBFLAGS) ;
   }
   else
   {
      Flagnum = parse_num(argv[2],0,NDBFLAGS-1,&err) ;
      Flagval = parse_num(argv[3],0,255,&err) ;

      if (err)
      {
         Console_printf("Parameter error (type set flags to see parameters).\n") ;
      }
      else
      {
         DbFlags[Flagnum] = Flagval ;
      }
   }
}

static void SetErrLogs (int argc,char** argv)
{
   int i = 0 ;

   if (2!=argc)
   {
      Console_printf("This command has no parameters! ") ;
   }

   for (i=0;i<ERRLOGENTRIES;i++)
   {
      ErrLog[i] = 0 ;
   }

   Console_printf("Error Log counters have been cleared.\n") ;
}

static void SetDLogger (int argc,char** argv)
{
   int i = 0 ;

   if (2!=argc)
   {
      Console_printf("This command has no parameters! ") ;
   }

   for (i=0;i<NDLOGGERIDS;i++)
   {
         DLogger_Data[i].Event_ID = 0 ;
   }

   Console_printf("Data Logger entries have been cleared.\n") ;
}

/*******************************************************************************
* Routine  : SetShowHelp
*   Inputs : cmd1,cmd2 : Setting (and sub-setting) help topic
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This is an extension to the 'help set' and 'help show' commands that provides
* help on the particular set/show setting.  It also has conditional extensions
* for the optional modules dial and local.
*******************************************************************************/
void SetShowHelp(char* cmd1, char* cmd2)
{
   int token = 0     ; /* Parsed token              */
   int error = false ; /* Parsing error flag        */
   int good  = false ; /* Recognized sub-param flag */

   /* See if we got a match */
   token = parse_token(SSCmds,cmd1,&error) ;

   if ((!error) && (NULL==cmd2))
   {
      Console_puts(HelpTopics[token]) ;
   }
   else if ((!error) && (NULL!=cmd2))
   {
      /* If we have a third parameter, these are (currently) only valid for   */
      /* the optional dial and local extensions.                              */
#ifdef LOCALVOTER
      if (CMD_LOCAL==token)
      {
         good = true ;
         LocalSettingsHelp(cmd2) ;
      }
#endif
#ifndef NODIALTASK
      if (CMD_DIAL==token)
      {
         good = true ;
         DialSettingsHelp(cmd2) ;
      }
#endif
      /* If not matches above, say so */
      if (!good)
      {
         Console_printf("No extended help for that command\n/") ;
      }
   }
   else
   {
      /* If no match, try to be helpful */
      Console_printf("Set/Show command not found.  Type 'help show' for a full list.\n") ;
   }
}

/*******************************************************************************
* Routine  : SetOTP
*   Inputs : argv, argc - standard params
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This is the routine to program the serial number, hardware revision, and MAC
* address of the Voter2 into the OTP area of the SPINOR flash.  As this is
* programming OTP this command can only be executed once and is assumed to be
* executed as part of "factory bring-up" of the Voter2.  It will only run if
* the OTP area is confirmed as being blank.
* The user supplies the serial number and major and minor HW revision numbers,
* the MAC address is generated automatically (see ProgramOTP).
*******************************************************************************/
static void SetOTP (int argc,char** argv)
{
   int err    = false ; /* Error accumulator      */
   int SNum   = 0     ; /* Serial Number          */
   int HwMaj  = 0     ; /* HW Major revision      */
   int HwMin  = 0     ; /* HW Minor revision      */
   int result = 0     ; /* Result code            */ /* LEAVING THIS WARNING ON PURPOSE!  I NEED TO ADDRESS THE ISSUE (LOW PRIORITY THOUGH) */
   char response[LINE_SIZE] = {0} ; /* User input */

   /* TEMPORARY CODE: Just for Dave and I, we programmed OTP without locking  */
   /* it.  This locks already programmed OTP.  Once we do that, this code     */
   /* goes away.                                                              */
   /* A command of "set myserialnum lock" executes this code.                 */
   if ((3==argc) && (!strcmp("lock",argv[2])))
   {
      SpiNor_lockOTP() ;
   }

   /* If OTP is already programmed, then it's too late */
   else if (Settings.MySerialNum!=0xffffffff)
   {
      Console_printf("Sorry, this parameter isn't changeable.\n") ;
   }
   else
   {
      /* Exactly three parameters, serial number, major HW Rev and minor HW Rev */
      if (5!=argc)
      {
         Console_printf("Parameters are serial number (32-bit), major HW Rev (0-255), and minor HW Rev (0-99)\n") ;
      }
      else
      {
         SNum  = parse_num(argv[2],0,0  ,&err) ;
         HwMaj = parse_num(argv[3],0,255,&err) ;
         HwMin = parse_num(argv[4],0,99 ,&err) ;

         if (err)
         {
            Console_printf("Parameter errors.\n") ;
         }
         else
         {
            /* Echo back exactly what will be programmed and make sure!       */
            Console_printf("I have Serial number %d and Hardware Rev %d.%02d\n",SNum,HwMaj,HwMin) ;
            Console_printf("Is this what you want to program into OTP?\n") ;
            Console_printf("THIS IS IRREVERSIBLE!!\n======================\n") ;
            Console_printf("A randomized MAC Address will also be generated and saved in OTP.\n") ;
            Console_printf("Enter \"yes\" (in lower case) to confirm.\n") ;
            result = Consoleio_gets(response,LINE_SIZE) ;

            if (CONSOLEIO_FLAGS_DATA==result)
            {
               if (!strncmp(response,"yes",4))
               {
                  Console_printf("Programming OTP...\n") ;
                  ProgramOTP(SNum,HwMaj,HwMin) ;
                  Console_printf("Please reboot for settings to take effect.\n") ;
               }
               else
               {
                  Console_printf("OK, never mind...\n") ;
               }
            }
            else /* Something weird from the console, not a line of data! */
            {
               Console_printf("Aborting!\n") ;
            }
         }
      }
   }
}

/*******************************************************************************
* Routine  : ProgramOTP
*   Inputs : SNum - Voter2 product serial number
*          : HwMaj - Hardware revision (Major number)
*          : HwMin - hardware revision (Minor number)
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This is the routine to program the OTP area of the SPINOR flash.  It is 4Kbits
* (512 bytes), but I'm using only 12 bytes!  Assignments are as follows:
*  - Addr 0x00-0x03 : 32-bit Serial Number, MSByte first
*  - Addr 0x04-0x09 : 6-byte MAC address MSByte first
*  - Addr 0x0a-0x0b : 2-byte HW Rev (Major, Minor)
*
* The rest of the OTP is unused.
*
* Note that the MAC address is not provided as parameter, it is a randomly
* generated, locally administered Unicast address.
* Practically, all random bits except for the first byte having bit 0 (the
* unicast/multicast bit) set to 0 and bit 1 (globally vs locally administered)
* bit set to 1.
*******************************************************************************/
static void ProgramOTP(uint32_t SNum,uint8_t HwMaj,uint8_t HwMin)
{
   uint32_t rand1 = 0 ; /* Random number #1  */
   uint32_t rand2 = 0 ; /* Random number #2  */
   int errors = false ; /* Error accumulator */

   /* Take care of the easy stuff first */
   OTPdata[ 0] = (SNum>>24) & 0xff ;
   OTPdata[ 1] = (SNum>>16) & 0xff ;
   OTPdata[ 2] = (SNum>> 8) & 0xff ;
   OTPdata[ 3] = (SNum    ) & 0xff ;
   OTPdata[10] = HwMaj             ;
   OTPdata[11] = HwMin             ;

   /* For the random MAC address fire up the random number generator! */
   if (HAL_RNG_GenerateRandomNumber(&hrng, &rand1) != HAL_OK) errors = true ;
   if (HAL_RNG_GenerateRandomNumber(&hrng, &rand2) != HAL_OK) errors = true ;

   if (errors)
   {
      Console_printf("Problems creating the MAC Address, aborting...\n") ;
   }
   else
   {
      /* For the MSByte, set bits for unicast and locally administered */
      OTPdata[ 4] = ((rand1>>24) & 0xfc) | 0x02  ;
      OTPdata[ 5] =  (rand1>>16) & 0xff  ;
      OTPdata[ 6] =  (rand1>> 8) & 0xff  ;
      OTPdata[ 7] =  (rand1    ) & 0xff  ;
      OTPdata[ 8] =  (rand2>>24) & 0xff  ;
      OTPdata[ 9] =  (rand2>>16) & 0xff  ;

      /* All set, write the OTP and lock it. (Note locking not implemented yet) */
      SpiNor_writeOTP(OTPdata,0,12) ;
      SpiNor_lockOTP() ;
   }
}

/*******************************************************************************
* Routine  : IncErrLog
*   Inputs : id - flag number
*      IOs : None
*  Returns : Nothing
*  Globals : ErrLog[]
*
* This is the routine to increment an error log counter.  It also sends a
* message to the logger output.
* See ErrLog.h for array assignments
*******************************************************************************/
void IncErrLog(int id,int showit)
{
   /* Increment, but peg at 255 */
   if (ErrLog[id]<255) ErrLog[id]++ ;

   /* Note this if asked to */
   if (ERRLOG_SHOW==showit)
   {
      Logger2_Msg(Logger.MainApp,LOG_MAJOR,LOG_TIME,"Error Logger: ErrLog[%d]=%d\r\n",id,ErrLog[id]) ;
   }
}

/*******************************************************************************
* Routine  : DLogger_Event
*   Inputs : id - Event ID
*          : data - Event data
*      IOs : None
*  Returns : Nothing
*  Globals : DLogger_Data[],DLogger_Index
*
* This is the routine to increment an error log counter.  It also sends a
* message to the logger output.
* See ErrLog.h for array assignments
*******************************************************************************/
void DLogger_Event(uint32_t id,uint32_t data)
{
   DLogger_Data[DLogger_Index].Event_ID        = id            ;
   DLogger_Data[DLogger_Index].Event_Data      = data          ;
   DLogger_Data[DLogger_Index].Event_Timestamp = HAL_GetTick() ;

   DLogger_Index = (DLogger_Index+1)%NDLOGGERIDS ;
}

/*******************************************************************************
* Routine  : SetRxCal
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : Settings
*
* This is the routine to calibrate RSSI values.  The user should have a service
* monitor generating a 1KHz tone with 3KHz deviation and be able to adjust the
* S/N as needed.  This routine shows a "live" S/N using the FFT analysis of the
* incoming signal.  The user adjusts the service monitors dBm to get full
* quieting and audible threshold and these values get stored as "255" and "0"
* RSSI values.  When doing live RSSI reporting, the value sent to the DIAL
* server is interpolated between those two points.
*******************************************************************************/
#define SN_BARLEN 40
#define RXCAL_SDIVISOR 400000 /* Pretty arbitrary to get nice graphs (signal) */
#define RXCAL_NDIVISOR 200000 /* Pretty arbitrary to get nice graphs (noise)  */

enum
{
   RXCAL_STATE_CALIBRATING = 0,
   RXCAL_STATE_DONE,
   RXCAL_STATE_ABORT,
} RXCAL_STATES ;

static void SetRxCal (void)
{
   int      state         = RXCAL_STATE_CALIBRATING ;
   int      KbPressed     =  0 ;
   uint16_t Analog_RSSI   =  0 ;
   uint16_t NewAnalog_0   = -1 ;
   uint16_t NewAnalog_255 = -1 ;

   int  i               =  0  ; /* General counter */
   int  freqlvl         =  0  ; /* Frequency level */
   char SN_BarText[SN_BARLEN] = {0} ; /* My VU bar */

   /* Enable all Rx filters--even if not needed for audio */
   RxDiags = true ;

   Console_printf("\nSet your service monitor to a 1KHz tone with 3KHz deviation.\n") ;
   Console_printf("Press 'a' after adjusting the signal for a receiver sensitivity of 12 dB SINAD.\n") ;
   Console_printf("Press 'q' after increasing the generator by 25 dB.\n") ;
   Console_printf("Press 's' to save the results (you can press q and a multiple times, last one used).\n") ;
   Console_printf("Press 'x' to abort the process and keep old values.\n") ;
   Console_printf("Press any key to start. The S/N bar is there for guidance.\n\n") ;

   /* Wait for them to press a key */
   Consoleio_purge() ;
   while (!Consoleio_kbhit()) ;
   Consoleio_purge() ;

   /* Calibration loop, stay here until no longer calibrating */
   while (RXCAL_STATE_CALIBRATING==state)
   {
      /* First fill in the VU bar background */
      for (i=0;i<SN_BARLEN;i++) SN_BarText[i] = '.' ;
      SN_BarText[ 0] = '|'  ; /* Left edge  */
      SN_BarText[33] = '|'  ; /* Right edge */
      SN_BarText[34] =  0   ; /* EOS        */

      /* Plunk an 'S' for the 1KHz bin for signal, */
      /* Plunk an 'N' for the others for noise.    */
      freqlvl = (RxFFT_Bins[4]/RXCAL_SDIVISOR)+1 ;
      if (freqlvl< 1) freqlvl = 1       ;
      if (freqlvl>32) freqlvl = 32      ;
      SN_BarText[freqlvl]= 'S'          ;

      /* Add up all bins except index 0 (DC) and 4 (1KHz) */
      freqlvl = 0 ;
      for(i=1;i<FFT_BINLEN;i++)
      {
         if (4!=i)
           freqlvl += (RxFFT_Bins[i]/RXCAL_NDIVISOR) ;
      }

      freqlvl = (freqlvl/4)+1      ; /* Bit more scaling */
      if (freqlvl< 1) freqlvl = 1  ; /* Lower limit      */
      if (freqlvl>32) freqlvl = 32 ; /* Upper limit      */
      SN_BarText[freqlvl]= 'N'     ; /* Plunk the 'N'    */

      KbPressed = tolower(Consoleio_getc(CONSOLE_GETC_NOWAIT)) ;
      Analog_RSSI = Get_Analog_RSSI(ANALOG_RSSI_RAW) ;

      Console_printf("%s %d ",SN_BarText,Analog_RSSI) ;

      if ('q'==KbPressed)
      {
         NewAnalog_255 = Analog_RSSI ;
         Console_printf("RSSI 255 (full quiet) set.\n") ;
      }
      else if ('a'==KbPressed)
      {
         NewAnalog_0   = Analog_RSSI ;
         Console_printf("RSSI 0 (audible) set.\n") ;
      }
      else
      {
         Console_printf("\n") ;
      }

      if ('s'==KbPressed) state = RXCAL_STATE_DONE ;
      if ('x'==KbPressed) state = RXCAL_STATE_ABORT ;

      osDelay(200) ;
   } /* while calibrating */

   /* OK, the user said they were done.  If it was a "save and exit" (and they*/
   /* set both quiet and noise levels), save them, otherwise exit without     */
   /* saving anything.                                                        */
   if (RXCAL_STATE_DONE==state)
   {
      if ((-1==NewAnalog_0) || (-1==NewAnalog_255)) /* Forgot a setting */
      {
         Console_printf("You must save both full quieting and noise settings.\n") ;
         Console_printf("Aborting without making changes.\n") ;
      }
      else if (NewAnalog_0 >= NewAnalog_255) /* Backwards settings */
      {
         Console_printf("Your noise RSSI setting is higher than full quieting!\n") ;
         Console_printf("You probably got 'q' and 'a' backwards.\n") ;
         Console_printf("Aborting without making changes.\n") ;
      }
      else
      {
         Settings.Analog_RSSI0   = NewAnalog_0   ;
         Settings.Analog_RSSI255 = NewAnalog_255 ;
         Settings.Dirty          = true          ;
         Console_printf("Analog RSSI calibration complete.\n") ;
         Console_printf("Remember to save settings for them to be permanent.\n") ;
      }
   }
   else /* The user aborted */
   {
      Console_printf("Aborting without making changes.\n") ;
   }

   /* All done, update the analog RSSI interpolation table and only enable    */
   /* all Rx filters needed                                                   */
   Update_ARSSI_Table() ;
   RxDiags = false ;

}

/*******************************************************************************
* Routine  : ShowRxCal
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : Settings
*
* This displays the analog Rx calibration values.  They are stored as raw ADC
* values, so I go ahead and convert them to volts (before the resistor divider)
* and then what the MTR-2000 claims is the dBm value for that voltage level.
*******************************************************************************/
static void ShowRxCal (void)
{
   int RssiV_0    = 0 ; /* RSSI   0 volts x100 */
   int RssiV_255  = 0 ; /* RSSI 255 volts x100 */
   int RssidB_0   = 0 ; /* RSSI   0 dBm x100   */
   int RssidB_255 = 0 ; /* RSSI 255 dBm x100   */

   Console_printf("Below are the analog RSSI values for an RSSI of 0 and 255.\n") ;
   Console_printf("The dBm value is per the MTR-2000 spec from the voltage.\n") ;

   /* First convert ADC value to voltsx100. Order matters for integer math.   */
   RssiV_0   = (Settings.Analog_RSSI0  *330)/4096 ;
   RssiV_255 = (Settings.Analog_RSSI255*330)/4096 ;

   /* I have a resistor divider on the analog RSSI coming in, so need to      */
   /* compensate for that, it is x1.332.                                      */
   RssiV_0   = (RssiV_0  *1332)/1000 ;
   RssiV_255 = (RssiV_255*1332)/1000 ;

   /* Now convert that to dBm.  The MTR spec calls out just the two endpoints:*/
   /* 0.5V for -120dBm, 3.5V for -40dBm.                                      */
   /* With a little twiddling, this comes to dB being -133.33+Volts*26.67.     */
   RssidB_0   = -(13333-(2667*RssiV_0  )/100) ;
   RssidB_255 = -(13333-(2667*RssiV_255)/100) ;

   Console_printf("RSSI  ADC Volts  dBm\n") ;
   Console_printf("==== ==== ===== ====\n") ;
   Console_printf("   0 %4d %2d.%2.2d %4d\n",Settings.Analog_RSSI0  ,RssiV_0  /100,RssiV_0  %100,RssidB_0  /100) ;
   Console_printf(" 255 %4d %2d.%2.2d %4d\n",Settings.Analog_RSSI255,RssiV_255/100,RssiV_255%100,RssidB_255/100) ;

}

/*******************************************************************************
* Routine  : SetVcxoV
*   Inputs : argv, argc - standard params
*      IOs : None
*  Returns : Nothing
*  Globals : Settings,Vcocxo_DACval
*
* This saves the VCXO calibration value in the settings array (not NVM!).
* If a parameter is provided, the VCXO calibration setting will be that value.
* If no parameter is provided, the value is taken from the VCXO calibration
* loop code.  This second option is the 99% case since the value is determined
* by the loop, not the user.
*******************************************************************************/
static void SetVcxoV  (int argc,char** argv)
{
   int32_t  Val32  = 0     ; /* New value         */
   int      err    = false ; /* Error accumulator */

   /* If no params, get the value from the VCXO control loop */
   if(2==argc)
   {
      Settings.Vcxo_DACval = Vcxo_DACval ;
      Console_printf("VCXO calibration value is now %u\n",Vcxo_DACval) ;
      Settings.Dirty = true ;
   }
   /* If a single parameter, that is the DAC value */
   else if (3==argc)
   {
      /* Go get the number */
      Val32=parse_num(argv[2],0,65535,&err) ;

      if (err)
      {
         Console_printf("Invalid or out of range number, range is 0-65535.\n") ;
      }
      else
      {
         Settings.Vcxo_DACval = Val32 ;
         Console_printf("VCXO calibration value is now %u\n",Val32) ;
         Settings.Dirty = true ;
      }
   }
   else
   {
      Console_printf("Specify no value to use loop value or a single 16-bit value.\n") ;
   }
}
