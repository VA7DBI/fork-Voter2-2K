/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the DialTaskIn file. It is in charge of data coming in from the    */
/* DIAL server.  It also does the initial setup of the Ethernet interface.    */
/* It is only enabled if Voter mode is enabled.                               */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - DialEthRxTask - Top level task                                          */
/*                                                                            */
/******************************************************************************/
// To Do:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>
#include <stdio.h>

#include "lwip.h"
#include "lwip/api.h"

#include "main.h"
#include "Options.h"
#include "Settings.h"
#include "AnalogIO.h"
#include "DialTaskCom.h"
#include "DialTaskOut.h"
#include "DialTaskIn.h"
#include "DialSettings.h"
#include "Rx_DSP.h"
#include "GPS.h"
#include "Histograms.h"
#include "Codecs.h"
#include "logger2rt.h"
#include "Debugging.h"
#include "EthernetTask.h"
#include "Tx_DSP.h"

/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/

/******************************************************************************/
/* Structures                                                                 */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
uint32_t RxPackets[PAYLOAD_CNTRS] = {0}   ; /* Rx packet count by type */

/* For a sync check */
uint8_t  SyncCheck    = false     ; /* Sync check flag     */
uint32_t MySecs       = 0         ; /* Event local seconds */
uint32_t MynSecs      = 0         ; /* Event local ns      */
uint32_t DSSecs       = 0         ; /* DIAL server seconds */
uint32_t DSnSecs      = 0         ; /* DIAL server ns      */


/******************************************************************************/
/* Globals shared just between DialTasks (in DialTaskCom.h)                   */
/******************************************************************************/
int EnableDialOut = false ; /* Enable message queuing           */
struct netconn *DIALconn = NULL  ; /* netconn handle for DIAL server   */
int DialWatchdog = 0     ; /* DIAL Comms watchdog counter */
int DIAL_Offline = false ; /* DIAL Offline flag           */
uint8_t   DIAL_Challenge[SETTINGS_CHALLENGE_LEN] = {0} ;/* Challenge string from the DIAL server         */
int      DIAL_State   = DIAL_DISC ; /* DIAL connection state   */
uint8_t  DIAL_flagbyte            =  0    ; /* DIAL Server flag byte   */
uint32_t FKGPS_Time      = 0     ; /* Fake GPS Time (seconds)          */
uint32_t FKGPS_Tns       = 0     ; /* Fake GPS Time (ns)               */
uint32_t GP_SeqNum       = 0     ; /* GP mode packet counter           */



/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
#ifndef NODIALTASK
static int16_t Tx_Samples[APKT_SAMPLES*2] ; /* Decompressed samples (2x for ADPCM) */

#endif /* #ifndef NODIALTASK */

/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
#ifndef NODIALTASK
static void    HandleEthData(uint8_t*,uint32_t) ;
static void    Rx_handleCR  (uint8_t*,uint8_t*) ;
static int     Rx_Auth_Packet    (void*,uint16_t,uint32_t,uint32_t) ;
static int     Rx_MuLaw_Packet   (void*,uint16_t,uint32_t,uint32_t) ;
static int     Rx_GPSInfo_Packet (void*,uint16_t                  ) ;
static int     Rx_ADPCM_Packet   (void*,uint16_t,uint32_t,uint32_t) ;
static int     Rx_Ping_Packet    (void*,uint16_t                  ) ;

#endif /* #ifndef NODIALTASK */

/******************************************************************************/
/* Finally, routines!                                                         */
/******************************************************************************/
/*******************************************************************************
* Routine  : DialEthRxTask
* Gazintas : None (argument isn't used)
* IOs      : None
* Returns  : Doesn't, this is a top level RTOS task
* Globals  : DIALconn - The DIAL connection
*          : EnableDialOut - enable DIAL messages
*
* This task handles UDP packets coming from the DIAL server.
* This task first waits for DialEthTxTask to set up the port, then has a
* blocking wait for data.  It does a bit of sanity checking, then passes on
* the packet for interpreting.
*******************************************************************************/
 void DialInTask(void const * argument)
{
#ifdef NODIALTASK
   osThreadTerminate(DialEthRxTaskIDHandle) ;
#else

   err_t         err     = ERR_OK ; /* Called routine result code */
   struct netbuf *rx_buf = NULL   ; /* Rx packet buffer handle    */

   /* Do our prescribed wait, double-check that Ethernet is up (should be),   */
   /* then say Hi on the logger interface                                     */
   osDelay(StartDelay_DIALTask) ;
   while (!EthernetUp) osDelay(10) ;

   Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialInTask: Start\r\n") ;

   /* If the DIAL server IP address is static, plunk in the user-specified IP */
   /* address we want to contact.                                             */
   if (DIALIPMODE_STATIC==DIALSettings.IPMode)
   {
      IP_ADDR4(&DIAL_Server_IP,(DIALSettings.Static_IP>>24) & 0xff,
                               (DIALSettings.Static_IP>>16) & 0xff,
                               (DIALSettings.Static_IP>> 8) & 0xff,
                               (DIALSettings.Static_IP    ) & 0xff) ;
   }
   else /* else do a DNS lookup for the DIAL server IP address */
   {
      /* Loop forever if the lookup fails.  Can't do much without a DIAL IP      */
      /* address.  It may be because of no network connection or maybe a bad     */
      /* FQDN, so just keep retrying until resolved.                             */
      while ((netconn_gethostbyname(DIALSettings.fqdn,&DIAL_Server_IP))!= ERR_OK)
      {
         Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialInTask: DIAL server DNS Lookup failed!\r\n") ;
         osDelay(1000) ;
      }
   }

   /* Save the resolved address just for CLI reporting */
   DIAL_ip = DIAL_Server_IP.addr ;

   /* Set up the UDP connection with the DIAL server. Note that this does not */
   /* generate any IP traffic.  I don't think it can fail.                    */
   /* Connect to the DIAL server using UDP.                                   */
   /* Note that this doesn't actually establish or confirm a connection!      */
   /* It "connects" even if a server isn't there.  This is normal.            */
   DIALconn = netconn_new(NETCONN_UDP);
   Logger2_Msg(Logger.Dial,LOG_SUPPORT,LOG_TIME,"DialInTask: netconn_new (%8.8x)\r\n",(uint32_t)DIALconn) ;
   netconn_connect(DIALconn,&DIAL_Server_IP,DIALSettings.VoterPort);
   Logger2_Msg(Logger.Dial,LOG_SUPPORT,LOG_TIME,"DialInTask: netconn_connect (%8.8x)\r\n",(uint32_t)DIALconn) ;

   /* OK, we're up!  Enable incoming Rx Audio messages and Ethernet packets!  */
   EnableDialOut = true ;

   /* Ready!  Now just wait on packets and if one comes along, queue it up    */
   /* for DialTask.                                                           */
   for(;;) /* RTOS Task Infinite loop */
   {
      err = netconn_recv(DIALconn, &rx_buf) ;
      if (0!=err) IncErrLog(ERRLOG_DIALETHRXTASK_NETCONN_RECV,ERRLOG_SHOW) ;

      //Logger2_Msg(Logger.Dial,LOG_REGIO,LOG_TIME,"DialEthRxTask: Rx Data (%d,%d)\r\n",err,err?0:rx_buf->p->tot_len) ;

      /* If no Rx error and a reasonable packet length, process it! */
      /* *NEW* If forced offline mode, just ignore the packet */
      if ((ERR_OK==err) && (rx_buf->p->tot_len >= VOTER_MINPLEN) && (rx_buf->p->tot_len <= VOTER_MAXPLEN) && !DIAL_Offline)
      {
         /* Go process the packet */
         HandleEthData(rx_buf->p->payload,rx_buf->p->tot_len) ;
      }
      /* and finally release the netbuf */
      if (rx_buf) netbuf_delete(rx_buf) ;
      /* "The Internet" says to delete and re-request a netbuf each time,     */
      /* don't try to just re-use the same netbuf over and over.              */
      /* I still tried to re-use it and it didn't go well! :)                 */
   }
#endif /* #ifdef NODIALTASK */
}

/*******************************************************************************
* Routine  : HandleEthData
* Gazintas : DialEthRxPkt - Buffer of data
*          : BufferLen - Buffer data length
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine processes Ethernet packets from the DIAL server.  These are just
* UDP packets with a simple length (VOTER_MINPLEN/VOTER_MAXPLEN) check.
* Enough bytes for the header and less than the max possible DIAL packet.
*******************************************************************************/
static void HandleEthData(uint8_t* DialEthRxPkt,uint32_t BufferLen)
{
   bool     err    = true ; /* Packet error flag      */
   HEADER_T header = {0}  ; /* Packet header contents */

   /* The general flow is first looking at the header see if it makes sense,  */
   /* then doing the challenge/response since it is common to all packets,    */
   /* then handing it off to each packet type for handling that packet types  */
   /* payload.  If anything is bad about the packet, it is simply dropped.    */

   /* Not yet, but check things like source IP address, port, and other stuff?*/

   /* To keep track if we are still connected to the DIAL server, I have      */
   /* essentially a comms watchdog.  It gets incremented every 20ms by the    */
   /* HandleRxAudio() routine.  Getting data here resets that counter to 0,   */
   /* so if that counter reaches the timeout value, we declare we've lost     */
   /* comms and go back to the unauthorized state.  For this routine, just    */
   /* Zero the watchdog count.                                                */
   DialWatchdog = 0 ;

   /* Still double-check the payload length to be enough for a header.        */
   if (BufferLen >= 24)
   {
      /* Copy the header bytes (in any byte alignment) from the UDP packet    */
      /* to the word-aligned header structure for parsing.                    */
      memcpy(&header,DialEthRxPkt,sizeof(HEADER_T)) ;
      /* do the net to host conversions for ints. */
      header.time_s = ntohl(header.time_s) ;
      header.time_ns = ntohl(header.time_ns) ;
      header.Payload_Type = ntohs(header.Payload_Type) ;

      /* Challenge response is common to all packets, so handle here */
      Rx_handleCR((uint8_t*)(DialEthRxPkt+8),(uint8_t*)(DialEthRxPkt+18)) ;

      /* Head off to the various routines based on the Payload Type.  They    */
      /* will do further payload-type-specific checking from there.           */
      /* Since DialEthRxPkt gets re-used after this, routines must make local */
      /* copies of any data they want to keep before returning.               */
      switch (header.Payload_Type)
      {
         case PAYLOAD_T0AUTH    :  err=Rx_Auth_Packet   (DialEthRxPkt,BufferLen,header.time_s,header.time_ns) ; break ;
         case PAYLOAD_T1MULAW   :  err=Rx_MuLaw_Packet  (DialEthRxPkt,BufferLen,header.time_s,header.time_ns) ; break ;
         case PAYLOAD_T2GPSINFO :  err=Rx_GPSInfo_Packet(DialEthRxPkt,BufferLen                             ) ; break ;
         case PAYLOAD_T3ADPCM   :  err=Rx_ADPCM_Packet  (DialEthRxPkt,BufferLen,header.time_s,header.time_ns) ; break ;
         case PAYLOAD_T5PING    :  err=Rx_Ping_Packet   (DialEthRxPkt,BufferLen                             ) ; break ;
         default                :  err=true                                                                   ; break ;
      }
   }
   else /* Payload < 24 bytes */
   {
      err = true ;
   }

   /* If any error, increment the error packet counter. */
   if (err) RxPackets[PAYLOAD_ERR]++ ;
}

/*******************************************************************************
* Routine  : Rx_handleCR
* Gazintas : New_DIAL_Challenge - incoming DIAL challenge string
*          : DIAL_CR_Response - DIALs response to the voters challenge string.
* IOs      : None
* Returns  :
* Globals  :DIAL_State
*
* This routine parses the challenge response info of any packet.  The challenge
* string from the DIAL server just gets stored so the response can be computed
* on the transmit side.  The challenge response from the DIAL server is
* compared to the expected response and DIAL_State is updated based on the
* result.
*******************************************************************************/
static void Rx_handleCR(uint8_t* New_DIAL_Challenge,uint8_t* DIAL_CR_Response)
{
   uint32_t expected_response = 0 ; /* Expected challenge response  */
   uint32_t actual_response   = 0 ; /* Challenge response from DIAL */
   int      LastState         = 0 ; /* For tracking a state change  */

   /* Just copy the DIALs challenge string for use later. */
   memcpy(DIAL_Challenge,New_DIAL_Challenge,SETTINGS_CHALLENGE_LEN) ;

   /* Compute the expected challenge response from the voter challenge string */
   /* and the system password, then get the challenge response from the       */
   /* received packet to compare (copying byte string to uint32).             */
   expected_response = ntohl(crc32_bufs((unsigned char*)DIALSettings.Voter_Challenge,(unsigned char*)DIALSettings.Host_Password)) ;
   memcpy(&actual_response,DIAL_CR_Response,4) ;

   /* Refresh the DIAL connection state.  Log a message only if a change. */
   if (0 == actual_response)
   {
      /* A challenge response of 0 forces unauthorized state */
      if (DIAL_UNAUTH != DIAL_State) Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialTask: De-Authorized by DIAL!\r\n") ;
      DIAL_State = DIAL_UNAUTH ;
      //Show_State(CONNECTED_STATE,false) ;
   }
   else if (expected_response == actual_response)
   {
      LastState = DIAL_State ;
      /* Matching challenge/response - a good start!  But need to be sure the */
      /* DIAL server agrees with our timing mode too. It may not initially.   */
      if (((PKTTIM_GP   ==DIALSettings.PacketTiming) &&  DIAL_GENPURPOSE ) ||
          ((PKTTIM_GPS  ==DIALSettings.PacketTiming) && !DIAL_GENPURPOSE ) ||
          ((PKTTIM_FKGPS==DIALSettings.PacketTiming) && !DIAL_GENPURPOSE )   )
      {
         /* While I insist the DIAL server give back the right timing mode, I */
         /* do just accept the compression mode.                              */
         DIAL_State = DIAL_USEADPCM?DIAL_ADPCM:DIAL_MULAW ;
      }

      /* If something changed, note it */
      if (DIAL_State != LastState)
      {
         Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialTask: Authorized! (%s)\r\n",DIAL_USEADPCM?"ADPCM":"MuLaw") ;
      }
   }
   else
   {
      /* Got a non-zero response, but it didn't match */
      if (DIAL_UNAUTH != DIAL_State) Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialTask: DIAL failed challenge/response!\r\n") ;
      DIAL_State = DIAL_UNAUTH ;
   }
}

/*******************************************************************************
* Routine  : Rx_Auth_Packet
* Gazintas : payload - pointer to Ethernet packet payload bytes (all of them)
*          : len - payload length
*          : Packet_Time - Server time (seconds)
*          : Packet_Tns - Server time (ns)
* IOs      : None
* Returns  : error flag
* Globals  :
*
* This routine parses a Type 0 (Authorization) packet.  For messages from the
* host, this is a fixed length packet (Flag byte is mandatory for host)
* This just handles timing and the flag byte, actual authorization is part of
* every packet and handled in Rx_handleCR().
*******************************************************************************/
static int Rx_Auth_Packet (void* payload,uint16_t len,uint32_t Packet_Time,uint32_t Packet_Tns)
{
   bool     err     = true ; /* General error flag */

   RxPackets[PAYLOAD_T0AUTH]++ ;
   if (VOTER_PACKLEN_T0GP == len)
   {
      /* There isn't anything to verify about the DIAL time.  Since it is the */
      /* DIAL servers time though, store it so it can be used to send back an */
      /* approximate time for non-GPS audio packets.  The spec says for       */
      /* non-GPS packets to use the ns field for a counter that starts at 0   */
      /* on authorization and increments every 20ms from there, so reset that */
      /* counter to 0 here.                                                   */
      FKGPS_Time = Packet_Time ;
      FKGPS_Tns  = Packet_Tns  ;
      GP_SeqNum = 0           ;

      /* If a sync check has been requested and an auth packet sent, then     */
      /* this auth return packet has our timestamp data!  Save all the time   */
      /* values and flag that the sync check is complete.  Code in            */
      /* Stat_Sync() does all the math and reporting.                         */
      if (SYNCCHECK_RUNNING==SyncCheck)
      {
         Get_GPSTimeNow(&MySecs,&MynSecs) ;
         DSSecs    = Packet_Time          ;
         DSnSecs   = Packet_Tns           ;
         SyncCheck = SYNCCHECK_IDLE       ;
      }

      /* For fake GPS mode, I need a bit of an offset */
      FKGPS_Tns +=20000000 ; /* 20ms in ns */

      if (FKGPS_Tns >=1000000000) /* billion ns to a s */
      {
         FKGPS_Tns -= 1000000000 ;
         FKGPS_Time++   ;
      }

      /* Save the flag byte - crazy typecasting! */
      DIAL_flagbyte = *(((uint8_t*)payload)+24) ;

      /* A new flag byte could have changed some of the DSP filters, go       */
      /* re-initialized them with the current settings.                       */
      Rx_FilterInit() ;

      Logger2_Msg(Logger.Dial,LOG_REGIO,LOG_TIME,"DialTask: RxAuth: Time = 0x%8.8x, Host Flag Byte: 0x%2.2x\r\n",FKGPS_Time,DIAL_flagbyte) ;

      /* Regardless of CR result, packet itself is good. */
      err = false ;
   }
   return (err) ;
}

/*******************************************************************************
* Routine  : Rx_MuLaw_Packet
* Gazintas : payload - pointer to Ethernet packet payload bytes (all of them)
*          : len - payload length
*          : Packet_Time - Server time (seconds)
*          : Packet_Tns - Server time (ns)
* IOs      : None
* Returns  : error flag
* Globals  : Tx_Samples - decompressed contents to transmit
*
* This routine parses a Type 1 (MuLaw) packet.  The header is verified good, so
* double-check that it is the right length for RSSI and samples before
* decompressing it and sending the decompressed data to the DAC handlers.
*******************************************************************************/
static int Rx_MuLaw_Packet (void* payload,uint16_t len,uint32_t Packet_Time,uint32_t Packet_Tns)
{
   static uint32_t Prev_Pkt_Sec = 0    ; /* Previous Packet time (secs)    */
   static uint32_t Prev_Pkt_ns  = 0    ; /* Previous Packet time (ns)      */
   int32_t         delta        = 0    ; /* Delta from last packet (ns)    */
   bool            err          = true ;

   /* Jitter logging tool */
   Jitter_Log() ;

   RxPackets[PAYLOAD_T1MULAW]++ ;
   /* A type 1 (MuLaw) packet is fixed length, so only one length possible.   */
   /* For the payload itself (1 RSSI byte and 160 audio samples, nothing more */
   /* to check.                                                               */
   /* Copy the data (since pbuf is going to be freed on returning) and send   */
   /* the data to the audio task.                                             */
   if (VOTER_PACKLEN_T1 == len)
   {
      DecompressuLaw (payload+25,Tx_Samples) ;  /* Decompress just the data part */
      Tx_EnqPacket(Tx_Samples,DIAL_GENPURPOSE?GENERAL_TIMED:GPS_TIMED,Packet_Time,Packet_Tns) ;
      err = false ;

      /* This reporting generates so much data I enable/disable it by DbFlags    */
      /* only.                                                                   */
      if (3==DbFlags[DBFLAG_TSDELTAS])
      {
         /* Figger out the delta time from the last packet in ns */
         delta = (Packet_Time-Prev_Pkt_Sec)*1000000000+Packet_Tns-Prev_Pkt_ns ;
         Logger2_Msg(Logger.Dial,LOG_REGIO,LOG_TIME,"DialTask: uLaw Tx TS: %u.%09u delta %6d\r\n",Packet_Time,Packet_Tns,delta) ;
         Prev_Pkt_Sec = Packet_Time ;
         Prev_Pkt_ns  = Packet_Tns  ;
      }
   }

   return (err) ;
}

/*******************************************************************************
* Routine  : Rx_GPSInfo_Packet
* Gazintas : payload - pointer to Ethernet packet payload bytes (all of them)
*          : len - payload length
* IOs      : None
* Returns  : error flag
* Globals  : TBD
*
* This routine parses a Type 2 (GPS Information) packet.  As this is coming
* from the DIAL server, I'm expecting it to not have any info, just be a blank
* "keep alive" packet.
*******************************************************************************/
static int Rx_GPSInfo_Packet (void* payload,uint16_t len)
{
   RxPackets[PAYLOAD_T2GPSINFO]++ ;
   return (false) ;
}

/*******************************************************************************
* Routine  : Rx_ADPCM_Packet
* Gazintas : payload - pointer to Ethernet packet payload bytes (all of them)
*          : len - payload length
*          : Packet_Time - Server time (seconds)
*          : Packet_Tns - Server time (ns)
* IOs      : None
* Returns  : error flag
* Globals  : Tx_Samples - decompressed contents to transmit
*
* This routine parses a Type 3 (ADPCM) packet.  The header is verified good, so
* double-check that it is the right length for RSSI and samples before
* decompressing it and sending the decompressed data to the DAC handlers.
* NOTE: For ADPCM a single Ethernet packet (164 payload bytes) generates two
* "regular" 160-sample packets of decompressed data.
*******************************************************************************/
static int Rx_ADPCM_Packet (void* payload,uint16_t len,uint32_t Packet_Time,uint32_t Packet_Tns)
{
   /* Jitter logging tool */
   Jitter_Log() ;

   bool err = true ;

   RxPackets[PAYLOAD_T3ADPCM]++ ;
   /* A type 3 (ADPCM) packet is fixed length, so only one length possible.   */
   /* For the payload itself (1 RSSI byte and 163 compressed audio bytes,     */
   /* nothing more to check.                                                  */
   /* Decompress the data into another buffer (since pbuf is going to be      */
   /* freed on returning) and send the data to the DAC handlers.              */
   if (VOTER_PACKLEN_T3 == len)
   {
      /* ADPCM generates two 160-sample audio packets for every 163- */
      /* byte Ethernet packet.  Decompress the full Ethernet packet  */
      /* and then queue up both audio packets.                       */
      DecompressADPCM(payload+25,Tx_Samples) ;
      Tx_EnqPacket(Tx_Samples,DIAL_GENPURPOSE?GENERAL_TIMED:GPS_TIMED,Packet_Time,Packet_Tns) ;

      /* For the second packet I need to increment the time by 20ms if in  */
      /* GPS-timed mode or increment the counter in the ns field if in     */
      /* general purpose mode.                                             */
      if (PKTTIM_GP==DIALSettings.PacketTiming)
      {
         Packet_Tns++ ;
      }
      else
      {
         Packet_Tns +=20000000 ; /* +20ms in ns */
         if (Packet_Tns>1000000000)
         {
            Packet_Time++ ;
            Packet_Tns -= 1000000000 ;
         }
         Tx_EnqPacket(Tx_Samples+160,DIAL_GENPURPOSE?GENERAL_TIMED:GPS_TIMED,Packet_Time,Packet_Tns) ;
      }
      err = false ;
   }

   return (err) ;
}


/*******************************************************************************
* Routine  : Rx_Ping_Packet
* Gazintas : payload - pointer to Ethernet packet payload bytes (all of them)
*          : len - payload length
* IOs      : None
* Returns  : error flag
* Globals  : PingPacket
*
* This routine parses a Type 5 (Ping) packet.  Header is good, so only check
* is the ping payload should be 200 bytes or less with no known checks on the
* payload contents.  If legit, just return the payload back to the host.
*******************************************************************************/
static int Rx_Ping_Packet (void* payload,uint16_t len)
{
   bool err = true ;

   RxPackets[PAYLOAD_T5PING]++ ;
   /* This is a variable length packet, so just make sure the incoming packet */
   /* isn't too long.  VOTER_PACKLEN_T5 is for the whole packet including the */
   /* header, so 224 for max 200 byte ping payload.  No need for a minimum    */
   /* size check as that was done during header parsing.                      */
   if (len <= VOTER_PACKLEN_T5)
   {
      Tx_Ping_Packet(payload+24,len-24) ;
#if 0
      /* Create the ping return packet */
      Struct_PingPacket.header.time_s       = htonl(FKGPS_Time) ;
      Struct_PingPacket.header.time_ns      = 0 ; /* 0 for pings? */
      Struct_PingPacket.header.Payload_Type = htons(PAYLOAD_T5PING) ;

      memcpy(Struct_PingPacket.PingData,payload+24,len-24) ;
      /* Challenge/response is handled later as it is common to all packets */

      /* Packet ready to send, send it! */
      SendDialPacket(PingPacket,len) ;
      TxPackets[PAYLOAD_T5PING]++ ;
#endif
      err = false ;
   }

   return (err) ;
}

extern int CheckSyncCheck(void)
{
   int rval = false ;
   if (SYNCCHECK_START==SyncCheck)
   {
      SyncCheck = SYNCCHECK_RUNNING ;
      rval = true ;
   }
   return (rval) ;
}
