/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Rx_DSP file.  It is in charge of all the Receive DSP functions.*/
/* These routines get passed a packets worth of raw audio samples from the    */
/* ADC routines and create the "cooked" packets of samples for the DIALTask   */
/* to compress and send over Ethernet.                                        */
/* With Voter support the audio packet size must be 160 samples, if Voting is */
/* disabled, it can be variable.                                              */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Rx_FilterInit - Initialize Rx DSP filters                               */
/*  - Rx_EnqPacket - Processed and enqueues a packet of audio samples.        */
/*                                                                            */
/******************************************************************************/
// TO DO:
//  - DeEmphasis and the voice filter attenuate a lot!
//  - Need to reset filter (line 166) when changing between local and dial modes

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h> /* for memcpy */

#include "Options.h"
#include "main.h"
#include "Utils.h"
#include "Settings.h"
#include "SetShow.h"
#include "Gpio.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "Tx_DSP.h"
#include "Gps.h"
#include "LocalMode.h"
#include "DialTaskOut.h"
#include "DialTaskIn.h"
#include "VoiceFilter.h"
#include "RSSIFilter.h"
#include "Codecs.h"
#include "Timers.h"
#include "Debugging.h"

#ifndef ARM_MATH_CM7
#define ARM_MATH_CM7
#endif
#ifndef _ARM_MATH_H
#include "arm_math.h"
#endif

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
/* Audio peak-peak levels for determining Rx LED color                        */
#define VINPP_MIN  1024 /* 1/4 scale is min (yellow-green transition)         */
#define VINPP_MAX  3840 /* 7/8 scale as overdrive (green-red transition)      */

#define HPF1_TABLESIZE 8
#define RSSI_HISTLEN 3


/* defines for the DSP/BEW math */
#define FFT_FWD_XFORM 0
#define FFT_REV_XFORM 1
#define FFT_BITREVERSE 0
#define FFT_NOBITREVERSE 1

/* BEW_THRESHOLD takes a bit of explaining and I'm not sure I have it entirely*/
/* right still. The threshold is being compared to the sum of the magnitude   */
/* squared of the FFT results and if they add up to more than 10, that is the */
/* BEW threshold.  It is magnitude squared just to save the overhead of a     */
/* square root and it is for the 29 of the 32 bins (no DC, CTCSS,or Nyqust).  */
/* The FFT output is in 6.10 format, so the squared sum is in 12.20 format.   */
/* So, 1.0 is 2^20 and 10.0 10x that.                                         */
#define BEW_THRESHOLD (10*1048576)

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/* For offline De-emphasis.  The default is off unless a local mode overrides */
/* it.  Note that each local mode has its own settings structure, so for code */
/* independence, this is the common setting each local mode must set.         */
int LocalDeemph = false ;

/* If I am running some Rx diags, enable all filters, even if not being used  */
/* for repeater audio.  Normally only the necessary filters are enabled.      */
int RxDiags = false ;

uint32_t Hpf_RSSI    = 0 ; /* High-pass filt RSSI value */
int      RxTToneMode = 0 ; /* Rx Test Tone mode         */
uint16_t VinPP       = 0 ; /* Full scale is all 16-bits */
uint16_t VinPP_Max   = 0 ; /* Full scale is all 16-bits */

int32_t RxFFT_Bins[FFT_BLOCKLEN] = {0}   ; /* Magnitude bins for the Rx FFT   */
int     BEW_Event                = false ; /* BEW Even flag                   */
int32_t RxFFT_SigSum             =  0    ; /* Sum of FFT Bins                 */

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static int16_t  Rx_ppbuf1[APKT_SAMPLES] IN_DTCM = {0} ; /* Rx Pingpong buffer 1*/
static int16_t  Rx_ppbuf2[APKT_SAMPLES] IN_DTCM = {0} ; /* Rx Pingpong buffer 2*/

/* Note that for the CMSIS DSP routines, there must be an even number of      */
/* Coefficients.  Since this filter has 91, I need an extra coefficient of 0  */
/* added to the end.                                                          */
static arm_fir_instance_q15 Voice_Instance                 = {0} ;
static q15_t Voice_Coefs[VOICEFILTER_TAP_NUM+1]            = {0} ;
static q15_t Voice_State[VOICEFILTER_TAP_NUM+APKT_SAMPLES] = {0} ;

/* Note that for the CMSIS DSP routines, there must be an even number of      */
/* Coefficients.  Since this filter has 23, I need an extra coefficient of 0  */
/* added to the end.                                                          */
static arm_fir_instance_q15 RSSI_Instance                  = {0} ;
static q15_t RSSI_Coefs[RSSIFILTER_TAP_NUM+1]              = {0} ;
static q15_t RSSI_State[RSSIFILTER_TAP_NUM+APKT_SAMPLES+1] = {0} ;

static TONE_CONTEXT RxCal_Context = {0,100000, 50,TONE_REPLACE} ; /* Rx Cal tone. (if used) */

/* This is the table to convert my HPF RSSI values into what would be reported*/
/* by a Voter.  I basically plunked these dBm settings into a service         */
/* monitor and got the second column of numbers. I then plunked the same dBm  */
/* settings into my Voter2, measured the HPF filter value and that is the     */
/* first column.  For live readings I just interpolate the HPF filter values  */
/* into Voter equivalent values.                                              */
static INTERPOLATE_PT hpf1_interpolate_table[HPF1_TABLESIZE] =
{
   {   0,255}, /*>-100dBm */
   { 148,253}, /* -100dBm */
   { 246,242}, /* -105dBm */
   { 432,208}, /* -110dBm */
   { 802,167}, /* -115dBm */
   {1237, 40}, /* -120dBm */
   {1370, 13}, /* -125dBm */
   {1371,  0}, /*<-125dBm */
};


/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void    MakeSigned(uint16_t*,int16_t*) ;
static void    DeEmphasis(int16_t*, int16_t*) ;
static void    Voice_Filter(int16_t*,int16_t*) ;
static uint8_t RSSI_HFilter(int16_t*,int16_t*) ;
static uint8_t RSSI_BEWfilter(int16_t*,int16_t*,uint8_t,int) ;
static int     Figger_RxActive(void) ;
static void    Set_Rx_LED(int) ;
static void    Figger_VPP(int16_t* in) ;
static uint8_t Choose_RSSI(uint8_t,uint8_t,uint8_t,int) ;
static void    FillTestPattern(uint16_t*) ;
static void    PutPulse(int,int,uint16_t*) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Rx_FilterInit
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : Filter tables
*
* This routine initializes all the filters used on the receive path.  They get
* initialized on power-up and if we get a new flag byte from the DIAL server.
*******************************************************************************/
void Rx_FilterInit(void)
{
   int i = 0 ;

   /* Examples say I need to reverse the filter taps - but aren't the         */
   /* coefs symmetric?                                                        */

   /* Pick the right voice filter depending on if talking to DIAL or not.     */
   /* Note that for the CMSIS DSP routines the choice of filter coefficients  */
   /* is made at initialization (here) versus for the T-Filter C routines the */
   /* choice of filter is made during data IO (in Voice_Filter()).            */
#if 0
   if (DIAL_ACTIVE && DIAL_NOSUBAUDIO)
   {
      for (i=0;i<VOICEFILTER_TAP_NUM;i++) Voice_Coefs[i]=VoiceFilter_taps[VOICEFILTER_TAP_NUM-i-1] ;
      arm_fir_init_q15(&Voice_Instance,VOICEFILTER_TAP_NUM,Voice_Coefs,Voice_State,APKT_SAMPLES) ;
   }
   else
   {
#endif
   /* This filter has 91 real coefficients, but the CMSIS routines must have  */
   /* even number of coefficients.  Interestingly, you can't have a high pass */
   /* filter with an even number of coefficients--I tried.  Instead the CMSIS */
   /* suggestion is to simply add an extra 0 coefficient at the end, so adding*/
   /* 1 to the CMSIS tap array size and setting the last entry to 0.          */
   for (i=0;i<VOICEFILTER_TAP_NUM;i++) Voice_Coefs[i]=VoiceFilter_taps[VOICEFILTER_TAP_NUM-i-1] ;
   Voice_Coefs[VOICEFILTER_TAP_NUM] = 0 ;
   arm_fir_init_q15(&Voice_Instance,VOICEFILTER_TAP_NUM+1,Voice_Coefs,Voice_State,APKT_SAMPLES) ;
//   }

   /* This filter has 23 real coefficients, but the CMSIS routines must have  */
   /* even number of coefficients.  Interestingly, you can't have a high pass */
   /* filter with an even number of coefficients--I tried.  Instead the CMSIS */
   /* suggestion is to simply add an extra 0 coefficient at the end, so adding*/
   /* 1 to the CMSIS tap array size and setting the last entry to 0.          */
   for (i=0;i<RSSIFILTER_TAP_NUM;i++) RSSI_Coefs[i]=rssi_filter_taps[RSSIFILTER_TAP_NUM-i-1] ;
   RSSI_Coefs[RSSIFILTER_TAP_NUM] = 0 ;
   arm_fir_init_q15(&RSSI_Instance,RSSIFILTER_TAP_NUM+1,RSSI_Coefs,RSSI_State,APKT_SAMPLES) ;
}

/*******************************************************************************
* Routine  : Rx_EnqPacket
* Gazintas : Rawdata - pointer to 16-bit audio samples (12 bits used)
*            Normally 160 samples)
* IOs      : None.
* Returns  : Nothing
* Globals  : Rx_Compressed - to AudioTask
*
* This routine is the common handler for a ping or pong buffers of a packets
* worth of audio samples.
* This is the supervisory routine to do all the work to filter, convert, and
* create a packet of data to be sent out.
*
* OPEN ISSUE: Data coming in is 12-bit unsigned audio samples (DAC values).
* The compression algos assume 16-bit signed samples.  Should I do all the DSP
* on 12-bit data then convert to 16-bit just for compression or do all the DSP
* on 16-bit data? I like less chance of overflows but might have better DSPing
* with more bits.  Going to go 16-bit for now.
*
* Execution time: 122us max with  analog RSSI (0.61% CPU load)
*                 168us max with     HPF RSSI (0.84% CPU load)
*                 207us max with DSP/BEW RSSI (1.04% CPU load)
*   - It gets a bit complicated in local mode where some Tx code runs under the
*      Rx ISR, above is for DIAL mode.
*******************************************************************************/
void Rx_EnqPacket(uint16_t* RawData,uint32_t TIM2_Trigger)
{
   int     Rx_Active     = false ; /* Repeater Rx Active             */
   uint8_t Rssi_Analog   = 0     ; /* RSSI based on analog signal    */
   uint8_t Rssi_HPF      = 0     ; /* RSSI based on high pass filter */
   uint8_t Rssi_BEW      = 0     ; /* RSSI based on BEQ algorithm    */
   uint8_t Selected_RSSI = 0     ; /* Selected RSSI value            */

 //AISR_SHOWSTART ;
   /* If RxTToneMode is not 0, then we are in Rx test mode.  In this mode Rx  */
   /* is always active and audio data is instead various test patterns based  */
   /* on the non-zero RxTToneMode value.                                      */
   if (RxTToneMode)
   {
      FillTestPattern(RawData) ;
      Rx_Active = true ;
   }
   else /* Regular mode, leave audio samples as-is & figger Rx_Active */
   {
      Rx_Active = Figger_RxActive() ;
   }

   /* *********************************************************************** */
   /* *********************************************************************** */
   /* THIS IS THE MAIN RECEIVE DSP COMPUTATIONAL SEQUENCE!!  Here is where we */
   /* convert ADC samples into packets ready to be sent to the DIAL server    */
   /* and/or Local State Machine!                                             */
   /* *********************************************************************** */
   /* *********************************************************************** */
   /* Inside each step I have ProbeCheck().  This allows the user to "probe"  */
   /* the audio signal after each step in the chain and see the results on    */
   /* DAC2.  What to probe is a CLI command.                                  */
   /* *********************************************************************** */

   MakeSigned  (RawData  ,Rx_ppbuf1) ; /* A2D format to DSP format            */
   Rssi_HPF = RSSI_HFilter(Rx_ppbuf1,Rx_ppbuf2) ; /* Above band (HPF) RSSI    */
   Rssi_BEW = RSSI_BEWfilter(Rx_ppbuf1,Rx_ppbuf2,Rssi_HPF,Rx_Active) ; /* BEW */
   Rssi_Analog = Get_Analog_RSSI(ANALOG_RSSI_INTERPOLATED) ; /* Analog RSSI   */
   DeEmphasis  (Rx_ppbuf1,Rx_ppbuf2) ; /* De-emphasis (optional)              */
   Voice_Filter(Rx_ppbuf2,Rx_ppbuf1) ; /* CTCSS filter (optional)             */
   /* Coming Maybe?: CTCSS detector                                           */

   /* Update the Rx LED and choose the desired RSSI source */
   Set_Rx_LED(Rx_Active) ;
   Selected_RSSI = Choose_RSSI(Rssi_HPF,Rssi_BEW,Rssi_Analog,Rx_Active) ;

   /* Go see what the max VPP is for this packet (for audio cal)              */
   Figger_VPP(Rx_ppbuf1) ;

   /* OK, all done DSPing, the data is ready to send to the DIAL server and   */
   /* local state machine.  Both state machines need to be called every       */
   /* packet regardless of if there is Rx Active or if we are in local or     */
   /* DIAL mode so they can maintain proper state values.  They use RX_Active */
   /* and DIAL_State to know what to do.                                      */
   /* The last ping pong buffer was Rx_ppbuf1, so tell Dialtask to use it.    */
#ifndef NODIALTASK
   /* Only enqueue data to the DIAL task if it exists!.  If compiled for a    */
   /* local mode only setup, then DIAL support doesn't exist.                 */
   Dial_Enqueue(Rx_ppbuf1,TIM2_Trigger,Rx_Active,Selected_RSSI) ;
#endif
   /* Even if connected to the DIAL server, still send packets to the local   */
   /* mode routines for other processing.  DIAL_State tells the local machine */
   /* whether to send audio on or not.                                        */
   LocalModeSM(Rx_ppbuf1,DIAL_State,Rx_Active) ;
 //AISR_SHOWEND ;

}

/*******************************************************************************
* Routine  : MakeSigned
* Gazintas : RawData - Audio samples in unsigned 12-bit offset format
* IOs      : SignedData - Audio samples in 16-bit signed format
* Returns  : Nothing
* Globals  : None
*
* This routine converts the raw A2D data which is 12-bit samples with "0V" at
* the middle of the A2D range into samples for the DSP routines which assume
* 16-bit signed data with 0V at 0.
* While here, I also determine the min and max values of the raw data coming
* in for the packet so we can report incoming signal volume.
*
* Execution time: 10.5us.
*******************************************************************************/
static void MakeSigned(uint16_t* RawData, int16_t* SignedData)
{
   int      i   =    0 ;
   uint16_t min = 2048 ;
   uint16_t max = 2048 ;

 //AISR_SHOWSTART ;
   for (i=0;i<APKT_SAMPLES;i++)
   {
      SignedData[i] = (int16_t)(((int32_t)(RawData[i])-2048)<<4) ;
      if (RawData[i] < min) min = RawData[i] ;
      if (RawData[i] > max) max = RawData[i] ;
   }

   /* Remember the Vin peak-peak voltage for Rx level calibration */
   VinPP = max - min ;

   /* This is for the levels status command.  It resets VinPP_Max each        */
   /* display cycle, then this below gets the max value until reset again.    */
   if (VinPP>VinPP_Max) VinPP_Max = VinPP ;

   /* Check for probing this output */
   ProbeCheck(SignedData,PROBE_RXIN,PROBE_AUDIO) ;
 //AISR_SHOWEND ;
}

/*******************************************************************************
* Routine  : DeEmphasis
* Gazintas : in - Audio samples (Emphasized)
* IOs      : out - Audio samples (De-Emphasized)
* Returns  : Nothing
* Globals  : None
*
* This routine implements a 75us (2.1KHz cutoff frequency) De-emphasis filter.
* Pretty sure this is just implemented as a single order low pass filter.  I'm
* using the Z transform to calculate the coefficients.  This is the standard C
* implementation.  Given its simplicity, I'm not sure it is a good candidate
* for the CMSIS DSP libraries.  It's certainly lower priority.
* 
* Vout[n]=(a/1+a)*Vin[n] + (1/1+a)*Vout[n-1] where a = 2*pi*(fc/fs)
*
* fc = cutoff frequency = 2.1KHz
* fs = sample frequency = 8.0KHz
* a  = 1.649336115
* a/(1+a) = 0.622546953 or 0x4FAF in Q15 format
* 1/(1+a) = 0.377453047 or 0x3050 in Q15 format
*
* LOTS OF ASSUMPTIONS INTO THIS CODE!!!  It works observationally, but
* definitely needs quantitative verification!!!
* At a minimum, the baseline code severely attenuaed even the passband, so I've
* added a 2.5x "amplifier".
*
* De-Emphasis is normally on except if disabled by the DIAL server when
* authenticated or overridden in local mode.
*
* Execution time:  5.4us (if enabled)
* Execution time:  1.8us (if bypassed)
*******************************************************************************/
static void DeEmphasis(int16_t* in, int16_t* out)
{
#define DE_EMPH_COEF_N   0x4faf
#define DE_EMPH_COEF_NM1 0x3050

   static int16_t last = ADAC_0V ; /* Last sample from previous packet */
   int i = 0 ;

 //AISR_SHOWSTART ;
   if ((DIAL_NOTAUTHORIZED && LocalDeemph) || (DIAL_ACTIVE && (!DIAL_FLATAUDIO)))
   {
      /* First output sample uses last sample from previous frame */
      out[0] = (int16_t)((((int32_t)in[0]*DE_EMPH_COEF_N + (int32_t)last*DE_EMPH_COEF_NM1)>>16)) ;

      /* Rest of the samples in a loop */
      for (i=1;i<APKT_SAMPLES;i++)
      {
         out[i] = (int16_t)((((int32_t)in[i]*DE_EMPH_COEF_N + (int32_t)out[i-1]*DE_EMPH_COEF_NM1)>>16)) ;

         /* Now for the post-processing gain , currently 2.5 */
         out[i-1] = ((int32_t)out[i-1]*5)/2 ;
      }

      /* Finally save the last output coefficient for the next call */
      last = out[APKT_SAMPLES-1] ;

      /* ...and gain for the last sample */
      out[APKT_SAMPLES-1] = ((int32_t)out[APKT_SAMPLES-1]*5)/2 ;

   }
   else /* DeEmphasis not requested */
   {
	   memcpy(out,in,APKT_SAMPLES*2) ;
   }
   
   /* Check for probing */
   ProbeCheck(out,PROBE_RXDEM,PROBE_AUDIO) ;
 //AISR_SHOWEND ;
}

/*******************************************************************************
* Routine  : Voice_Filter
* Gazintas : in - Audio samples (full spectrum)
* IOs      : out - Audio samples (voice frequencies only--maybe)
* Returns  : Nothing
* Globals  : None
*
* This routine implements either a 300Hz high pass filter (filtering out CTCSS
* frequencies or passes through audio unchanged (no CTCSS filtering) depending
* on the FLATAUDIO bit in the DIAL flags byte.
* If we are in local mode, CTCSS is always filtered.
* The coefficients come from TFilter http://t-filter.engineerjs.com/
* VoiceFilter.c has their standard C implementation.  If using the CMSIS DSP
* library, all I use is the coefficients, not the code.
*
* This routine attenuates even in the passband too.  It needs an extra 1.5x
* "amplifier" afterwards.
*
* Execution time:  86us (if enabled)
* Execution time: 1.8us (if bypassed)
*******************************************************************************/
static void Voice_Filter(int16_t* in, int16_t* out)
{

 //AISR_SHOWSTART ;
   /* See if we are filtering or not */
   if (DIAL_ACTIVE && DIAL_FLATAUDIO)
   {
      arm_fir_q15(&Voice_Instance,in,out,APKT_SAMPLES) ;
   }
   else /* Not filtering, just copy in to out */
   {
      memcpy(out,in,APKT_SAMPLES*2) ;
   }

   /* Check for probing */
   ProbeCheck(out,PROBE_RXVOICE,PROBE_AUDIO) ;
 //AISR_SHOWEND ;

}

/*******************************************************************************
* Routine  : RSSI_HFilter
* Gazintas : in - Audio samples (full spectrum)
* IOs      : out - identical RSSI values (for analog out monitoring)
* Returns  : RSSI value (0-255) (same as out samples above)
* Globals  : Hpf_RSSI - HPF-based RSSI value (0-255)
*
* This routine implements a 2400Hz - 4000Hz high pass filter, then does an
* energy measurement to get an RSSI value from 0-255.  The only reason for
* noise above 2400Hz is if the incoming signal is weak, so the higher the
* noise the lower the RSSI.
*
* Execution time: 26us (if enabled)
*******************************************************************************/
#define HPFRSSI_AVGLEN 3 /* Number of HPF RSSI values to average */

static uint8_t RSSI_HFilter(int16_t* in, int16_t* out)
{
   static uint8_t RSSI_Buf[HPFRSSI_AVGLEN] = {0} ; /* RSSI value buffer   */
   static int     RSSI_Index               =  0  ; /* RSSI buffer pointer */

 //AISR_SHOWSTART ;
   uint64_t rms_accum    = 0 ; /* Accumulator for RMS value       */
   int32_t Instant_rssi  = 0 ; /* RSSI value for just this packet */
   int32_t Averaged_rssi = 0 ; /* Averaged RSSI value reported    */
   int i = 0 ;

   /* Do HPF if we're doing diagnostics or any RSSI mode except analog */
   if (RxDiags || (Settings.RssiMode!=RSSI_ANALOG))
   {

      /* Use the CMSIS DSP routine to do the filtering.                       */
      /* Then accumulate the sum of squares of the output.                    */
      arm_fir_q15(&RSSI_Instance,in,out,APKT_SAMPLES) ;
      for (i=0;i<APKT_SAMPLES;i++) rms_accum += out[i]*out[i] ;

      /* I now have the sum of the squares of the filtered samples, get the   */
      /* square root of it to get RMS.                                        */
      /* NOTE: not sure sqrt() is a good idea, it's floating point! Seems the */
      /* Coretex M7s floating point unit does this nice and fast!             */
      rms_accum = sqrt(rms_accum/APKT_SAMPLES) ;

      /* Get the instantaneous RSSI value for just this packet.  It is noisy, */
      /* so I do a bit of averaging later.                                    */
      Instant_rssi = interpolate(rms_accum,hpf1_interpolate_table,HPF1_TABLESIZE) ;

     /* Check for probing of the RSSI signal */
      ProbeCheck(out,PROBE_RSSSIG,PROBE_AUDIO) ;

      /* If we're probing the RSSI level instead of the raw signal, copy the  */
      /* RSSI value into the entire packet for the DAC. This way the debug DAC*/
      /* output will show the RSSI level for the given audio packet.          */
      /* The RSSI value is multipled by 16 go get a 0-4096 range for the DAC. */
      /* Purposely, show the instant RSSI value, not the averaged one.        */
      if (PROBE_RSSLVL==AnalogProbe)
      {
         for (i=0;i<APKT_SAMPLES;i++) out[i] =  Instant_rssi*16 ;
         ProbeCheck(out,PROBE_RSSLVL,PROBE_RAW) ;

      }

      /* HPF RSSI is measuring noise which is--not surprisingly--noisy! :).   */
      /* For basic HPF RSSI values, just average a few packets.  You do want  */
      /* to keep HPFRSSI_AVGLEN small as this slows response time and will    */
      /* degrade effectiveness for things like picket fencing where signal    */
      /* changes rapidly.                                                     */
      RSSI_Buf[RSSI_Index] = Instant_rssi ;
      RSSI_Index = (RSSI_Index+1)%HPFRSSI_AVGLEN ;
      for (i=0;i<HPFRSSI_AVGLEN;i++) Averaged_rssi +=RSSI_Buf[i] ;
      Averaged_rssi = Averaged_rssi/HPFRSSI_AVGLEN ;

      /* Save a copy in a global place for the status rssi command */
      Hpf_RSSI = Averaged_rssi ;
   } /* if HPF enabled */

   /* If HPF isn't enabled, just return 0, that's fine */

 //AISR_SHOWEND ;
   return(Averaged_rssi) ;
}

/*******************************************************************************
* Routine  : RSSI_BEWilter
* Gazintas : in - Audio samples (full spectrum)
*          : Rssi_HPF - HPF-derived RSSI value
*          : Rx_Active - Rx is active flag
* IOs      : out - not touched
* Returns  : RSSI value (0-255)
* Globals  :
*
* This routine implements the DSP/BEW (Baseband Examination Window) algorithm as
* designed and implemented by ??? and implemented in the original Voter.
* Thanks to Mason (N5LSN) for doing his AI magic to get me a summary and
* analysis of what this algorithm is, making implementation a lot easier. His
* report is here:
* https://github.com/Mason10198/Voter/blob/n5lsn-dev/docs/DSP_BEW_feature.md
*
* High level theory:
*  - Do an FFT on the first 32 samples of each packet
*  - Add up the energy bins except for 0-500Hz and >3500Hz
*  - If less than a magic threshold, use regular HPF RSSI
*  - If more, keep on using an older RSSI until you drop below the threshold
*
* The ideas is if you get a sudden broadband signal, that extra energy could be
* incorrectly interpreted as low signal strength.  Just keep the old RSSI while
* that signal is present.
*
* (later, only execute this code if BEW is enabled and Rx_Active is true.
*  Right now on always is great for debugging)
*
* Execution time: 41.8us (if enabled)
* Execution time:  1.2us (if bypassed--could be improved)
*******************************************************************************/
static uint8_t RSSI_BEWfilter(int16_t* in, int16_t* out,uint8_t Rssi_HPF,int Rx_Active)
{
   static uint8_t RSSI_History[RSSI_HISTLEN] = {0} ;

 //AISR_SHOWSTART ;
   int     i                          =  0  ; /* General counter      */
   int16_t BEW_Window[FFT_BLOCKLEN]   = {0} ; /* Our sample window    */
   int16_t BEW_FFTout[FFT_BLOCKLEN*2] = {0} ; /* FFT result (2x size) */
   arm_rfft_instance_q15 S            = {0} ; /* CMSIS FFT instance   */
   uint8_t BEWrssi                    =  0  ; /* Final RSSI value     */

   /* Do HPF if we're doing diagnostics or BEW modes */
   if (RxDiags || (RSSI_BEW1==Settings.RssiMode) || (RSSI_BEW2==Settings.RssiMode))
   {
      /* Copy over just our sample window. Important as the CMSIS docs say    */
      /* the input buffer does get modified.                                  */
      /* For the FFT to not overflow, the signal can't exceed +-0.5 (Q15      */
      /* format so there are two ways below to do that.                       */
      for (i=0;i<FFT_BLOCKLEN;i++)
      {
         if (RSSI_BEW1==Settings.RssiMode)
         {
            /* In BEW1 mode, the input is just divided by two */
            BEW_Window[i] = in[i]/2 ;
         }
         else
         {
            /* In BEW2 mode, the input is not divided, but clipped at 50% */
            BEW_Window[i] = in[i] ;
            if (BEW_Window[i] >  16383) BEW_Window[i] =  16383 ;
            if (BEW_Window[i] < -16383) BEW_Window[i] = -16383 ;
         }
      }

      /* Do the FFT thang! */
      arm_rfft_init_q15(&S, FFT_BLOCKLEN, FFT_FWD_XFORM, FFT_NOBITREVERSE) ;
      arm_rfft_q15(&S,BEW_Window, BEW_FFTout);

      /* Get the magnitude squared (!) of each bin. This seems weird to not   */
      /* take the real magnitude (square root of sum of the squares), but     */
      /* that is what the Voter2 code does, so doing the same thing.          */
      /* Between recasting to int32_t and squaring, lots of parenthesis!!     */
      /*  - RxFFT_Bins is global so status rxfft can show results.            */
      for (i=0;i<FFT_BINLEN;i++)
      {
         RxFFT_Bins[i] = ((int32_t)(BEW_FFTout[i*2  ]))*((int32_t)(BEW_FFTout[i*2  ])) +
                         ((int32_t)(BEW_FFTout[i*2+1]))*((int32_t)(BEW_FFTout[i*2+1])) ;
      }

      /* Add up all the bins except for the bottom two (DC and CTCSS) and top */
      /* (at Nyquist) to get an idea if we are having a major signal event    */
      /*  - RxFFT_SigSum is global so status rxfft can show results.          */
      RxFFT_SigSum = 0 ;
      for (i=2;i<(FFT_BINLEN)-1;i++) RxFFT_SigSum += RxFFT_Bins[i] ;

      /* See if we're greater than the BEW_THRESHOLD.  If we are, then this   */
      /* is a BEW event, time to adjust RSSI!                                 */
      /*  - BEW_Event is global so status rxfft can show results.             */
      BEW_Event = (RxFFT_SigSum>BEW_THRESHOLD) ;

      if (!BEW_Event)
      {
         /* If not a BEW event, just use the "regular" RSSI */
         BEWrssi = Rssi_HPF ;

         /* and keep a regular running history */
         RSSI_History[0] = RSSI_History[1] ;
         RSSI_History[1] = RSSI_History[2] ;
         RSSI_History[2] = BEWrssi         ;
      }
      else
      {
         /* Its a BEW event, do the BEW RSSI processing. */
         /* Fill the RSSI history with the RSSI from three packets ago */
            RSSI_History[1] = RSSI_History[0] ;
            RSSI_History[2] = RSSI_History[0] ;
            BEWrssi         = RSSI_History[0] ;
      }

      /* If Rx isn't active, force BEWrssi to zero and clear out the history  */
      /* as well.                                                             */
      if (!Rx_Active)
      {
         RSSI_History[0] = 0 ;
         RSSI_History[1] = 0 ;
         RSSI_History[2] = 0 ;
         BEWrssi         = 0 ;
      }
   } /* iF BEW enabled */

   /* If BEW isn't enabled, just return 0, that's fine */

 //AISR_SHOWEND ;
   return(BEWrssi) ;
}

/*******************************************************************************
* Routine  : Figger_RxActive
* Gazintas : None (GPIO's sampled)
* IOs      : None
* Returns  : true if RX is active
* Globals  : Settings
*
* This routine looks at the COR (valid carrier) and RDSTAT (valid CTCSS) GPIO
* inputs and based on the RxMode setting, determines if Rx is active.
* This may get more complicated with RSSI processing as well at some point.
*******************************************************************************/
static int  Figger_RxActive(void)
{
   int retval = false ;

   switch (Settings.RxMode)
   {
      case RXMODE_OFF  : retval = false                        ; break ;
      case RXMODE_COR  : retval = COR_State()                  ; break ;
      case RXMODE_CTCSS: retval = RDSTAT_State()               ; break ;
      case RXMODE_BOTH : retval = COR_State() & RDSTAT_State() ; break ;
      case RXMODE_ON   : retval = true                         ; break ;
      default          : retval = false                        ; break ;
   }

   return(retval) ;
}

/*******************************************************************************
* Routine  : Set_Rx_LED
* Gazintas : RxActive - Rx is active (via user-selected method)
* IOs      : None
* Returns  : Nothing
* Globals  : VinPP - DAC input Peak-Peak voltage (0-4096 scale)
*
* This routine sets the Rx LED according to the following logic:
*  - RxActive false                               : LED off    (no valid carrier)
*  - RxActive true, Vpp < VINPP_MIN               : LED Yellow (carrier, low audio)
*  - RxActive true, VINPP_MIN < VinPP < VINPP_MAX : LED Green  (carrier, good audio)
*  - RxActive true, Vpp > VINPP_MAX               : LED Red    (carrier, overdriving audio)
*******************************************************************************/
static void Set_Rx_LED(int RxActive)
{
   int color          = RSSI_NOSIG ; /* Default   */
   static int LastCol = RSSI_NOSIG ; /* Save last */

        if (RxActive && (VinPP < VINPP_MIN)) color = RSSI_LOW ;
   else if (RxActive && (VinPP > VINPP_MAX)) color = RSSI_HIGH ;
   else if (RxActive) color = RSSI_GOOD ;

   /* Only write a new color if it is different from the previous colors.     */
   /* Just save lots of IO writes and probably noise.  This also allows the   */
   /* startup blinky light sequence to work.                                  */
   if (LastCol!=color) Show_State(RSSI_STATE,color) ;
   LastCol = color ;
}

/*******************************************************************************
* Routine  : Choose_RSSI
* Gazintas : Rssi_HPF - High pass filter RSSI value
*          : Rssi_BEW - BEW algorithm RSSI value
*          : RSSI_Analog - Analog RSSI value
*          : Rx_Active - Rx Active state
* IOs      : None
* Returns  : Selected RSSI value or 0 if Rx_Active isn't asserted.
* Globals  : None
*
* This is the top level routine to get the RSSI value.  Sources for RSSI depend
* on the users rssimode setting, analog or HPF.  (more to come!)
* If RxActive is not active, then the return RSSI is forced to 0 regardless of
* the analog or HPF value.
*******************************************************************************/
static uint8_t Choose_RSSI(uint8_t Rssi_HPF,uint8_t Rssi_BEW,uint8_t RSSI_Analog,int Rx_Active)
{
   uint8_t rval = 0 ; /* Selected RSSI value */

   if (Rx_Active) /* Only override default of 0 if Rx is active. */
   {
      if      (RSSI_ANALOG==Settings.RssiMode) rval = RSSI_Analog ;
      else if (RSSI_HPF   ==Settings.RssiMode) rval = Rssi_HPF    ;
      else if (RSSI_BEW1  ==Settings.RssiMode) rval = Rssi_BEW    ;
      else if (RSSI_BEW2  ==Settings.RssiMode) rval = Rssi_BEW    ;
   }

   return(rval) ;
}

/*******************************************************************************
* Routine  : Figger_VPP
* Gazintas : in - packet of audio samples
* IOs      : None
* Returns  : Nothing
* Globals  : PreComp_VPP
*
* This routine scans a packet of audio, looks for the min and max values, and
* if the delta (Vpp) is greater than the global PreComp_VPP, sets PreComp_VPP
* to the new bigger value.  This routine does not reset PreComp_VPP, that is
* done by the supervising routine so it can get a max VPP over many packets.
*******************************************************************************/
static void Figger_VPP(int16_t* in)
{
   int i   = 0 ; /* Counter          */
   int min = 0 ; /* Packet min value */
   int max = 0 ; /* Packet max value */
   int Vpp = 0 ; /* Packet Vpp value */

   for (i=0;i<APKT_SAMPLES;i++)
   {
      if (in[i]<min) min = in[i] ;
      if (in[i]>max) max = in[i] ;
   }
   Vpp = max - min ;
   if (Vpp>PreComp_Vpp) PreComp_Vpp = Vpp ;
}

/*******************************************************************************
* Routine  : FillTestPattern
* Gazintas : None
* IOs      : RawData - 160 16-bit Raw ADC values (a packet)
* Returns  : Nothing
* Globals  : None
*
* This routine gets called if we are in special test modes.  In this mode the
* ADC data gets over written by test patterns that make checking for sync
* between two Voter2s easier.  They are simple pulse waveforms with different
* intervals to ensure we are synchronized at both the intra and inter packet
* levels.  The test patterns based on RxTToneMode are:
*  0 - Not in test mode (this routine not called)
*  1 - Timing Pulse at the start of every packet
*  2 - Timing Pulse every 4th packet.
*  3 - Timing Pulse every 11th packet.
*  4 - 1KHz tone at level that should correspond to 3KHz deviation.
*  Rest - RFU, for now silence
*
*  The reason for 4 and 11 for Timing pulses is to make sure I'm not off by an
*  amount exactly equal to my sequence out.  If I'm in sync every 4th and 11th
*  packet, then I would need to be off by exactly 44 packets to have a "false"
*  sync on both.
*******************************************************************************/
static void FillTestPattern(uint16_t* RawData)
{
   static int PktCount = 0 ; /* Packet sequencer */

   switch (RxTToneMode)
   {
      case  1: PktCount = (PktCount+1)%1  ; PutPulse(PktCount,1,RawData) ; break ;
      case  2: PktCount = (PktCount+1)%4  ; PutPulse(PktCount,1,RawData) ; break ;
      case  3: PktCount = (PktCount+1)%11 ; PutPulse(PktCount,1,RawData) ; break ;
      case  4: AddATone12u(RawData,RawData,&RxCal_Context)               ; break ;
      default: PutPulse(1,1,RawData) /* Silence always */                ; break ;
   }
}

/*******************************************************************************
* Routine  : PutPulse
* Gazintas : trigger - Only put the pulse if this value is 0
*          : start - starting sample point for the test pulse
* IOs      : RawData - Packet of data to put the test pulse in
* Returns  : Nothing
* Globals  : None
*
* This routine plunks in the test pulse into the packet of data if the trigger
* value is zero.  The packet becomes pure silence if trigger isn't zero.
*******************************************************************************/
static void PutPulse(int trigger,int start,uint16_t* RawData)
{
   int i = 0 ; /* counter */

   /* First start off with silence.  Since this is emulating ADC values, 0V   */
   /* is the mid point or 2048.                                               */
   for(i=0;i<APKT_SAMPLES;RawData[i++]=2048) ;

   if (0==trigger)
   {
      RawData[start++] = 1280 ;
      RawData[start++] = 2048 ;
      RawData[start++] = 2816 ;
      RawData[start++] = 3854 ;
      RawData[start++] = 3854 ;
      RawData[start++] = 3854 ;
      RawData[start++] = 2816 ;
      RawData[start++] = 2048 ;
      RawData[start++] = 1280 ;
      RawData[start++] =  512 ;
      RawData[start++] =  512 ;
      RawData[start++] =  512 ;
      RawData[start++] = 1280 ;
      RawData[start++] = 2048 ;
      RawData[start++] = 2816 ;
   }
}
