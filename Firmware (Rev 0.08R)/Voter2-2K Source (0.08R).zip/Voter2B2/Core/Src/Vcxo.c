/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Vcxo file.  It is in charge of managing the 10MHz VCOCXO if    */
/* It is loaded.  It is dormant otherwise.  This loops counts timer ticks per */
/* GPS 1PPS and adjusts the control voltage to the VCXO to get it exactly at  */
/* 10MHz.  Of note, that 10MHz goes into a PLL, so I see 40MHz here.          */
/* This code supports two different DACs, but as a compile time switch, not   */
/* dynamically.  It also supports a VCXO as well as an OCVCXO.  Alas the      */
/* cheaper VCXO didn't work well enough (no surprise).                        */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Find_Vcxo - Find if VCXO is loaded                                      */
/*  - Vcxo_Loop - Loop routine                                                */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <stdio.h>
#include <string.h>

#include "Options.h"
#include "main.h"
#include "Vcxo.h"
#include "Timers.h"
#include "Settings.h"
#include "I2C.h"
#include "Debugging.h"
#include "Logger2rt.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
//#define DAC8571 /* If undefined, it will be the AD5693      */
#define OCVCXO    /* if undefined, it is a VCXO (didn't work) */

#define VCXO_HISTORY           25 /* VCXO clock count history queue size      */
                                  /* Must be <=100 or you get overflows.      */

#define DAC_VMIN             5934 /* VCXO min input voltage - 0.3V -10ppm     */
#define DAC_VMAX            59602 /* VCXO min input voltage - 3.0V +10ppm     */

#ifdef OCVCXO
#define DAC_SLOPE            1000 /* Slope in PPTrillion(!!) per DAC bit      */
#else
#define DAC_SLOPE            5000 /* Slope in PPTrillion(!!) per DAC bit      */
#endif

#ifdef DAC8571
#define DAC8571_I2CADDR      0x98 /* DAC I2C bus address */
#define DAC8571_CTL_DATA     0x00 /* Control word for data write              */
#define DAC8571_CTL_PWR      0x01 /* Control word for Power Down cmdegister   */
#define DACADDR (DAC8571_I2CADDR) /* DAC I2C bus address */

#define DAC8571_CMD_INPUT    0x00 /* Command - Data to staging reg only       */
#define DAC8571_CMD_DACREG   0x10 /* Command - Data to staging and DAC        */
#define DAC8571_CMD_TMPREG   0x20 /* Command - Staging data to DAC            */
#define DAC8571_CMD_BCSTREG  0x30 /* Command - Broadcast update               */

#else /* AD5693 */
#define AD5693_I2CADDR      0x98 /* DAC I2C bus address */
#define AD5693_CMD_NOP      0x00 /* Command - NOP                             */
#define AD5693_CMD_INPUT    0x10 /* Command - Write input staging register    */
#define AD5693_CMD_UPDATE   0x20 /* Command - Send staging value to DAC       */
#define AD5693_CMD_DACREG   0x30 /* Command - Write directly to DAC output    */
#define AD5693_CMD_CONTROL  0x40 /* Command - Write control bits              */
#define DACADDR (AD5693_I2CADDR) /* DAC I2C bus address */

#define AD5693_NOVREF     0x1000 /* Control word for disabled VREF            */
#endif

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
int      Vcxo_present = false  ; /* VCXO present flag */
uint16_t Vcxo_DACval  = 0x8000 ; /* VCXO DAC value    */

int      VcxoDValid  = false ; /* Data valid flag (for status)       */

uint32_t disp_history[DISP_HISTORY] = {0} ; /* Sample history for display */

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
#if 1
static int32_t clk_history[VCXO_HISTORY] = {0} ; /* Sample history    */
static uint32_t FreqInt     =  0    ; /* Avg Frequency integer part         */
static uint32_t FreqFrac    =  0    ; /* Avg Frequency fractional part      */

static int32_t LimitTable[25] =
   {    0,50000,25000,17000,13000, /* This is the limit by sample number to say that if the  */
    10000, 9000, 8000, 7000, 6000, /* PPB error is greater than this value, go ahead and do  */
     5000, 5000, 5000, 4000, 4000, /* a DAC update.  It is basically double the possible     */
     4000, 4000, 2000, 2000, 2000, /* quantization error for that many samples.              */
     2000, 2000, 2000, 2000, 2000  /* It is in PPT instead of PPB, BTW (!).                  */
   } ;
#endif
/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void Write_VCXO_DacReg(uint8_t,uint16_t) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Find_Vcxo
* Gazintas : Nothing
* IOs      : None.
* Returns  : Nothing
* Globals  : Vcxo_Present
*
* This routine gets called on startup to see if a VCXO is present.  It does this
* by checking to see if there is a DAC on the I2C bus.
* If the DAC is present, it is initialized as well.
*******************************************************************************/
void Find_Vcxo(void)
{
#ifndef DAC8571 /* If undefine, it will be the AD5693 */
   if (I2C_SharedIsReady(DACADDR,2,3,true))
   {
      Vcxo_present = true ;

      /* Only change from the power-up defaults is we are using an external   */
      /* voltage reference, so disable the internal one.                      */
      Write_VCXO_DacReg(AD5693_CMD_CONTROL,AD5693_NOVREF) ;

      /* Set the DAC value to the setting stored in NVM.                      */
      Write_VCXO_DacReg(AD5693_CMD_DACREG,Settings.Vcxo_DACval) ;
   }
#else
   if (I2C_SharedIsReady(DACADDR,2,3,true))
   {
      Vcxo_present = true ;

      /* Set the DAC value to the setting stored in NVM.                      */
      Write_VCXO_DacReg(DAC8571_CMD_DACREG,Settings.Vcxo_DACval) ;
   }
#endif
}

/*******************************************************************************
* Routine  : Vcxo_Loop
* Gazintas : Nothing
* IOs      : None.
* Returns  : Nothing
* Globals  : New_CP1PPS_L (new count flag), TicksP1PPS (ticks per PPS)
*
* This routine gets called by MainTask every 100ms (its loop time).  If
* New_CP1PPS_L is set (only once a second), then it looks at that delta and
* decides if it needs to adjust the value for the DAC driving the VCOCXO.
*
* Attempt #2 of this control loop is trying to be more dynamic instead of modal.
* After ignoring the first count after a change, the loop looks at the ppb error
* amount.  If it is large it makes a correction quickly to try and react sooner.
* If the error is low, it will accumulate more samples and average them out to
* get more accurate readings up to the max of 25 readings for full 1ppb
* resolution.
*******************************************************************************/
void Vcxo_Loop(void)
{
#if 0 /* Bring-up code first */
   static int Seq = 0 ;

   if (Seq&1) /* Alternating condition */
   {
      Write_VCXO_DacReg(DAC8571_CMD_DACREG,DAC_VMIN) ;
   }
   else
   {
      Write_VCXO_DacReg(DAC8571_CMD_DACREG,DAC_VMAX) ;
   }

   Seq++ ;

#else
   static int Sequencer =  0    ; /* Sample Sequencer counter           */
   static int DispIndex =  0    ; /* Display sample index               */

   int      i           =  0    ; /* General counter                    */
   int32_t  FreqSum     =  0    ; /* Sum of historical frequencies      */
   int32_t  DACDelta    =  0    ; /* DAC adjustment value               */
   int32_t  PPTDelta    =  0    ; /* Delta from ideal frequency (PPT)   */
   char     AdjMode[16] = {0}   ; /* Adjustment mode string             */
   int      DoDACUpdate = false ; /* DAC update flag                    */
   int      logmode     =  0    ; /* Log mode                           */

   /* This routine gets called by MainTask many times per second always,      */
   /* Only care if we have a VCXO and we recently got a GPS 1PPS tick.        */
   if (Vcxo_present && New_CP1PPS_L)
   {
      /* I generate fake 1PPS's sometimes to keep some things going, so here  */
      /* I only want 1PPSes when we have a confirmed GPS lock.                */
      if (GPSLocked)
      {
         /* The sequencer controls the process.  State 0 is the state after   */
         /* updating the DAC. The VCXO needs some settling time after the     */
         /* change, so no timer information is stored in state 0.  We just    */
         /* clear out our accumulators.  Data starts getting stored in state  */
         /* 1.                                                                */
         if (0==Sequencer)
         {
            /* Note that this is a skipped sample */
            strcpy(AdjMode,"-S-") ;
            logmode = LOG_REGIO ;
         }
         else /* After 0, start doing stuff */
         {
            /* Add this clock sample data to our sample array */
            clk_history[Sequencer-1] = ClocksP1PPS ;

            /* Keep a running tab of the last 25 clock counts for the CLI     */
            /* status command.                                                */
            disp_history[DispIndex] = ClocksP1PPS ;
            DispIndex = (DispIndex+1)%DISP_HISTORY ;

            /* Add up all the clocks accumulated so far */
            for (i=0;i<Sequencer;i++)
            {
               FreqSum += clk_history[i] ;
            }

            /* Calculate the delta in PPT (yes, trillion!) */
            PPTDelta = ((FreqSum-40000000*Sequencer)*PPT_PHZ)/Sequencer ;

            /* We do a DAC update either if the error is greater than the     */
            /* allowable range for the sample count or we get up to our max   */
            /* sample size of 25 samples.                                     */
            if ((PPTDelta>LimitTable[Sequencer]) || (PPTDelta<-LimitTable[Sequencer]) ||
                Sequencer>=(VCXO_HISTORY-1))
            {
               DACDelta = -PPTDelta/DAC_SLOPE ;
               Vcxo_DACval += DACDelta ;
               DoDACUpdate = true ;

               /* Limit the DAC rane just in case */
               if (Vcxo_DACval > DAC_VMAX) Vcxo_DACval = DAC_VMAX ;
               if (Vcxo_DACval < DAC_VMIN) Vcxo_DACval = DAC_VMIN ;

               /* Update the DAC and prepare the logging string entry. */
#ifndef DAC8571 /* If undefine, it will be the AD5693 */
               Write_VCXO_DacReg(AD5693_CMD_DACREG,Vcxo_DACval) ;
#else
               Write_VCXO_DacReg(DAC8571_CMD_DACREG,Vcxo_DACval) ;
#endif
               sprintf(AdjMode,"%4lddDAC",DACDelta) ;
               logmode = LOG_SUPPORT ;
            }
            else
            {
               /* If  no DAC update, say we're just sampling */
               strcpy(AdjMode,"-A-") ;
               logmode = LOG_REGIO ;
            }
         }

         /* Now get the averaged frequency integer and fractional (1000th)    */
         /* parts.  Order matters to minimize integer rounding errors         */
         if (Sequencer) /* avoid math if sequencer value is zero!             */
         {
            FreqInt  = FreqSum/Sequencer ;
            FreqFrac = ((FreqSum-(FreqInt*Sequencer))*1000)/Sequencer ;
         }

         Logger2_Msg(Logger.Vcxo,logmode,LOG_TIME,"VCXO : (%2d) %8dHzI %8d.%3.3dHzA %5dPPB %8s %6dDAC\r\n",Sequencer,ClocksP1PPS,FreqInt,FreqFrac,PPTDelta/1000,AdjMode,Vcxo_DACval) ;

         /* increment the sequencer until a DAC update, then reset it */
         Sequencer = (DoDACUpdate)? 0:Sequencer+1 ;

         /* Finally, make this data available to the status 10mhz command */
         VcxoDValid = true ;

      } /* If GPS locked */
      /* All done, clear the loop flag and wait for the next GPS1PPS */
      New_CP1PPS_L = false ;
   }
#endif
}

/*******************************************************************************
* Routine  : Write_VCXO_DacReg
* Gazintas : Reg - Register address
*          : Regval - Register value (16 bit)
* IOs      : None.
* Returns  : Nothing
* Globals  : None
*
* This routine writes a 16-bit value to the specified DAC register.
*******************************************************************************/
static void Write_VCXO_DacReg(uint8_t Reg, uint16_t Regval)
{
static IN_DMADD2 uint8_t seq[2] = {0} ; /* Bytes to send. Static and uncached */

   /* Set up the data string in DMA-able space */
   seq[0] = (Regval>>8)&0xff ;
   seq[1] =  Regval    &0xff ;

   /* I get to use the I2C memory write command using the command byte as the */
   /* address!                                                                */
   I2C_SharedMemWrite(DACADDR,Reg,I2C_MEMADD_SIZE_8BIT,seq,2,true) ;

}
