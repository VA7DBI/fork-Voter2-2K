/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/* ************************************************************************** */
/* This is the MainTask file.  This is the main supervisory task running      */
/* Voter2.  Right now it is just doing some debug variable monitoring Status  */
/* LED blinking, and the system watchdog.                                     */
/* On startup it loads in all the CLI commands and does the all important LED */
/* blinky routine.                                                            */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - MainTask - Just that, the main (but kinda useless) task!                */
/*                                                                            */
/******************************************************************************/
// To Do:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"
#include "task.h"

#include "Options.h"
#include "main.h"
#include "logger2rt.h"
#include "Gpio.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "DialTaskOut.h"
#include "DialTaskIn.h"

/* These are all for registering CLI commands */
#include "ConsoleTask.h"
#include "Utils.h"
#include "Settings.h"
#include "GPS.h"
#include "Timers.h"
#include "RTC.h"
#include "Status.h"
#include "SetShow.h"
#include "TTones.h"
#include "xuart.h"
#include "MtrSpi.h"
#include "Update.h"
#include "Histograms.h"
#include "Vcxo.h"
#include "Ping.h"

/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/

/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
void ShowHeartbeat(void) ;
void ShowIPStats(void) ;
void ShowGPSState(void) ;
void ShowDIALState(void) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : MainTask
* Gazintas : None
* IOs      : None
* Returns  : Never
* Globals  : TBD
*
* This is the supervisory Main Task.  It don't do much!
*******************************************************************************/
void MainTask(void const * argument)
{

   /* Startup sequencing enforcement. See Options.h */
   osDelay(StartDelay_MainTask) ;
   Logger2_Msg(Logger.MainApp,LOG_MAJOR,LOG_TIME,"MainTask : Start\r\n") ;

   /* Register the CLI commands.  If you want them displayed in alphabetical  */
   /* order by help, register them below in alphabetical order.               */
   /* I need a common place somewhere to register commands and this seems the */
   /* best place.                                                             */
   MyCLI_Register(cmd_cls_cmd,      cmd_cls_cmdsc,     cmd_cls_help,      Cmd_cls     ) ;
   MyCLI_Register(cmd_help_cmd,     cmd_help_cmdsc,    cmd_help_help,     Cmd_help    ) ;
   MyCLI_Register(cmd_jitter_cmd,   cmd_jitter_cmdsc,  cmd_jitter_help,   Cmd_jitter  ) ;
   MyCLI_Register(cmd_logout_cmd,   cmd_logout_cmdsc,  cmd_logout_help,   Cmd_logout  ) ;
   MyCLI_Register(cmd_mtrspi_cmd,   cmd_mtrspi_cmdsc,  cmd_mtrspi_help,   Cmd_mtrspi  ) ;
   MyCLI_Register(cmd_netdelay_cmd, cmd_netdelay_cmdsc,cmd_netdelay_help, Cmd_netdelay) ;
 //MyCLI_Register(cmd_ping_cmd,     cmd_ping_cmdsc,    cmd_ping_help,     Cmd_Ping    ) ; Not working yet
   MyCLI_Register(cmd_rtc_cmd,      cmd_rtc_cmdsc,     cmd_rtc_help,      Cmd_rtc     ) ;
   MyCLI_Register(cmd_reboot_cmd,   cmd_reboot_cmdsc,  cmd_reboot_help,   Cmd_reboot  ) ;
   MyCLI_Register(cmd_rxtest_cmd,   cmd_rxtest_cmdsc,  cmd_rxtest_help,   Cmd_rxtest  ) ;
   MyCLI_Register(cmd_settings_cmd, cmd_settings_cmdsc,cmd_settings_help, Cmd_settings) ;
   MyCLI_Register(cmd_set_cmd,      cmd_set_cmdsc,     cmd_ss_help,       Cmd_set     ) ;
   MyCLI_Register(cmd_show_cmd,     cmd_show_cmdsc,    cmd_ss_help,       Cmd_show    ) ;
   MyCLI_Register(cmd_status_cmd,   cmd_status_cmdsc,  cmd_status_help,   Cmd_status  ) ;
   MyCLI_Register(cmd_txtone_cmd,   cmd_txtone_cmdsc,  cmd_txtone_help,   Cmd_txtone  ) ;
   MyCLI_Register(cmd_update_cmd,   cmd_update_cmdsc,  cmd_update_help,   Cmd_update  ) ;
   MyCLI_Register(cmd_xuart_cmd,    cmd_xuart_cmdsc,   cmd_xuart_help,    Cmd_xuart   ) ;

   /* Initialize the VCXO if it is present */
   Find_Vcxo() ;

   /* Do our blinky light thang... */
   GPIO_RTOS_Splash() ;

   /* Task infinite loop */
   for(;;)
   {
      /* Call the code that manages the control loop for the VCOCXO.          */
      Vcxo_Loop() ;

      /* The rest are all the supervisory/reporting routines, that is pretty  */
      /* all the MainTask loop does.  The polling period is about 100ms.  It  */
      /* is a bit longer as I'm just delaying 100ms at the end so 100ms plus  */
      /* the loop execution time.  This is at user-speed, so OK.              */
      ShowHeartbeat() ;
      ShowIPStats() ;
      ShowGPSState() ;
      ShowDIALState() ;
      /* For the watchdog I have a counter in the TIM7 ISR that counts up 1   */
      /* every 20ms (50x/sec).  This MainTask loop runs every second and      */
      /* resets that counter to 0.  If that count ever exceeds 100, the timer */
      /* will initiate a reboot. Only if the watchdog is enabled of course!   */
      MainTaskWatchdogPet() ;
      osDelay(100) ;

   } /* RTOS forever loop */
} ;

/*******************************************************************************
* Routine  : ShowHeartbeat
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This just blinks the heartbeat LED.  Pretty simple.  This routine gets called
* every 100ms, it is a 100ms blink once a second.
*******************************************************************************/
void ShowHeartbeat(void)
{
   static int count = 0 ; /* state counter */

   /* Blink the heartbeat LED.  I purposely want this implemented by an    */
   /* RTOS task as I've seen too many cases of the RTOS hanging, but the   */
   /* low level timer IRQ working quite happily.                           */
   Show_State(HB_STATE,0==count) ;
   count = (count+1)%10 ;
}

/*******************************************************************************
* Routine  : ShowIPStats
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This displays the cumulative IP traffic by packet type every second (if
* enabled).  The IP routines just increment the counts, so this displays the
* count then resets the counters to zero afterwards.
* I have also added CPU loading to the 1-second logs.
*******************************************************************************/
void ShowIPStats(void)
{
   static int count = 0 ; /* state counter   */
   int        k     = 0 ; /* General counter */

   static int64_t LastIdle    = 0 ; /* Last CPU Idle task tick count    */
   int64_t        CurrentIdle = 0 ; /* Current CPU Idle task tick count */

   /* Execute this code once a second, so only every 10th call */
   count = (count+1)%10 ;
   if (0==count)
   {

      /* If enabled, show IP traffic summary stats for the past second */
      Logger2_Msg(Logger.MainApp,LOG_SUPPORT,LOG_TIME,"MainTask : Tx/Rx PPS(%d,%d,%d,%d,%d,%d,%d / %d,%d,%d,%d,%d,%d,%d) ",
         TxPackets[0],TxPackets[1],TxPackets[2],TxPackets[3],TxPackets[4],TxPackets[5],TxPackets[6],
         RxPackets[0],RxPackets[1],RxPackets[2],RxPackets[3],RxPackets[4],RxPackets[5],RxPackets[6]) ;

      /* Show CPU utilization which is 100%-idle%.  There are 1,000 ticks/sec.*/
      CurrentIdle = ulTaskGetIdleRunTimeCounter() ;
      Logger2_Msg(Logger.MainApp,LOG_SUPPORT,LOG_NOTIME," | CPU %d%%\r\n",100-((CurrentIdle-LastIdle)/10)) ;
      LastIdle = CurrentIdle ;

      /* Reset the packet counters */
      for (k=0;k<PAYLOAD_CNTRS;k++)
      {
         TxPackets[k] = 0 ;
         RxPackets[k] = 0 ;
      }
   }
}

/*******************************************************************************
* Routine  : ShowGPSState
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : GPSData, GPSLocked,
*
* This displays the GPS receiver status.  The GPS LED is off for no data,
* blinks for data but no 1PPS yet, and is steady-on for valid data and 1PPS.
*******************************************************************************/
void ShowGPSState (void)
{
   static int LEDCycle  = 0     ; /* LED cycle counter    */
   int        LEDState  = false ; /* Cumulative LED state */

   /* Getting valid GPS data is already parsed by the GPS code and the state  */
   /* set in GPSData.status ('A' for good, 'V' for bad).  That status is      */
   /* updated every GPS sentence or once/sec.                                 */

   /* Default to LED off and list conditions for the LED to be on.            */
   /* This is based on a 4-count state.                                       */

   /* If valid data and 1PPS locked, the LED is always on (states 0,1,2,3).   */
   if (('A'==GPSData.Status) && GPSLocked) LEDState = true ;

   /* If valid data but no 1PPS yet, the LED is on in states 0 and 1 only.    */
   if (('A'==GPSData.Status) && !GPSLocked) LEDState = LEDCycle<2 ;

   /* All that is legitimately left is no valid data for which the LED is off */
   /* always.  There is a weird boundary condition where data is invalid but  */
   /* 1PPS could be active, but that shouldn't happen.                        */

   /* OK, show the state and increment the LED Cycle counter.                 */
   Show_State(GPS_STATE,LEDState) ;
   LEDCycle = (LEDCycle+1)%4 ;
}

/*******************************************************************************
* Routine  : ShowDIALState
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : DIALState
*
* This displays the DIAL connection state on the DIAL LED.
*  - Off: no connection
*  - Blinking: Connected but not authorized
*  - On: Connected and authorized
*******************************************************************************/
void ShowDIALState(void)
{
#ifndef NODIALTASK

   static int LEDCycle  = 0     ; /* LED cycle counter    */
   int        LEDState  = false ; /* Cumulative LED state */

   /* The DIAL state is completely maintained in DialTask, just show that     */
   /* state on the LED                                                        */

   /* Default to LED off and set the conditions for LED on.                   */

   /* If authorized, LED is always on.                                        */
   if (DIAL_AUTHORIZED) LEDState = true ;

   /* If connected but not authorized, then blink.                            */
   if (DIAL_UNAUTH==DIAL_State) LEDState = LEDCycle<2 ;

   /* Only state left is disconnected which is always off.                    */

   /* OK, show the state and increment the LED Cycle counter.                 */
   Show_State(CONNECTED_STATE,LEDState) ;
   LEDCycle = (LEDCycle+1)%4 ;
#endif
}
