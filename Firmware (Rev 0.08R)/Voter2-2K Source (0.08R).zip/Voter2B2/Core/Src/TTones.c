/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the TTones file.  It is the UI part of the test tone generators.   */
/* For the transmit test tone (txtone), this allows the user to change  the   */
/* TTone_Context structure that tells the Tx_DSP main sequencer to add tones  */
/* (or not) directly to the audio out (and enables PTT).                      */
/* For the receive tests (rxtest), this adds either impulses for timing       */
/* checks or a reference tone on the Rx side to percolate through the entire  */
/* Voter/DIAL path.                                                           */
/* NOTE1: On purpose, Test Tone settings are not preserved across reboots.    */
/* NOTE2: Tx test tones are *after* timeout checks, so will go forever.       */
/* NOTE3: Rx test tones are before timeout checks.                            */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_txtone - Transmit Test Tone CLI command                             */
/*  - Cmd_rxtest - Receive Test signal CLI command                            */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "string.h"
#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "Tx_DSP.h"
#include "Utils.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
enum
{
   CMD_OOPS = 0,
   CMD_OFF,
   CMD_LEVEL,
   CMD_FREQ,
} TTONE_ENUMS ;

#define CMD_RXOFF   0
#define CMD_RX20MS  1
#define CMD_RX80MS  2
#define CMD_RX220MS 3
#define CMD_RXRTONE 4

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_txtone_cmd   = "txtone" ;
char* cmd_txtone_cmdsc = "txt" ;
char* cmd_txtone_help  = "txtone - [off|level #|freq #]\n"
                         "         off - Disables test tone (normal operation)\n"
                         "         level - Tone amplitude in %full scale (0-100)\n"
                         "                 Enables tone if not enabled.\n"
                         "         freq - Tone frequency in Hz (1-4000)\n"
                         "         if no params, tone settings will be shown.\n";

char* cmd_rxtest_cmd   = "rxtest" ;
char* cmd_rxtest_cmdsc = "rxt" ;
char* cmd_rxtest_help  = "rxtest - [off|0-3]\n"
                         "         off - Disables test signal (normal operation)\n"
                         "         0 - Same as off\n"
                         "         1 - Timing pulse every packet (20ms).\n"
                         "         2 - Timing pulse every 4th packet (80ms).\n"
                         "         3 - Timing pulse every 11th packet (220ms).\n"
                         "         4 - 1KHz tone emulating 3KHz deviation (??% full scale\n";

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST TxToneCmds[] =
{
   {"off"  ,NULL,CMD_OFF  },
   {"level",NULL,CMD_LEVEL},
   {"freq" ,NULL,CMD_FREQ },
   {NULL   ,NULL,0        }
} ;

static TOKENLIST RxTestCmds[] =
{
   {"off"   ,NULL,CMD_RXOFF  },
   {"tp20"  ,NULL,CMD_RX20MS },
   {"tp80"  ,NULL,CMD_RX80MS },
   {"tp220" ,NULL,CMD_RX220MS},
   {"dev3k" ,NULL,CMD_RXRTONE},
   {NULL    ,NULL,0          }
} ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void TTone_Show_State(void) ;
static void TTone_off(void) ;
static void TTone_level(int, char*) ;
static void TTone_freq(int,char*) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Cmd_txtone
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command sets up or shows the state of the test tone generator.
*******************************************************************************/
int Cmd_txtone(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag */
   int Token = 0     ; /* Command token      */

   /* If no arguments, show test tone status */
   if (1==argc)
   {
      TTone_Show_State() ;
   }
   else /* at least one argument! */
   {
      /* See which settings command */
      stolower(argv[1]) ; /* To lower case first */
      Token = parse_token(TxToneCmds,argv[1],&error) ;

      if (error)
      {
         Console_printf("Parameter must be off, level or freq.\n") ;
      }
      else
      {
         switch(Token)
         {
            case CMD_OFF  : TTone_off  ()             ;  break ;
            case CMD_LEVEL: TTone_level(argc,argv[2]) ;  break ;
            case CMD_FREQ : TTone_freq (argc,argv[2]) ;  break ;
            default : /* Shouldn't happen */             break ;
         }
      }
   }

   return (0) ;
}

/*******************************************************************************
* Routine  : TTone_Show_State
*   Inputs : None
*      IOs : None
*  Returns : 0 for success always
*  Globals : Settings
*
* This shows the state of the Test Tone generator
*******************************************************************************/
static void TTone_Show_State(void)
{

   /* If tone is disabled, say so. */
   if (TONE_BYPASS==TTone_Context.mix)
   {
      Console_printf("Test Tone disabled. (Set level to enable)\n") ;
   }
   else /* Test Tone is enabled! */
   {
      Console_printf("Test Tone enabled.\n") ;
      Console_printf("Amplitude %d%% full scale\n",TTone_Context.level) ;
      Console_printf("Frequency %dHz\n",TTone_Context.freq/100) ;
   }

   Console_printf("NOTE: Test Tone settings are not preserved on reboot.\n") ;
}

static void TTone_off(void)
{
   TTone_Context.mix = TONE_BYPASS ;
   Console_printf("Test Tone disabled.\n") ;
}

static void TTone_level(int argc, char* arg2)
{
   int newval = 0 ;
   int error = false ; /* Parsing error flag */

   if (argc!=3)
   {
      error = true ;
   }
   else
   {
      newval=parse_num(arg2,0,100,&error) ;
   }

   if (error)
   {
      Console_printf("Level should be 0-100 (percent full scale).\n") ;
   }
   else
   {
      TTone_Context.level = newval ;
      Console_printf("Level set to %d%% full scale\n",TTone_Context.level) ;
      /* Setting a level also turns on the tone generator if it was off       */
      TTone_Context.mix = TONE_REPLACE ;
   }
}

static void TTone_freq(int argc,char* arg2)
{
   int newval = 0 ;
   int error = false ; /* Parsing error flag */

   if (argc!=3)
   {
      error = true ;
   }
   else
   {
      newval=parse_num(arg2,1,4000,&error) ;
   }

   if (error)
   {
      Console_printf("Frequency should be 1-4000.\n") ;
   }
   else
   {
      /* The tone generator generates frequencies in units of 1/100th of a Hz */
      /* so multiply regular Hz times 100.                                    */
      TTone_Context.freq = newval*100 ;
      Console_printf("Frequency set to %dHz\n",TTone_Context.freq/100) ;
   }
}

/*******************************************************************************
* Routine  : Cmd_rxtest
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command controls the Rx test signal generator.
*******************************************************************************/
int Cmd_rxtest(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag */
   int Token = 0     ; /* Command token      */

   /* If no arguments, show test tone status */
   if (1==argc)
   {
      switch(RxTToneMode)
      {
         case  0: Console_printf("Rx Test mode off\n")                  ; break ;
         case  1: Console_printf("Rx Test mode pulse period 20ms\n")    ; break ;
         case  2: Console_printf("Rx Test mode pulse period 80ms\n")    ; break ;
         case  3: Console_printf("Rx Test mode pulse period 220ms\n")   ; break ;
         case  4: Console_printf("Rx Test mode 3KHz deviation equiv\n") ; break ;
         default: Console_printf("Rx Test mode RFU\n")                  ; break ;
      }
   }
   else /* at least one argument! */
   {
      /* See which settings command */
      stolower(argv[1]) ; /* To lower case first */
      Token = parse_token(RxTestCmds,argv[1],&error) ;

      if (error)
      {
         Console_printf("Parameter must be off, tp20, tp80, tp220, or dev3k.\n") ;
      }
      else
      {
         RxTToneMode = Token ;
      }
   }

   return (0) ;
}

