/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Ping file.  It implements the ping command.                    */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_xuart - Test Tone CLI command                                       */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"
#include "lwip/opt.h"
#include "lwip/api.h"
#include "lwip/sys.h"
#include "lwip/ip.h"
#include "lwip/prot/icmp.h"
#include "lwip/inet_chksum.h"

#include "string.h"
#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "Utils.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
#define PING_TARGET_IP   "192.168.221.1"
#define PING_DATA_SIZE   32
#define PING_TIMEOUT_MS  2000

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_ping_cmd   = "ping" ;
char* cmd_ping_cmdsc = "ping" ;
char* cmd_ping_help  = "ping [ipaddr|device] - Ping the IP address or device.\n"
                        "   Devices can be asl, tftp,or gateway.\n" ;


/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void lwip_ping_example(void) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Cmd_Ping
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command just runs the UART test,
*******************************************************************************/
int Cmd_Ping(int argc, char* argv[])
{
   Console_printf ("Ping still being developed! May need to wait for the raw API.\n") ;
   lwip_ping_example() ;
   return (0) ;
}

static void lwip_ping_example(void)
{
   struct netconn *conn;
   struct netbuf *sb ;
   struct netbuf *rb ;
   ip_addr_t target_addr;
   err_t err;

   u16_t unique_id = 0xAFAF;
   u16_t seq_num = 0;

   // Parse the target IP address string
   ipaddr_aton(PING_TARGET_IP, &target_addr);

   // 1. Create a raw network connection for ICMP
   conn = netconn_new(NETCONN_RAW);
   if (conn == NULL) {
         Console_printf("Ping: Failed to create connection.\n");
       vTaskDelete(NULL);
   }

   // 2. Bind locally and set a receive timeout
   netconn_bind(conn, IP_ADDR_ANY, IP_PROTO_ICMP);
   netconn_set_recvtimeout(conn, PING_TIMEOUT_MS);

   Console_printf("Pinging %s...\n", PING_TARGET_IP);

   while (seq_num<4) {
       size_t packet_size = sizeof(struct icmp_echo_hdr) + PING_DATA_SIZE;

       // 3. Allocate a send network buffer
       sb = netbuf_new();
       uint8_t *payload = (uint8_t *)netbuf_alloc(sb, packet_size);

       if (payload != NULL) {
           struct icmp_echo_hdr *iecho = (struct icmp_echo_hdr *)payload;

           // 4. Construct the ICMP Echo Header
           ICMPH_TYPE_SET(iecho, ICMP_ECHO);
           ICMPH_CODE_SET(iecho, 0);
           iecho->chksum = 0;
           iecho->id     = lwip_htons(unique_id);
           iecho->seqno  = lwip_htons(++seq_num);

           // Fill packet payload with dummy characters
           char *dptr = (char *)(payload + sizeof(struct icmp_echo_hdr));
           for (int i = 0; i < PING_DATA_SIZE; i++) {
               dptr[i] = 'A' + (i % 26);
           }

           // 5. Compute the standard internet checksum
           iecho->chksum = inet_chksum(iecho, packet_size);

           // 6. Transmit the ping packet to the destination address
           err = netconn_sendto(conn, sb, &target_addr, 0);
           netbuf_delete(sb); // Instantly clean up the metadata structure

           if (err == ERR_OK) {
               u32_t start_time = sys_now();

               // 7. Await the response packet
               err = netconn_recv(conn, &rb);
               if (err == ERR_OK) {
                   u32_t rtt = sys_now() - start_time;
                   void *data;
                   u16_t len;

                   // Extract payload pointer and length from network buffer
                   netbuf_data(rb, &data, &len);

                   /* Note: RAW sockets parse packets starting at the IP payload.
                    * Check if packet length matches the ICMP layer minimum size */
                   if (len >= sizeof(struct icmp_echo_hdr)) {
                       struct icmp_echo_hdr *recho = (struct icmp_echo_hdr *)data;

                       // 8. Validate Type (Echo Reply), ID, and Sequence number
                       if (ICMPH_TYPE(recho) == ICMP_ER &&
                           recho->id == lwip_htons(unique_id) &&
                           recho->seqno == lwip_htons(seq_num)) {
                             Console_printf("Reply from %s: bytes=%d time=%ldms seq=%d\n",
                                  PING_TARGET_IP, len, rtt, seq_num);
                       }
                   }
                   netbuf_delete(rb); // Free allocated incoming buffer memory
               } else if (err == ERR_TIMEOUT) {
                     Console_printf("Request timed out for seq %d.\n", seq_num);
               } else {
                     Console_printf("Receive error encountered: %d\n", err);
               }
           } else {
                 Console_printf("Failed to transmit ICMP packet: %d\n", err);
           }
       } else {
           netbuf_delete(sb);
           Console_printf("Memory allocation failed for network buffer.\n");
       }

       // Delay 1 second between consecutive pings
       sys_msleep(1000);
   }

   // Clean up connections if breaking out of the loop
   netconn_close(conn);
   netconn_delete(conn);
}

#ifdef LWIP_BROADCAST_PING

#endif
