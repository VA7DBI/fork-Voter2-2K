/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the DialTaskOut file. It is in charge of data going out to the     */
/* DIAL server.  This is mostly audio packets from the repeater but also      */
/* various command/control stuff.  Note that the actual setup of the Ethernet */
/* hardware is doen by DialTaskIn.c.                                          */
/* It is only enabled if Voter mode is enabled.                               */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - Dial_Enqueue - DialTask message enqueuer (for incoming audio packets)   */
/*  - DialEthRxTask - Task just for getting DIAL packets                      */
/*  - DialTask - The top level task for DIAL traffic handling                 */
/*                                                                            */
/******************************************************************************/
// To Do:
// Should there be a user-programmable timeout for Status packets to go back to disconnected?
// Clean up GPS/GP handling in Do_DIAL_Supervisory_Stuff()
// I think audio buffers could be cleaned up and optimized more
// See if this file can be split up, it is getting big (>1000 lines)
// Timestamping for ADPCM needs fixing.
// ~697: Do I discard packets in dial reset mode?

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>
#include <stdio.h>

#include "lwip.h"
#include "lwip/api.h"

#include "main.h"
#include "Options.h"
#include "Settings.h"
#include "DialTaskCom.h"
#include "logger2rt.h"
#include "Debugging.h"
#include "EthernetTask.h"
#include "DialTaskOut.h"
#include "Gpio.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "Tx_DSP.h"
#include "Codecs.h"
#include "GPS.h"
#include "DialSettings.h"

/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/
#define DIALWATCHDOGTRIG 250 /* DIAL connection watchdog count (@50 tics/sec) */
#define NOTMASTER_DELAY  6   /* Delay in ms for data if not timing master     */
#define MINUS20MS -20000000  /* -20ms in ns                                   */

#define RXQ_SIZE 4 /* One is enough, making it four */

/******************************************************************************/
/* Structures                                                                 */
/******************************************************************************/
typedef struct
{
   int16_t* Rx_Buffer ;
   uint32_t TimeStamp ;
   uint8_t  Rx_Active ;
   uint8_t  Rssi      ;
   uint8_t  RFU1      ; /* Just to fill out to a 32-bit word */
   uint8_t  RFU2      ; /* Just to fill out to a 32-bit word */
} RX_MSGDATA ;

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
uint32_t TxPackets[PAYLOAD_CNTRS] = {0}   ; /* Tx packet count by type */

uint32_t DIAL_ip         = 0     ; /* DIAL server resolved IP */
ip_addr_t DIAL_Server_IP = {0}   ; /* DIAL Sever IP address   */

int PreComp_Vpp          = 0     ; /* Pre-compression p-p value */

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
#ifndef NODIALTASK

/* This is the data passed from the Rx_DSP interrupt service to the DialTask  */
/* task for every packet.  The message handler (with CMSIS 1.x) can only pass */
/* up to a 32-bit value, so that message will simply be an index to the array */
/* below for the data itself.  This data is handled in real time and before   */
/* the data was passed simply as globals, so no queue depth at all.  Still, a */
/* small queue seems safer.                                                   */
static RX_MSGDATA Rx_MsgData[RXQ_SIZE] = {0} ;


static PAYLOAD_T0_STRUCT Struct_AuthPacket    = {0} ; /* Auth packet (rtn data)*/
static PAYLOAD_T1_STRUCT Struct_MuLawRxPacket = {0} ; /* MuLaw Rx Data packet  */
static PAYLOAD_T2_STRUCT Struct_GPSTxPacket   = {0} ; /* GPS packet (rtn data) */
static PAYLOAD_T3_STRUCT Struct_ADPCMRxPacket = {0} ; /* ADPCM Rx Data packet  */
static PAYLOAD_T5_STRUCT Struct_PingPacket    = {0} ; /* Ping packet (rtn data)*/

/* Above packets just cast to byte arrays for easier sending/receiving */
#define AuthPacket    ((uint8_t*)&Struct_AuthPacket)
#define MuLawRxPacket ((uint8_t*)&Struct_MuLawRxPacket)
#define GPSTxPacket   ((uint8_t*)&Struct_GPSTxPacket)
#define ADPCMRxPacket ((uint8_t*)&Struct_ADPCMRxPacket)
#define PingPacket    ((uint8_t*)&Struct_PingPacket)

/* For bring-up, this is data for a fake GPS location string */
static char* FakeLongitude = "3936476N"  ; /*  9 bytes */
static char* FakeLatitude  = "10451881W" ; /* 10 bytes */
static char* FakeAltitude  = "1757.4\0"  ; /*  8 bytes */

int DIAL_Restart = false ; /* DIAL Restart flag       */

#endif /* #ifndef NODIALTASK */

/* CRC polynomial for the Voter challenge/response if using SW CRC.           */
/* The table is based on the polynomial 0x04c11db7 (0xedb88320 reversed) and  */
/* is just copied from voter1 source.                                         */
/* Only needed if not using the STM32's hardware CRC.                         */
#ifndef USE_HW_CRC
static const long crc_32_tab[] = {
0x00000000, 0x77073096, 0xee0e612c, 0x990951ba, 0x076dc419, 0x706af48f,
0xe963a535, 0x9e6495a3, 0x0edb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988,
0x09b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91, 0x1db71064, 0x6ab020f2,
0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9,
0xfa0f3d63, 0x8d080df5, 0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172,
0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b, 0x35b5a8fa, 0x42b2986c,
0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423,
0xcfba9599, 0xb8bda50f, 0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924,
0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d, 0x76dc4190, 0x01db7106,
0x98d220bc, 0xefd5102a, 0x71b18589, 0x06b6b51f, 0x9fbfe4a5, 0xe8b8d433,
0x7807c9a2, 0x0f00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb, 0x086d3d2d,
0x91646c97, 0xe6635c01, 0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e,
0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457, 0x65b0d9c6, 0x12b7e950,
0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7,
0xa4d1c46d, 0xd3d6f4fb, 0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0,
0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9, 0x5005713c, 0x270241aa,
0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81,
0xb7bd5c3b, 0xc0ba6cad, 0xedb88320, 0x9abfb3b6, 0x03b6e20c, 0x74b1d29a,
0xead54739, 0x9dd277af, 0x04db2615, 0x73dc1683, 0xe3630b12, 0x94643b84,
0x0d6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d, 0x0a00ae27, 0x7d079eb1,
0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb,
0x196c3671, 0x6e6b06e7, 0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc,
0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5, 0xd6d6a3e8, 0xa1d1937e,
0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55,
0x316e8eef, 0x4669be79, 0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236,
0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f, 0xc5ba3bbe, 0xb2bd0b28,
0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
0x9b64c2b0, 0xec63f226, 0x756aa39c, 0x026d930a, 0x9c0906a9, 0xeb0e363f,
0x72076785, 0x05005713, 0x95bf4a82, 0xe2b87a14, 0x7bb12bae, 0x0cb61b38,
0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7, 0x0bdbdf21, 0x86d3d2d4, 0xf1d4e242,
0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69,
0x616bffd3, 0x166ccf45, 0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2,
0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db, 0xaed16a4a, 0xd9d65adc,
0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693,
0x54de5729, 0x23d967bf, 0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94,
0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d
};
#endif

/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/
extern osMessageQId DialQueueHandle;
extern CRC_HandleTypeDef hcrc;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
#ifndef NODIALTASK
static void    HandleRxAudio(int16_t*,uint32_t,uint8_t,uint8_t) ;
static void    Update_Counters(void) ;
static void    Do_DIAL_Supervisory_Stuff(void) ;

static void    Tx_handleCR  (uint8_t*,uint8_t*) ;
static void    Tx_AuthPacket(void) ;
static void    Tx_MulawPacket(uint8_t*,uint32_t,uint8_t) ;
static void    Tx_ADPCMPacket(uint8_t*,uint8_t) ;
static void    Tx_GPSPacket(void) ;
static void    FillTimeStamp(uint32_t*, uint32_t*) ;
static void    Package_MuLaw_Packet(uint32_t,uint32_t,uint8_t,uint8_t*) ;

static void    SendDialPacket(uint8_t*,uint32_t) ;
#endif /* #ifndef NODIALTASK */

/******************************************************************************/
/* Finally, routines!                                                         */
/******************************************************************************/

#ifndef NODIALTASK
/*******************************************************************************
* Routine  : Dial_Enqueue
* Gazintas : Rx_Buffer_in - Pointer to a packet of audio samples
*          : Timestamp_in - Timer2 timestamp for that buffer
*          : Rx_Active_in - Rx Active flag for this packet
*          : Rssi_in      - RSSI value for this packet (whatever the source)
* IOs      : None
* Returns  : Nothing
* Globals  : EnableDialOut - Semaphore to enable incoming packets
*
* This is the routine to queue up data for the DialEthTx Task.
* CMSIS V1 can only support a 32-bit int for a message, so I plunk the above
* information into a structue, have a small array of those structures and just
* pass the structure array index value in the message itself.
*
* Most importantly, this is is where a packet of samples transitions from the
* "below the RTOS" hard real-time domain into the RTOS task domain.
*******************************************************************************/
void Dial_Enqueue(int16_t* Rx_Buffer_in, uint32_t TimeStamp_in, uint8_t Rx_Active_in, uint8_t Rssi_in)
{
   static int Buffer_Num = 0 ; /* Buffer array index */

   /* Only if enabled, send the message into the Dial Task!                   */
   /* If not enabled, data just gets lost.  That is fine.                     */
   /* Mostly needed as the ISRs fire up before the RTOS and try to send data  */
   /* before the RTOS has started and that *is* bad.                          */
   if (EnableDialOut)
   {
      /* Just stuff the parameters into the next buffer queue entries.        */
      Rx_MsgData[Buffer_Num].Rx_Buffer = Rx_Buffer_in ;
      Rx_MsgData[Buffer_Num].TimeStamp = TimeStamp_in ;
      Rx_MsgData[Buffer_Num].Rx_Active = Rx_Active_in ;
      Rx_MsgData[Buffer_Num].Rssi      = Rssi_in      ;
      Rx_MsgData[Buffer_Num].RFU1      = 0            ;
      Rx_MsgData[Buffer_Num].RFU2      = 0            ;

      /* and then queue up the pointer to that stuffed buffer */
     osMessagePut(DialQueueHandle,Buffer_Num,0) ;

     /* and finally increment the buffer number. */
     Buffer_Num = (Buffer_Num+1)%RXQ_SIZE ;
  }
}

#endif /* #ifndef NODIALTASK */

/*******************************************************************************
* Routine  : DialEthTxTask
* Gazintas : None (argument isn't used)
* IOs      : None
* Returns  : Doesn't, this is a top level RTOS task
* Globals  : EnableDialOut - flag to enable incoming packets from ISR
*
* This is the RTOS task for sending data to DIAL.
* A separate task manages data from DIAL.
* Data comes in from RxDSP via a queue using Dial_Enqueue().
* This task also handles all of the DIAL server comms for authentication,
* keep-alive, etc.  Ideally this task does everything between (uncompressed)
* audio samples from/to the TxDSP/RxDSP routines and Ethernet packets to/from
* Ethernet.  That is, compression/decompression is handled here.
*******************************************************************************/
 void DialOutTask(void const * argument)
{
   /* First wait on DialTask getting its Ethernet stuff set up.  It signals */
   /* is ready by setting EnableDialOut to true.                            */
   /* Yea, I could do the whole sempahore/signal thing, but this is simpler.*/
   while (!EnableDialOut) osDelay(10) ;
   Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialOutTask: Start\r\n") ;

#ifdef NODIALTASK
   Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialOutTask: Terminated\r\n") ;
   osDelay(10) ; /* Wait a bit for the message to go out */
   osThreadTerminate(DialTaskIDHandle) ;
#else
   osEvent   event     = {0} ; /* event info (for incoming message) */

   for(;;) /* RTOS Task Infinite loop */
   {
      /* Wait for a packet to arrive... (blocking wait)                       */
      /* Note that Rx_DSP sends a packet every 20ms no matter what.           */
      event = osMessageGet(DialQueueHandle,osWaitForever ) ;

      if ( event.status == osEventMessage) /* Only message type I'm expecting */
      {
         HandleRxAudio(Rx_MsgData[event.value.v].Rx_Buffer,
                       Rx_MsgData[event.value.v].TimeStamp,
                       Rx_MsgData[event.value.v].Rx_Active,
                       Rx_MsgData[event.value.v].Rssi) ;

      }
   }
#endif /* #ifdef NODIALTASK */
}

#ifndef NODIALTASK

/*******************************************************************************
* Routine  : HandleRxAudio
* Gazintas : BufferID - Buffer location pointer
*          : BufferLen - Buffer data length (not currently used)
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This routine processes Rx Audio from the DSP routines.  First it takes care
* of some general maintenance stuff (counters and supervisory things) for
* care and feeding of the DIAL server, then actual sending of data to the DIAL
* server.
*******************************************************************************/
static void HandleRxAudio(int16_t* buffer,uint32_t Timestamp,uint8_t Rx_Active, uint8_t Rssi)
{
   int HaveData = false ; /* Data available (for ADPCM) */

   static uint8_t Rx_Compressed[DIAL_AUD_MAXPACKETSIZE] ; /* Compressed audio buffer to DialTask */

   /* RxAudio generates a reliable hardware-based 20ms interrupt that happens */
   /* even if there is no carrier detect from the repeater, so can rely on it */
   /* for anything time-based.  Update our time and packet counters for       */
   /* General Purpose mode.  This is a handy place to also implement the      */
   /* forced comms restart timer.                                             */
   Update_Counters() ;

   /* Next, handle all the supervisory DIAL authentication stuff and  */
   /* keep-alive packet processing.                                   */
   Do_DIAL_Supervisory_Stuff() ;

   if (NULL != buffer)
   {
      /* Send the packet of audio to the DIAL server if we are authorized and */
      /* and there is a valid signal or DIAL server says to send always.      */
      if (DIAL_ACTIVE && (Rx_Active||DIAL_ALWAYSAUDIO))
      {
         /* Now for audio compression, either uLaw or ADPCM */
         if (!DIAL_USEADPCM)
         {
            /* For uLaw it is pretty simple, sample-for-sample 16-bit to 8-bit*/
            /* compression.  Compress it, then create a type 1 packet to send */
            /* it to the DIAL server.                                         */
            CompressuLaw(buffer,Rx_Compressed) ;
            Tx_MulawPacket(Rx_Compressed,Timestamp,Rssi) ;
         }
         else /* ADPCM */
         {
            /* We only get data back from the ADPCM compressor every other    */
            /* packet, HaveData says we have data (!).                        */
            HaveData = CompressADPCM(buffer,Rx_Compressed) ;
            if (HaveData)
            {
               Tx_ADPCMPacket(Rx_Compressed,Rssi) ;
            }
         }
      }
   }
}

/*******************************************************************************
* Routine  : Update_Counters
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : GP_SeqNum, FKGPS_Tns, FKGPS_Time
*          :  DIAL_Restart, DIAL_Offline
*
* This updates the two packet counters used for DIAL comms.  For General
* Purpose packets it is just a count that increments every 20ms.  For initial
* debugging I came up with a fake GPS mode where I'm temporarily cheating by
* getting the time from the DIAL server and then incrementing it by 20 million
* each 20ms.  It isn't needed anymore, but I think there may be a way to use
* the idea for a more accurate fake GPS that could be useful, so keeping the
* support for now.
*
* Also, here is where I deal with the forced offline mode.  If the semaphore
* to issue a restart gets set, this sets the local global DIAL_Offline for 2x
* the DIAL watchdog period to force a DIAL comms restart.
*******************************************************************************/
static void Update_Counters(void)
{
   static int Offline_Counter = 0 ; /* Timer counter for forced offline mode  */

   /* For Non-GPS audio, we simply send a sequence number in the time_ns part */
   /* of the header.  This must continuously increment even if not sending    */
   /* data.  This routine gets called every 20ms from the ISR even if there   */
   /* isn't a valid signal level, so fulfills that purpose.  Later, based on  */
   /* if there is a valid signal the packet will actually be sent to the DIAL */
   /* server or not.                                                          */
   /* Of note, if sending ADPCM packets, the counter value sent will          */
   /* actually increment by two each packet since they are sent every 40ms    */
	/* instead of every 20ms. This is what the spec says to do.               */
   GP_SeqNum++ ;

   /* For the rough time for non-GPS packets I capture the time from the      */
   /* authorization packet and then increment it every second.  For bring-up  */
   /* I have a fake GPS mode where I create a full timestamp to emulate a GPS */
   /* timed packet.  I do this by capturing the full time from the server     */
   /* (including ns), then increment the ns time by 20,000,000 each 20ms and  */
   /* update the seconds time on overflow.                                    */
   FKGPS_Tns +=20000000 ; /* 20ms in ns */

   if (FKGPS_Tns >=1000000000) /* billion ns to a s */
   {
      FKGPS_Tns -= 1000000000 ;
      FKGPS_Time++   ;
   }

   /* The CLI command set dial restart sets DIAL_Restart to true.  This code  */
   /* picks it up on the next packet tick and sets DIAL_Offline that tells    */
   /* the incoming packet handler to drop all packets and outgoing packet     */
   /* handler to not send out any packets.  time to do this is 2x the number  */
   /* of ticks to recognize a comms failure.                                  */
   if (DIAL_Restart)
   {
      DIAL_Restart = false ;
      DIAL_Offline = true ;
      Offline_Counter = DIALWATCHDOGTRIG*2 ;
   }

   if (Offline_Counter>0)
   {
      Offline_Counter-- ;
      if (0==Offline_Counter)
      {
         DIAL_Offline = false ;
      }
   }
}

/*******************************************************************************
* Routine  : Do_DIAL_Supervisory_Stuff
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  :
*
* This gets called every 20ms and handles all the DIAL supervisory comms.  In
* particular the sending of authentication packets when not connected and
* sending of GPS/Keep-alive packets when connected.
*******************************************************************************/
static void Do_DIAL_Supervisory_Stuff(void)
{
   static int counter = 0 ; /* State counter */

   /* Increment our state counter for whatever is next... */
   counter++ ;

   /* Special case of a sync check, send a spontaneous auth packet */
   if (CheckSyncCheck()) Tx_AuthPacket() ;

   /* We start off in un-authorized mode, so send authorization packets until*/
   /* a connection is established.  Sending of audio data is disabled        */
   /* elsewhere while unauthorized.                                          */
   if (DIAL_NOTAUTHORIZED)
   {
      /* Send an authorization packet at the authorization rate.  If/when we */
      /* get a packet back from the server, the code receiving the packet    */
      /* will update DIAL_State.                                             */
      if (counter>(DIALSettings.Unauth_Rate/20))
      {
         counter = 0 ;
         Tx_AuthPacket() ;
      }
   }
   else /* if authorized */
   {
      /* If authorized, just send GPS packets at the authorization rate as a  */
      /* keep-alive message. In non-GPS mode this is just a dummy packet.     */
       if (counter>(DIALSettings.Unauth_Rate/20))
      {
         counter = 0 ;
         Tx_GPSPacket() ;
      }

      /* Also, make sure we're still talking to the DIAL server.  Increment   */
      /* the watchdog counter below each call (20ms) and if we ever get to    */
      /* the trigger value, assume we've lost contact.  Even if no audio is   */
      /* being exchanged, keepalive packets should be coming in every second. */
      DialWatchdog++ ;

      if (DialWatchdog>DIALWATCHDOGTRIG)
      {
         /* Uh-oh, lost comms! */
         DIAL_State = DIAL_DISC ;
         //Show_State(CONNECTED_STATE,false) ;
         Logger2_Msg(Logger.Dial,LOG_MAJOR,LOG_TIME,"DialTask: Lost DIAL Server comms!\r\n") ;
         DialWatchdog=0 ; /* Reset count so no weirdness on restoration */
      }
   }
 }

/*******************************************************************************
* Routine  : Tx_handleCR
* Gazintas : Voter_Challenge - Outgoing challenge from voter to DIAL server
*          : Voter_CR_Response - Voters response to the servers challenge string.
* IOs      : None
* Returns  :
* Globals  :None
*
* This routine parses the challenge response info of any outgoing packet to
* the DIAL server.  The challenge string from the voter just gets plunked into
* the challenge string of the outgoing packet.  If not authorized, the challenge
* response is 0, otherwise the challenge response gets computed from the DIAL
* server challenge string and the voters password and sent back to the server.
*******************************************************************************/
static void Tx_handleCR(uint8_t* Voter_Challenge,uint8_t* Voter_CR_Response)
{
   uint32_t response = 0 ; /* Challenge response to DIAL */

   /* Just copy the Voters challenge string into the outgoing packet. */
   memcpy(Voter_Challenge,DIALSettings.Voter_Challenge,10) ;

   /* Whether authorized or not, just compute a challenge response and send   */
   /* it back.  If not authorized it will be junk, if authorized it will be   */
   /* good.  OK either way.                                                   */

   /* Compute the challenge response from the DIAL challenge string and the   */
   /* Voter password and plunk it in the response field.                      */
   response = htonl(crc32_bufs((unsigned char*)DIAL_Challenge,(unsigned char*)DIALSettings.Voter_Password)) ;

   memcpy(Voter_CR_Response,&response,4) ;
}

/*******************************************************************************
* Routine  : Tx_AuthPacket
* Gazintas : None (yet)
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This routine sends out a Type 0 authorization packet. As the actual
* authentication is handled by Tx_handleCR() shared with all payload types,
* this routine doesn't do much, just fills in the header and flag byte.
* For GP mode we set the GP bit, for GPS and fake GPS modes we clear the GP bit.
*
* NOTE: Well above is that the protocol spec implies.  In reality, it seems that
* if you want GPS-timed mode you send this packet without data and only send
* the data if the Flag Byte is non-zero (for GP mode)???
*******************************************************************************/
static void Tx_AuthPacket(void)
{
   /* Fill in all the other header stuff. */
   FillTimeStamp(&Struct_AuthPacket.header.time_s,&Struct_AuthPacket.header.time_ns) ;
   Struct_AuthPacket.header.Payload_Type = htons(PAYLOAD_T0AUTH) ;
   Struct_AuthPacket.FlagByte            = DIALFLAG_GENPURPOSE ; /* If sent, it's this */
   /* Challenge/response is handled later as it is common to all packets */

   Logger2_Msg(Logger.Dial,LOG_SUPPORT,LOG_TIME,"DialTask: Sending Auth len %d\r\n",
               (PKTTIM_GP==DIALSettings.PacketTiming)?VOTER_PACKLEN_T0GP:VOTER_PACKLEN_T0GPS) ;

   /* Packet ready: if GPS mode, only send the header.  If General Purpose    */
   /* mode, include the payload byte saying it's general purpose.             */
   SendDialPacket(AuthPacket,(PKTTIM_GP==DIALSettings.PacketTiming)?VOTER_PACKLEN_T0GP:VOTER_PACKLEN_T0GPS) ;
   TxPackets[PAYLOAD_T0AUTH]++ ;
}

/*******************************************************************************
* Routine  : Tx_MulawPacket
* Gazintas : buffer - 160 compressed audio samples
*          : Timestamp - TIM2 timestamp for this packet.
*          : rssi - signal strength
* IOs      : None
* Returns  : Nothing
* Globals  : Struct_MuLawRxPacket - Datagram ready to send via Ethernet
*
* This takes the sample data and creates the datagram to send via Ethernet
* to the DIAL server.  For GPS and fake GPS, the full time (s+ns) is
* in the header, for General Purpose mode, it is the rough time in the seconds
* field (same as fake GPS) and the General Purpose sequence number in the ns
* field.
*******************************************************************************/
static void Tx_MulawPacket(uint8_t* buffer,uint32_t Timestamp,uint8_t rssi)
{
   uint32_t GPS_Sec = 0 ; /* Previous GPS-based time (secs) */
   uint32_t GPS_ns  = 0 ; /* Previous GPS-based time (ns)   */

   /* Start off clean, then fill in values */
   memset ((uint8_t*)&Struct_MuLawRxPacket,0,VOTER_PACKLEN_T1)   ;

   switch(DIALSettings.PacketTiming)
   {
      case PKTTIM_GP  :   Package_MuLaw_Packet(FKGPS_Time,GP_SeqNum,rssi,buffer) ;
                          break ;
      case PKTTIM_GPS :   /* The time now is at the end of the current audio  */
                          /* packet.  I actually want the time for the        */
                          /* beginning of the packet, so subtrat 20ms         */
                          Get_GPSTime(Timestamp,&GPS_Sec,&GPS_ns) ;
                          Adjust_GPSTime(&GPS_Sec,&GPS_ns,MINUS20MS) ;
                          Package_MuLaw_Packet(GPS_Sec,GPS_ns,rssi,buffer) ;
                          break ;
      case PKTTIM_FKGPS : Package_MuLaw_Packet(FKGPS_Time,FKGPS_Tns,rssi,buffer) ;
                          break ;
      default           : break ;
   }
}

/*******************************************************************************
* Routine  : Package_MuLaw_Packet
* Gazintas : Pkt_Sec - Packet time seconds
*          : Pkt_ns - Packet time nanoseconds
*          : rssi - RSSI value
*          : buffer - 160 samples
* IOs      : None
* Returns  : Nothing
* Globals  : TxPackets, more?
*
* Since different routines can create a T1 (uLaw) packet depending on the timing
* mode, this is just all the common code to package up a packet to save code
* duplication.
*******************************************************************************/
static void Package_MuLaw_Packet(uint32_t Pkt_Sec, uint32_t Pkt_ns, uint8_t rssi, uint8_t* buffer)
{
   static uint32_t Prev_Pkt_Sec = 0 ; /* Previous Packet time (secs) */
   static uint32_t Prev_Pkt_ns  = 0 ; /* Previous Packet time (ns)   */
   int32_t         delta        = 0 ; /* Delta from last packet (ns) */

   Struct_MuLawRxPacket.header.time_s       = htonl(Pkt_Sec)         ;
   Struct_MuLawRxPacket.header.time_ns      = htonl(Pkt_ns)          ;
   Struct_MuLawRxPacket.header.Payload_Type = htons(PAYLOAD_T1MULAW) ;
   Struct_MuLawRxPacket.Rssi                = rssi                   ;
   memcpy(&Struct_MuLawRxPacket.Audio,buffer,APKT_SAMPLES) ;
   /* Challenge/response is handled later as it is common to all packets */

   /* This reporting generates so much data I enable/disable it by DbFlags    */
   /* only.                                                                   */
   if (2==DbFlags[DBFLAG_TSDELTAS])
   {
      /* Figger out the delta time from the last packet in ns */
      delta = (Pkt_Sec-Prev_Pkt_Sec)*1000000000+Pkt_ns-Prev_Pkt_ns ;
      Logger2_Msg(Logger.Dial,LOG_REGIO,LOG_TIME,"DialTask: uLaw Rx TS: %u.%09u delta %6d\r\n",Pkt_Sec,Pkt_ns,delta) ;
      Prev_Pkt_Sec = Pkt_Sec ;
      Prev_Pkt_ns  = Pkt_ns  ;
   }

   /* If the DIAL server says we're not the master, wait 6ms.    */
   /* **** This seems too simple,  makes me a bit nervous!!!**** */
   if (!DIAL_IMMASTER) osDelay(NOTMASTER_DELAY) ;

   SendDialPacket(MuLawRxPacket,VOTER_PACKLEN_T1) ;
   TxPackets[PAYLOAD_T1MULAW]++ ;
}

/*******************************************************************************
* Routine  : Tx_GPSPacket
* Gazintas : None (yet)
* IOs      : None
* Returns  : Nothing
* Globals  : DIALSettings.PacketTiming,FKGPS_Time,FKGPS_Tns
*
* This routine sends out a Type 2 GPS Information packet.  For General Purpose
* packets, this has nothing other than the header.  For fake GPS I have a
* static value, for real GPS I plunk in the data from the GPS.
*******************************************************************************/
static void Tx_GPSPacket(void)
{
   int  packet_size =  0  ; /* Packet sisze to send */
   char tmpstr[16]  = {0} ; /* Temporary string */

   /* Header first, ns field is 0 for GP, ns value for GPS modes */
   FillTimeStamp(&Struct_AuthPacket.header.time_s,&Struct_AuthPacket.header.time_ns) ;
   Struct_GPSTxPacket.header.Payload_Type = htons(PAYLOAD_T2GPSINFO) ;

   if (PKTTIM_GP==DIALSettings.PacketTiming)
   {
      /* If GP mode, the packet is ready since it is only the header! */
      packet_size = VOTER_PACKLEN_T2GP ;
   }
   else if (PKTTIM_GPS==DIALSettings.PacketTiming)
   {
      if  (!GPSLocked)
      {
         /* If GPS isn't locked, just send a GP packet. */
         packet_size = VOTER_PACKLEN_T2GP ;
      }
      else
      {
         /* In GPS mode, copy the GPS data */
         sprintf((char*)Struct_GPSTxPacket.Longitude,"%7.7s%c",GPSData.Longitude,GPSData.LongDir) ;
         sprintf((char*)Struct_GPSTxPacket.Latitude,"%8.8s%c",GPSData.Latitude,GPSData.LatDir) ;
         /* sprintf could overflow on an int, so using a temporary string intermediary */
         sprintf(tmpstr,"%4.4d.0",GPSData.Altitude) ;
         memcpy(Struct_GPSTxPacket.Altitude,tmpstr,7) ;
         packet_size = VOTER_PACKLEN_T2GPS ;
      }
   }
   else
   {
      /* In fake GPS mode, copy our hard coded location string for now */
      memcpy(Struct_GPSTxPacket.Longitude,FakeLongitude,9 ) ;
      memcpy(Struct_GPSTxPacket.Latitude ,FakeLatitude ,10) ;
      memcpy(Struct_GPSTxPacket.Altitude ,FakeAltitude ,7 ) ;
      packet_size = VOTER_PACKLEN_T2GPS ;
   }

   /* If the DIAL server says we're not the master, wait 6ms */
   /* **** This makes me a bit nervous!!!               **** */
   if (!DIAL_IMMASTER) osDelay(NOTMASTER_DELAY) ;

   SendDialPacket(GPSTxPacket,packet_size) ;
   TxPackets[PAYLOAD_T2GPSINFO]++ ;

}

/*******************************************************************************
* Routine  : Tx_ADPCMPacket
* Gazintas : buffer - 163 compressed audio samples
*          : rssi - signal strength
* IOs      : None
* Returns  : Nothing
* Globals  : Struct_MuLawRxPacket - Datagram ready to send via Ethernet
*
* This takes the sample data and creates the datagram to send via Ethernet
* to the DIAL server.  For GPS and fake GPS, the full time (s+ns) is
* in the header, for General Purpose mode, it is the rough time in the seconds
* field (same as fake GPS) and the General Purpose sequence number in the ns
* field.
*******************************************************************************/
static void Tx_ADPCMPacket(uint8_t* buffer,uint8_t rssi)
{
   uint32_t GPS_Sec = 0 ; /* GPS-based time (secs) */
   uint32_t GPS_ns  = 0 ; /* GPS-based time (ns)   */

   /* Start off clean, then fill in values */
   memset ((uint8_t*)&Struct_ADPCMRxPacket,0,VOTER_PACKLEN_T3)   ;

   switch(DIALSettings.PacketTiming)
   {
      case PKTTIM_GP  :   Struct_ADPCMRxPacket.header.time_s  = htonl(FKGPS_Time) ;
                          Struct_ADPCMRxPacket.header.time_ns = htonl(GP_SeqNum ) ;
                          break ;
      case PKTTIM_GPS :   Get_GPSTimeNow(&GPS_Sec,&GPS_ns) ;
                          Struct_ADPCMRxPacket.header.time_s  = htonl(GPS_Sec) ;
                          Struct_ADPCMRxPacket.header.time_ns = htonl(GPS_ns) ;
                          break ;
      case PKTTIM_FKGPS : Struct_ADPCMRxPacket.header.time_s  = htonl(FKGPS_Time) ;
                          Struct_ADPCMRxPacket.header.time_ns = htonl(FKGPS_Tns ) ;
                          break ;
      default           : break ;
   }

   Struct_ADPCMRxPacket.header.Payload_Type = htons(PAYLOAD_T3ADPCM)    ;
   Struct_ADPCMRxPacket.Rssi                = rssi ;
   memcpy(&Struct_ADPCMRxPacket.Audio,buffer,163) ;
   /* Challenge/response is handled later as it is common to all packets */

   /* If the DIAL server says we're not the master, wait 6ms */
   /* **** This makes me a bit nervous!!!               **** */
   if (!DIAL_IMMASTER) osDelay(NOTMASTER_DELAY) ;

   SendDialPacket(ADPCMRxPacket,VOTER_PACKLEN_T3) ;
   TxPackets[PAYLOAD_T3ADPCM]++ ;
}

/*******************************************************************************
* Routine  : Tx_Ping_Packet
* Gazintas : payload - Ping payload to send
*          : len - payload length
* IOs      : None
* Returns  : Nothing
* Globals  : PingPacket
*
* This routine send the return data from a ping to the Voter2 back to the DIAL
* server.  The payload has already been vetted, so no further error checking is
* needed.
*******************************************************************************/
void Tx_Ping_Packet (void* payload,uint16_t len)
{
   /* Create the ping return packet */
   Struct_PingPacket.header.time_s       = htonl(FKGPS_Time) ;
   Struct_PingPacket.header.time_ns      = 0 ; /* 0 for pings? */
   Struct_PingPacket.header.Payload_Type = htons(PAYLOAD_T5PING) ;
   memcpy(Struct_PingPacket.PingData,payload,len) ;
   /* Challenge/response is handled later as it is common to all packets */

   /* Packet ready to send, send it! */
   SendDialPacket(PingPacket,len) ;
   TxPackets[PAYLOAD_T5PING]++ ;
}

/*******************************************************************************
* Routine  : FillTimeStamp
* Gazintas : None
* IOs      : secs  - Timestamp seconds (filled in)
*          : nsecs - Timestamp nanoseconds filled in)
* Returns  : Nothing
* Globals  :FKGPS_Time, FKGPS_Tns
*
* This routine fills in the timestamp header for a packet.  The timestamp to
* use is based on the packet timing mode and the format is converted to
* network format.  Data filled in is as follows:
*  - General Purpose: Current seconds based on server time, ns set to 0
*  - GPS: The time right now--including ns (very accurate)
*  - Fake GPS: Time at the start of the last packet (so 0-20ms late)
*
* THIS IS ONLY USED FOR AUTHENTICATION AND GPS PACKETS where timing is not that
* critical.  Timestamps for uLaw and ADPCM packets are handled seperately.
*******************************************************************************/
static void FillTimeStamp(uint32_t* secs, uint32_t* nsecs)
{
   uint32_t ts  ; /* Temp stuff for debugging */
   uint32_t tns ; /* Temp stuff for debugging */

   switch(DIALSettings.PacketTiming)
   {
      case PKTTIM_GP  :   *secs  = htonl(FKGPS_Time) ;
                          *nsecs = 0                 ;
                          break ;
      case PKTTIM_GPS :   Get_GPSTimeNow(&ts,&tns) ;
                          tns -= 2000 ; /* +1us */
                          if (tns>1000000000) {tns+=2000 ; ts-- ; } ; /* overflow */
                          *secs  = htonl(ts)  ;
                          *nsecs = htonl(tns) ;

                          //Get_GPSTimeNow(secs,nsecs) ;
                          //*secs  = htonl(*secs)  ;
                          //*nsecs = htonl(*nsecs) ;
                          break ;
      case PKTTIM_FKGPS : *secs  = htonl(FKGPS_Time) ;
                          *nsecs = htonl(FKGPS_Tns)  ;
                          break ;
      default           : break ;
   }
}

/*******************************************************************************
* Routine  : crc32_bufs
* Gazintas : buf1 - buffer #1 (null terminated challenge)
*          : buf2 - buffer #2 (null terminated password)
* IOs      : None
* Returns  : CRC32 of the concatenated buffers.
* Globals  : crc_32_tab
*
* This computes the CRC32 of two concatenated null-terminated strings. This was
* initially 100% copied from Voter1, then just tweaked a bit for my coding
* style.
* Also included is the use of the STM32H750s Hardware CRC calculator
* if enabled.  The STM32H750 has a hardware CRC calculator, but for very
* small variable length strings, the overhead of setting it up means the HW
* solution takes roughly the same time.  The real advantage of using the HW
* solution is saving the 1KByte of memory the SW CRC table consumes.
*******************************************************************************/
long crc32_bufs(unsigned char *buf1, unsigned char *buf2)
{

   long crc32 = 0xFFFFFFFF ; /* CRC32 accumulator */

#ifndef USE_HW_CRC
   while(buf1 && *buf1)
   {
      crc32 = crc_32_tab[(crc32 ^ *buf1++) & 0xff] ^ ((unsigned long)crc32 >> 8);
   }

   while(buf2 && *buf2)
   {
      crc32 = crc_32_tab[(crc32 ^ *buf2++) & 0xff] ^ ((unsigned long)crc32 >> 8);
   }
#else
           HAL_CRC_Calculate  (&hcrc,(uint32_t*)buf1,strlen((char*)buf1)) ;
   crc32 = HAL_CRC_Accumulate (&hcrc,(uint32_t*)buf2,strlen((char*)buf2)) ;
#endif

   return (~crc32);

}

/*******************************************************************************
* Routine  : SendDialPacket
* Gazintas : packet - pointer to packet to send
*          : len - Packet length
* IOs      : None
* Returns  : Nothing
* Globals  : TBD
*
* This is the common routine to actually send a DIAL packet over Ethernet.
* This takes care of the Challenge/Response processing, then sends the packet
* on.  It is aware of the header format, but doesn't need to know or care
* about the payload other than length.
*******************************************************************************/
static void SendDialPacket(uint8_t* packet, uint32_t len)
{
   err_t err = 0 ;
   struct netbuf *tx_buf = NULL    ; /* Tx packet buffer handle    */

   /* Take care of Challenge/Response negotiating */
   Tx_handleCR(packet+8,packet+18) ;

   if (!DIAL_Offline) /* Unless forcing an offline mode, send the data! */
   {
      /* Create a netbuf for the data, fill it out, send it, and then free it */
      tx_buf = netbuf_new();
      if (NULL==tx_buf)
      {
         IncErrLog(ERRLOG_SENDDIALPACKET_NETBUF_NEW,ERRLOG_SHOW) ;
      }
      else
      {
         netbuf_alloc(tx_buf,len);
         if (NULL==tx_buf)
         {
            IncErrLog(ERRLOG_SENDDIALPACKET_NETBUF_ALLOC,ERRLOG_SHOW) ;
         }
         else
         {
            err=pbuf_take(tx_buf->p, (const void *)packet,len);
            if (ERR_OK!=err)
            {
               IncErrLog(ERRLOG_SENDDIALPACKET_PBUF_TAKE,ERRLOG_SHOW) ;
            }
            else
            {
               err = netconn_sendto(DIALconn,tx_buf,&DIAL_Server_IP,DIALSettings.VoterPort);
               if (ERR_OK!=err)
               {
                  IncErrLog(ERRLOG_SENDDIALPACKET_NETCONN_SENDTO,ERRLOG_SHOW) ;
               }
            }
         }
         /* Even if errors after netbuf_new, always delete the netbuf */
         netbuf_delete(tx_buf);
      }
   }

   //Logger2_Msg(Logger.Dial,LOGGER2_DIALTASK,LOG_TIME,"DialTask: Sent UDP T:%d %d len:%d err:%d\r\n",packet[22],packet[23],len,err) ;
}

/*******************************************************************************
* Routine  : DIAL_Assert_Restart
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : DIAL_Restart
*
* This restarts the DIAL comms when called by the CLI. It sets DIAL_Restart to
* true that triggers a small state machine in Update_Counters().
*******************************************************************************/
void DIAL_Assert_Restart(void)
{
   DIAL_Restart = true ;
}

#endif /* #ifndef NODIALTASK */
