/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the I2C file.  It is in charge of the I2C interface (surprise! :)).*/
/* What makes this a bit tricker than normal is the I2C interface is used     */
/* before the RTOS starts up as well as two different tasks when the RTOS is  */
/* running.  Hence it needs a lot of extra controls to be safely shared.      */
/* For RTOS use, the I2C interface needs to be DMA controlled to not suck up  */
/* CPU cycles.                                                                */
/*                                                                            */
/* This is hard coded for I2C1 for now.  It could/should be generisized later.*/
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - I2C_SharedMemWrite - I2C write memory command.                          */
/*  - I2C_SharedMemRead  - I2C read memory command.                           */
/*  - I2C_SharedIsReady  - I2C is device there query.                         */
/*                                                                            */
/* Sorta public routines are: (__weak overrides for callbacks)                */
/*  - HAL_I2C_MemTxCpltCallback - DMA Tx complete callback                    */
/*  - HAL_I2C_MemRxCpltCallback - DMA Rx complete callback                    */
/*                                                                            */
/******************************************************************************/
// TO DO:
//
/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"
#include "netif/ethernet.h"
#include "task.h"

#include "I2C.h"
#include "Options.h"
#include "main.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern I2C_HandleTypeDef hi2c1;
extern osMutexId I2C_MutexHandle;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static int          IRQ_inRTOS   = false ; /* RTOS state for IRQ response     */
static volatile int I2C_DMA_Busy = false ; /* DMA busy flag for non-RTOS use  */
static osThreadId   IRQ_ThreadId = 0     ; /* Calling task for RTOS use       */

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void Waiton_I2C_DMA(int) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : I2C_SharedMemWrite
* Gazintas : bus_addr - I2C bus address being accessed
*          : dev-addr - Memory address within the I2C device
*          : devaddr_size - Device address size
*          : dbuf - data buffer to write
*          : len - Number of bytes to write
*          : inRTOS - RTOS running flag
* IOs      : None
* Returns  : Nothing
* Globals  : None directly (done in WaitonI2C_DMA)
*
* This takes care of a memory write.  This has the RTOS wrappers around the
* HAL_I2C_Mem_Write_DMA() API, so the parameters are the same as that call.
*******************************************************************************/
void I2C_SharedMemWrite(uint16_t bus_addr,uint16_t dev_addr,uint16_t devaddr_size,uint8_t* dbuf,uint16_t len,int inRTOS)
{

   /* If running under the RTOS, wait until the interface is available and as */
   /* a precaution, clear out any lingering signals before starting the write.*/
   if (inRTOS)
   {
      osMutexWait(I2C_MutexHandle,osWaitForever) ;
      osSignalWait (0x01,0) ; /* clear out any older signals */
   }

   /* We have the hardware! Do the write and wait for the DMA to finish */
   HAL_I2C_Mem_Write_DMA(&hi2c1,bus_addr,dev_addr,devaddr_size,dbuf,len) ;
   Waiton_I2C_DMA(inRTOS) ;

   /* If running under the RTOS, release the mutex */
   if (inRTOS) osMutexRelease(I2C_MutexHandle) ;
}


/*******************************************************************************
* Routine  : I2C_SharedMemRead
* Gazintas : bus_addr - I2C bus address being accessed
*          : dev-addr - Memory address within the I2C device
*          : devaddr_size - Device address size
*          : dbuf - data buffer for read result
*          : len - Number of bytes to read
*          : inRTOS - RTOS running flag
* IOs      : None
* Returns  : Nothing
* Globals  : None directly (done in WaitonI2C_DMA)
*
* This takes care of a memory read.  This has the RTOS wrappers around the
* HAL_I2C_Mem_Read_DMA() API, so the parameters are the same as that call.
*******************************************************************************/
void I2C_SharedMemRead(uint16_t bus_addr,uint16_t dev_addr,uint16_t devaddr_size,uint8_t*dbuf,uint16_t len,int inRTOS)
{
   /* If running under the RTOS, wait until the interface is available and as */
   /* a precaution, clear out any lingering signals before starting the write.*/
   if (inRTOS)
   {
      osMutexWait(I2C_MutexHandle,osWaitForever) ;
      osSignalWait (0x01,0) ; /* clear out any older signals */
   }

   /* We have the hardware! Do the read and wait for the DMA to finish */
   HAL_I2C_Mem_Read_DMA(&hi2c1,bus_addr,dev_addr,devaddr_size,dbuf,len) ;
   Waiton_I2C_DMA(inRTOS) ;

   /* If running under the RTOS, release the mutex */
   if (inRTOS) osMutexRelease(I2C_MutexHandle) ;
}

/*******************************************************************************
* Routine  : I2C_SharedIsReady
* Gazintas : bus_addr - I2C bus address being accessed
*          : trials - # of attempts to try
*          : timeout - Timeout for error
*          : inRTOS - RTOS running flag
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* This checks if a device is on the bux (checks for an ACK to the device
* address).  This has the RTOS wrappers around the HAL_I2C_IsDeviceReady() API,
* so the parameters are the same as that call.
*
* NOTE: This isnt' DMA-based, so not great running under the RTOS!
*******************************************************************************/
int I2C_SharedIsReady(uint16_t bus_addr,uint32_t trials, uint32_t timeout,int inRTOS)
{
   int rval = false ;

   /* If running under the RTOS, wait until the interface is available and as */
   /* a precaution, clear out any lingering signals before starting the write.*/
   if (inRTOS)
   {
      osMutexWait(I2C_MutexHandle,osWaitForever) ;
      osSignalWait (0x01,0) ; /* clear out any older signals */
   }

   /* We have the hardware! Do the check and wait for the DMA to finish */
   rval = (HAL_OK==HAL_I2C_IsDeviceReady(&hi2c1,bus_addr,trials,timeout)) ;

   /* If running under the RTOS, release the mutex */
   if (inRTOS) osMutexRelease(I2C_MutexHandle) ;

   return (rval) ;
}

/*******************************************************************************
* Routine  : Waiton_I2C_DMA
* Gazintas : inRTOS - flag we're running in the RTOS
* IOs      : None
* Returns  : Nothing
* Globals  : I2C_DMA, IRQ_inRTOS
*
* This waits for the I2C DMA to finish.  If in RTOS mode we wait on a signal,
* if in bare metal mode we wait on the semaphore.
* The tricky bit here is I note which task is making the call so that the IRQ
* routine knows which task to signal back to.
*******************************************************************************/
static void Waiton_I2C_DMA(int inRTOS)
{
   I2C_DMA_Busy = true   ; /* busy now (assumes DMA started before this call) */
   IRQ_inRTOS   = inRTOS ; /* Tell call-back how to signal things             */

   if (inRTOS)
   {
      /* Tell the end-of-DMA IRQ handler what thread we are so it knows which */
      /* thread to signal back to, then wait for the signal.                  */
      IRQ_ThreadId = osThreadGetId() ;
      osSignalWait (0x01,osWaitForever) ;
   }
   else
   {
      while (I2C_DMA_Busy) ;
   }
}

/*******************************************************************************
* Routine  : HAL_I2C_MemTxCpltCallback, HAL_I2C_MemRxCpltCallback
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : None
*
* Callbacks for I2C DMA Tx and Rx functions.  Let the caller know they are
* done!  Set the semaphore always (it just gets ignored in RTOS mode), but
* only call the signal if in RTOS mode.
*******************************************************************************/
void HAL_I2C_MemTxCpltCallback(I2C_HandleTypeDef *hi2c)
{
   I2C_DMA_Busy = false ;
   if (IRQ_inRTOS) osSignalSet (IRQ_ThreadId,0x01);
}

void HAL_I2C_MemRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
   I2C_DMA_Busy = false ;
   if (IRQ_inRTOS) osSignalSet (IRQ_ThreadId,0x01);
}
