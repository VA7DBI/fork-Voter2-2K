/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Tx_DSP file.  It is in charge of all the Transmit DSP          */
/* functions.  These routines get passed a packets worth of decompressed      */
/* samples from the Ethernet interface and prepares that data for DMAing to   */
/* the audio DACS.  This includes buffering, any filtering and CTCSS stuff    */
/* and (eventually) time stamp syncing.                                       */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Tx_ClearPacket - Clear a packet to "0V"                                 */
/*  - Tx_EnqPacket - Process an incoming packet, put it in the FIFO.          */
/*  - Tx_DeqPacket - Get a packet (if available) and put into DAC DMA buffer  */
/*  - AddATone - Add a tone to a packet of audio                              */
/*  - ProbeCheck - Copies debug data to DAC2 buffer if it's the probe         */
/*                                                                            */
/******************************************************************************/
/* For the transmit data here is where we do our buffering to handle any      */
/* Network jitter (dictates minimum value).  For local and general purpose    */
/* audio without timestamps, the delay is just translated into packets of     */
/* storage before starting the output FIFO.  For GPS-timed packets that       */
/* support simulcast, the delay can be down to the sample level.  I could do  */
/* sub-sample timing, but since the A2D/DAC clock is already phase-locked to  */
/* the GPS1PPS, doesn't seem to be necessary.                                 */
/******************************************************************************/
// TO DO:
//
/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h> /* for memcpy */

#include "Options.h"
#include "main.h"
#include "Utils.h"
#include "Debugging.h"
#include "SetShow.h"
#include "AnalogIO.h"
#include "Tx_DSP.h"
#include "Gpio.h"
#include "DialTaskOut.h"
#include "Settings.h"
#include "Codecs.h"
#include "GPS.h"
#include "Histograms.h"
#include "Timers.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
/* The Tx Jitter buffer is a user-settable parameter.  For voting, the max    */
/* delay is 800ms which comes out to 40 160-sample buffers.  Adding a couple  */
/* more as we need a bit of margin if the user selects the full 800ms.        */
/* This is a pretty decent-sized buffer, almost 14KBytes!                     */
/* If not voting (local mode only), this can be a MUCH smaller buffer!!       */
#ifndef NODIALTASK
#define TXFIFO_NBUFS 42  /* Number of packets in Tx FIFO with voting support  */
#else
#define TXFIFO_NBUFS 5  /* Number of packets in Tx FIFO in local-only mode    */
#endif

#define INVERTED_OUTPUT /* The Voter/RTCM send the audio through an inverting */
                        /* amplifier whereas the Voter2 uses a non-inverting  */
                        /* amplifier.  This makes them compatible.            */


/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
/* For offline CTCSS Tones.  The default is off unless a local mode overrides */
/* it.  Note that each local mode has its own settings structure, so for code */
/* independence, this is the common setting each local mode must set.         */
uint8_t  Local_CTCSS_Lvl = 0 ;
uint8_t  Local_CTCSS_Freq = 0 ;

/* For the TxFIFO delay, this can be set by different settings "sources"      */
/* that can be compiled in or not, so just have GlobDialTxBufDly here with a  */
/* default value and whatever other code that can change it will.             */
/* Note that this is in ns!  I need that for simulcast.                       */
uint32_t GlobDialTxBufDly = 60000000 ;
/* Same idea for local mode delay... */
uint32_t GlobLocTxBufDly = 60000000 ;

uint16_t ProbeBuf[APKT_SAMPLES] = {0} ; /* Probe data buffer */

/* Flag to ignore DIAL audio in favor of local audio.  Needed so I can send   */
/* the ONLINE message cleanly if DIAL connects and is sending audio at the    */
/* same time.                                                                 */
int LocalOverride = false ;

TONE_CONTEXT TTone_Context = {0,100000,100,TONE_BYPASS} ; /* Test tone. 1KHz but disabled */

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
/* The Transmit FIFO */
static int16_t     TxFIFO[TXFIFO_NBUFS][APKT_SAMPLES] = {0} ; /* The audio tx buffer (big!) */
static int8_t      TxFIFO_Busy[TXFIFO_NBUFS]          = {0} ; /* Flag that packet has audio */

/* This is timing-critical data between the TxFIFO enqueuer and dequeuer.  I  */
/* occasionally get tripped up by the optimizer where I'm checking a variable */
/* in a tight loop where it gets updated by an ISR.  The optimiser doesn't    */
/* seem to realize that and optimizes the loop assuming the variable can't    */
/* change!                                                                    */
static volatile int      PPPIndex           =  0  ; /* Ping Pong Packet Index */
static volatile uint32_t PPPTime            =  0  ; /* Ping Pong Packet Timestamp */
static volatile int      FIFO_PtrUpdateFlag =  1  ; /* Pointer updated flag   */

static TONE_CONTEXT CTCSS_Context = {0, 10000, 10,TONE_BYPASS} ; /* CTCSS tone. 100Hz but disabled */

/* Also cast the TxFIFO as just a big one-dimensional array.  The enqueue-er  */
/* treats it as one big one-dimensional array, the dequeue-er pulls it down   */
/* by packets, so this makes the code a bit easier to read.                   */
#define TxFIFO1D ((int16_t*)&TxFIFO)

#if 1
/* This is a table of all the CTCSS tones and their frequency in 1/100ths of  */
/* a Hz.                                                                      */
static int16_t CTCSS_Deltas[] = {
   6700 , // CTCSS_670
   7190 , // CTCSS_719
   7440 , // CTCSS_744
   7700 , // CTCSS_770
   7970 , // CTCSS_797
   8250 , // CTCSS_825
   8540 , // CTCSS_854
   8850 , // CTCSS_885
   9150 , // CTCSS_915
   9480 , // CTCSS_948
   9740 , // CTCSS_974
   10000, // CTCSS_1000
   10350, // CTCSS_1035
   10720, // CTCSS_1072
   11090, // CTCSS_1109
   11480, // CTCSS_1148
   11880, // CTCSS_1188
   12300, // CTCSS_1230
   12730, // CTCSS_1273
   13180, // CTCSS_1318
   13650, // CTCSS_1365
   14130, // CTCSS_1413
   14620, // CTCSS_1462
   15140, // CTCSS_1514
   15670, // CTCSS_1567
   16220, // CTCSS_1622
   16790, // CTCSS_1679
   17380, // CTCSS_1738
   17990, // CTCSS_1799
   18620, // CTCSS_1862
   19280, // CTCSS_1928
   20350, // CTCSS_2035
   21070, // CTCSS_2107
   21810, // CTCSS_2181
   22570, // CTCSS_2257
   23360, // CTCSS_2336
   24180, // CTCSS_2418
   25030, // CTCSS_2503
} ;
#else
/* Below is the increment (in 100ths of a degree) per sample of a sinewave    */
/* at the specified frequency.  A sample of course being at 8KHz.             */
/* This is a SW implementation of what I see in hardware Digital Phase Locked */
/* loops and seems to fit quite nicely here.  Yea, using degrees instead of   */
/* radians or something is probably non-standard, but it is just an index, so */
/* doesn't really matter and makes more sense to me.                          */
/* The idea is we increment the phase counter by the value below every sample */
/* then do a lookup of the sine value based on that phase.                    */
/* See Voter2-2K Support.xlsx for how I computed this.                        */
static int16_t CTCSS_Deltas[] = {
   302, // CTCSS_670
   324, // CTCSS_719
   335, // CTCSS_744
   347, // CTCSS_770
   359, // CTCSS_797
   371, // CTCSS_825
   384, // CTCSS_854
   398, // CTCSS_885
   412, // CTCSS_915
   427, // CTCSS_948
   438, // CTCSS_974
   450, // CTCSS_1000
   466, // CTCSS_1035
   482, // CTCSS_1072
   499, // CTCSS_1109
   517, // CTCSS_1148
   535, // CTCSS_1188
   554, // CTCSS_1230
   573, // CTCSS_1273
   593, // CTCSS_1318
   614, // CTCSS_1365
   636, // CTCSS_1413
   658, // CTCSS_1462
   681, // CTCSS_1514
   705, // CTCSS_1567
   730, // CTCSS_1622
   756, // CTCSS_1679
   782, // CTCSS_1738
   810, // CTCSS_1799
   838, // CTCSS_1862
   868, // CTCSS_1928
   916, // CTCSS_2035
   948, // CTCSS_2107
   981, // CTCSS_2181
   1016,// CTCSS_2257
   1051,// CTCSS_2336
   1088,// CTCSS_2418
   1126,// CTCSS_2503
} ;
#endif
/* There may be fancier ways of doing this, but this is simple.  It is the    */
/* first quarter of a full scale (16-bit) sine wave in increments of one      */
/* degree.  When creating a CTCSS tone the degree count gets incremented in   */
/* hundredths of a degree using the index above, then the whole degree amount */
/* is used to look up the sine value.  The overall accuracy is still 1/100th  */
/* of a degree and rounding to a degree is just a bit of amplitude noise.     */
/* Digital PLLs are cool, hence liking this SW implementation.                */
/* It is only the first quarter of the sine wave as the other three quarters  */
/* space isn't a huge concern, but still want to be efficient.                */
/* NOTE: An optimization to this would be for the table's length to be a      */
/* power of 2 instead of 91.                                                  */
static int16_t sinetable_16s[91] = {
       0,  572, 1144, 1715, 2286, 2856, 3425, 3993,
    4560, 5126, 5690, 6252, 6813, 7371, 7927, 8481,
    9032, 9580,10126,10668,11207,11743,12275,12803,
   13328,13848,14365,14876,15384,15886,16384,16877,
   17364,17847,18324,18795,19261,19720,20174,20622,
   21063,21498,21926,22348,22763,23170,23571,23965,
   24351,24730,25102,25466,25822,26170,26510,26842,
   27166,27482,27789,28088,28378,28660,28932,29197,
   29452,29698,29935,30163,30382,30592,30792,30983,
   31164,31336,31499,31651,31795,31928,32052,32166,
   32270,32365,32449,32524,32588,32643,32688,32723,
   32748,32763,32767
} ;
/* Now a 12-bit table for unsigned sine waves */
static int16_t sinetable_12u[91] = {
      0,  36,  71, 107, 143, 178, 214, 250,
    285, 320, 356, 391, 426, 461, 495, 530,
    565, 599, 633, 667, 700, 734, 767, 800,
    833, 866, 898, 930, 961, 993,1024,1055,
   1085,1115,1145,1175,1204,1233,1261,1289,
   1316,1344,1370,1397,1423,1448,1473,1498,
   1522,1546,1569,1592,1614,1636,1657,1678,
   1698,1718,1737,1755,1774,1791,1808,1825,
   1841,1856,1871,1885,1899,1912,1924,1936,
   1948,1959,1969,1978,1987,1996,2003,2010,
   2017,2023,2028,2033,2037,2040,2043,2045,
   2047,2048,2048
} ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
//static void Tx_AddTones (int16_t*,int16_t*) ;
static void MakeDAClike(int16_t*,uint16_t*,int) ;
static void HandleDebugData(uint16_t*) ;
static void AddCTCSS(int16_t*,int16_t*) ;
static void AddTTone(int16_t*,int16_t*) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Tx_ClearPacket
* Gazintas : buf - Buffer to clear (sample buffer, so 1/2 of DMA buffer)
*          : channel - which channel to clear
* IOs      : None.
* Returns  : Nothing
* Globals  : None
*
* This routine clears out a channel in the ping or pong buffer to 0V (midway
* point for DAC).  It isn't quite trivial as it is a "stereo" buffer for the
* main and debug outputs, so clears one channel only, not both.
*******************************************************************************/
void Tx_ClearPacket(uint16_t* buf,int channel)
{
   int i = 0 ;
   for (i=0;i<APKT_SAMPLES;buf[(i++)*2+channel]=ADAC_0V) ;
}

/*******************************************************************************
* Routine  : `
* Gazintas : SrcBuffer - pointer to 16-bit uncompressed audio samples
*          :  - Normally 160 samples if voting supported, variable if local-only
*          : Pkt_Type - Packet timing type
*          : TS_secs - Packet timestamp - seconds
*          : TS_ns - Packet timestamp - ns
* IOs      : None.
* Returns  : Nothing
* Globals  : TxFIFO - Tramsmiter FIFO
*          : DAC_Busy - DAC Busy state (to stall initial transmission)
*          : TxFIFO_WrPtr - Transmit FIFO Write Pointer
*          : TxFIFO_RdPtr - Transmit FIFO Read Pointer
*
* This routine is the handler for a packets worth of audio samples from the
* server (if connected) or incoming audio (if in local mode).  See top header
* for how buffering works.
*
* Max execution time 4.6us (0.023% of CPU load)
*******************************************************************************/
void Tx_EnqPacket(int16_t* SrcBuffer,int Pkt_Type,uint32_t TS_secs,uint32_t TS_ns)
{
   static uint32_t LastTs  = 0 ; /* Last timestamp - seconds  */
   static uint32_t LastTns = 0 ; /* Last timestamp - ns       */
   uint32_t        TsDelta = 0 ; /* Delta from last timestamp */

   static int      Last_Pkt_Type    =  LOCAL_TIMED ; /* To detect a source change */
   static int      Local_Copy_Index = 0            ; /* For local/general copying */  /* Does this need to be static??? */
   static int      Local_Copy_Ref   = 0            ; /* For local/general copying */
   static uint32_t Last_Count       = 0            ; /* Last local/general count  */
   static int      Last_Copy_Index  = 0            ; /* Last index (to find gaps) */

   int      i                = 0 ; /* General counter               */
   uint32_t DAC_TStamp       = 0 ; /* Last DAC event Timestamp      */
   int      DAC_Index        = 0 ; /* Last DAC event index          */
   int      Copy_Index       = 0 ; /* Sample copying index          */
   uint32_t Pkt_TStamp       = 0 ; /* Curent packet Timestamp       */
   uint32_t TsDelta_ns       = 0 ; /* Timestamp delta (ns)          */
   uint32_t TsDelta_Samples  = 0 ; /* Timestamp delta (samples)     */

 //AISR_SHOWSTART ;

   /* Get the most recent pointer and timestamp for that pointer from the     */
   /* queue "getter" (the DMA stuffer).  The getter runs at a higher          */
   /* interrupt priority and updates FIFO_PtrUpdateFlag once done, so if it   */
   /* interrupts read below FIFO_PtrUpdateFlag will no longer be 0 and get    */
   /* re-read.                                                                */
   do
   {
      FIFO_PtrUpdateFlag = 0 ;
      DAC_TStamp = PPPTime ;
      DAC_Index  = PPPIndex*APKT_SAMPLES ;
   } while (0!=FIFO_PtrUpdateFlag) ;

   if (LOCAL_TIMED==Pkt_Type)
   {
      /* If this is a different packet type from before, or we've lost more   */
      /* than two packets in a row, reset our target index                    */
      /* Maybe later get fancier later than just "lost more than two packets" */
      if ((Last_Pkt_Type!=Pkt_Type) || (TS_ns>Last_Count+2))
      {
         Local_Copy_Index = (DAC_Index + GlobLocTxBufDly/125000)%(TXFIFO_NBUFS*APKT_SAMPLES) ;
         Local_Copy_Ref   = TS_ns ;
      }

      /* Now that we have a reference count value and a DAC index to reference*/
      /* it to, subsequent copy locations are just the difference between the */
      /* current and reference indexes times the packet length.  This way if  */
      /* a packet gets dropped its space will just be left with silence.      */
      Copy_Index = (Local_Copy_Index+(TS_ns-Local_Copy_Ref)*APKT_SAMPLES)%(TXFIFO_NBUFS*APKT_SAMPLES) ;
   }
   else if (GENERAL_TIMED==Pkt_Type)
   {
      /* If this is a different packet type from before, or we've lost more   */
      /* than two packets in a row, reset our target index                    */
      /* Maybe later get fancier later than just "lost more than two packets" */
      if ((Last_Pkt_Type!=Pkt_Type) || (TS_ns>Last_Count+2))
      {
         Local_Copy_Index = (DAC_Index + GlobDialTxBufDly/125000)%(TXFIFO_NBUFS*APKT_SAMPLES) ;
         Local_Copy_Ref   = TS_ns ;
      }

      /* Now that we have a reference count value and a DAC index to reference*/
      /* it to, subsequent copy locations are just the difference between the */
      /* current and reference indexes times the packet length.  This way if  */
      /* a packet gets dropped its space will just be left with silence.      */
      Copy_Index = (Local_Copy_Index+(TS_ns-Local_Copy_Ref)*APKT_SAMPLES)%(TXFIFO_NBUFS*APKT_SAMPLES) ;
   }
   else /* GPS Timed packets */
   {
      /* Compute the timestamp for the current packet.  This timestamp is in  */
      /* ns modulo 4 seconds.  As the longest txbuf delay is 800ms, we are    */
      /* good on unintentional overflows.  Next, add the TxDelay value from   */
      /* settings (via GlobDialTxBufDly) and that is the timestamp at which we*/
      /* want the first sample of this packet to go out.                      */
      Pkt_TStamp =(TS_secs%4)*1000000000+TS_ns + GlobDialTxBufDly ;

#if 0
      /* Some temporary sanity checking on timestamps                         */
      /* Uncomment all occurances of Last_Pkt_TStamp and Last_DAC_TStamp!     */
      if (((Pkt_TStamp-Last_Pkt_TStamp)>20100000) || ((Pkt_TStamp-Last_Pkt_TStamp)<19900000))
      {
         DLogger_Event(DLOGGER_TXDIALTSERR,Pkt_TStamp-Last_Pkt_TStamp) ;
         DLogger_Event(DLOGGER_TXDIALTSERR,TS_secs) ;
         DLogger_Event(DLOGGER_TXDIALTSERR,TS_ns) ;
      }
#endif

      /* We have the timestamp and location in the TxFIFO of the last DMAd    */
      /* packet and the Timestamp of the first sample of the packet we want to*/
      /* get queued up.  The difference between the two is how far in the     */
      /* "future" the first sample of this packet goes.  Initially in ns.     */
      /* As the minimum txbuf is 60ms (60,000,000ns), this should always be a */
      /* positive number.  If a wrap, the modulo math fixes that.             */
      TsDelta_ns = (Pkt_TStamp - DAC_TStamp)%4000000000 ;

      /* Now that we have the delta in ns, convert it to samples and          */
      /* sub-samples.  Sub-samples are in units of the TIM2 timer tick that   */
      /* is 25ns per tick.                                                    */
      TsDelta_Samples  =  TsDelta_ns/125000     ;

      /* For measuring the network delay I pass the timestamp of the just-    */
      /* received packet to the logger.  It compares it to the local GPS-based*/
      /* time to figure out the network delay for audio packets.  This        */
      /* assumes the audio packet was stamped with the exact time it was      */
      /* created so when it arrives here is the round trip network delay.     */
      NetDelay_Log(((TS_secs%4)*1000000000+TS_ns)%4000000000) ;

      /* For temporary debugging, log timestamp delta between packet and      */
      /* time.                                                                */
      if (1==DbFlags[DBFLAG_TSDELTAS]) DLogger_Event(DLOGGER_TSDELTANS,TsDelta_ns) ;

      /* Now that we know how many samples "in the future" this new data goes,*/
      /* that plus the index we got from the DAC is the array starting point. */
      /* Take care of any possible wraps too.                                 */
      Copy_Index = (DAC_Index + TsDelta_Samples)%(TXFIFO_NBUFS*APKT_SAMPLES) ;
   } /* if GPS-timed packets */

   /* Whether it was a local, general, or GPS-timed packet, we get here with  */
   /* Copy_Index being the place in the TxFIFO to copy the data to.           */

   /* LocalOverride is to allow the locally generated "OFFLINE" CWID to go    */
   /* out after a DIAL connection is established, so allows local audio to    */
   /* go out even if DIAL is up.  The exception to this exception (??!!) is   */
   /* if we get audio from the DIAL server while LocalOverride is still set.  */
   /* In that case, kill the LocalOverride CWID in favor of DIAL audio.       */
   if (LocalOverride && (LOCAL_TIMED!=Pkt_Type)) LocalOverride = false ;

   /* If local audio or non-overridden DIAL audio, copy the data to the DAC   */
   /* buffer!                                                                 */
   if ((LOCAL_TIMED==Pkt_Type) || !LocalOverride)
   {

#if 1
      /* We have saved the index from the last packet copy, ideally this index*/
      /* should be right after it.  If not, we cycle slipped somewhere!       */
      if (Copy_Index != Last_Copy_Index)
      {
         DLogger_Event(DLOGGER_TXFIFOSLIP,Copy_Index-Last_Copy_Index) ;
         //DLogger_Event(DLOGGER_TXFIFOSLIP,DAC_Index) ;
         //DLogger_Event(DLOGGER_TXFIFOSLIP,TsDelta_Samples) ;
         //DLogger_Event(DLOGGER_TXFIFOSLIP,TsDelta_ns) ;
         //DLogger_Event(DLOGGER_TXFIFOSLIP,Pkt_TStamp) ;
         //DLogger_Event(DLOGGER_TXFIFOSLIP,Last_Pkt_TStamp) ;
         //DLogger_Event(DLOGGER_TXFIFOSLIP,DAC_TStamp) ;
         //DLogger_Event(DLOGGER_TXFIFOSLIP,Last_DAC_TStamp) ;
      }
#endif

      /* First, mark the packet index's busy flag as having audio.  As the    */
      /* sufio almost certainly spans two DMA packets, mark the DAC packet    */
      /* where the copying starts as well as the next packet.                 */
      i = Copy_Index/APKT_SAMPLES ;
      TxFIFO_Busy[i] = true ;
      i = (i+1)%TXFIFO_NBUFS ;
      TxFIFO_Busy[i] = true ;

      /* ...and finally copy the data */
      for (i=0;i<APKT_SAMPLES;i++)
      {
         TxFIFO1D[Copy_Index] = SrcBuffer[i] ;
         Copy_Index = (Copy_Index+1)%(TXFIFO_NBUFS*APKT_SAMPLES) ;
      }

      Last_Pkt_Type   = Pkt_Type   ;
      Last_Count      = TS_ns      ;
      Last_Copy_Index = Copy_Index ;

      //Last_Pkt_TStamp = Pkt_TStamp ;
      //Last_DAC_TStamp = DAC_TStamp ;
   }

   /* Get the number of ms since the last timestamp.  As these timestamps are */
   /* coming from the DIAL server, I'm assuming they are pretty much perfect. */
   /* The two reasons for an error are a dropped packet or pause between      */
   /* transmissions.                                                          */
   if (!LocalOverride)
   {
      if (PKTTIM_GPS==Pkt_Type) /* Only makes sense for GPS packets */
      {
         TsDelta   = ((TS_secs-LastTs)*1000000000)+TS_ns-LastTns ;  /* In ns  */
         TsDelta   = TsDelta/1000000                             ;  /* To ms  */

         /* Not doing any precise limit checking here, only course ms.  If any*/
         /* errors, they are going to be big.                                 */
         /* Also if more than 255ms I'm just going to assume it was a pause   */
         /* between transmissions, not a lost packet.                         */
         if ((TsDelta<19) || ((TsDelta>21) && (TsDelta<256))) RtFlags[RTFLAG_DIALDELTA] = TsDelta ;
      }

      /* Save all of the current states for comparisons next time. */
      LastTs        = TS_secs ;
      LastTns       = TS_ns ;
   }

   /* Now checking for something like cache problems... */
 //AISR_SHOWEND ;
}

/*******************************************************************************
* Routine  : Tx_DeqPacket
* Gazintas : TargetBuf - Next buffer (ping or pong) to fill.
*          : PktTimerVal - TIM2 value for the last sample of the last packet.
* IOs      : None.
* Returns  : Nothing
* Globals  : TxFIFO - Transmitter FIFO
*          : DAC_Busy - DAC Busy state (to stall initial transmission)
*          : TxFIFO_WrPtr - Transmit FIFO Write Pointer
*          : TxFIFO_RdPtr - Transmit FIFO Read Pointer
*
* This routine gets the next available packet of data from the Tx FIFO, does
* any DSPing (CTCSS and pre-emphasis), and puts it into either the Ping or Pong
* buffer depending on which ISR called it.
* See top header for how buffering works.
*
* OPEN ISSUE: Data going to the A2D is 12-bit unsigned DAC samples.  The
* incoming data and decompression algos assume 16-bit signed samples.  Should
* I decimate to 12-bit first then do all the DSP on 12-bit data then convert to
* the A2D or stick with 16-bit data and do the DSP on 16-bit data? I like less
* chance of overflows but might have better DSPing with more bits.  Going
* to go 16-bit DSPing for now.
*
* Execution time of this ISR depends on if we are transmitting or not, or adding
* tones or not.  Without any big filters, no CMSIS DSP routines here (yet).
* Execution time with C code: 3.68us min, 16.2us max. (0.081% of the CPU)
* Execution time with CMSIS: N/A
*
*******************************************************************************/
void Tx_DeqPacket(uint16_t* TargetBuf,uint32_t PktTimerVal)
{
   static int16_t Tx_ppbuf1[APKT_SAMPLES] ; /* Pipeline buffer for uncompressed audio */

   int16_t* SrcData = NULL ; /* Shared packet source pointer */
   static int      PktIndex   = 0 ; /* Packet index         */
   static uint32_t LastTmrVal = 0 ; /* Last Timer value     */

   int      i          = 0 ; /* General counter      */
   uint32_t TSecs      = 0 ; /* Current time Seconds */
   uint32_t TnSecs     = 0 ; /* Current time nSecs   */
   uint32_t DAC_TStamp = 0 ; /* Timestamp (see note) */

   /* Get a 32-bit timestamp for the current packet.  At 32 bits this rolls   */
   /* over about ever 4 seconds, so do it modulo 4 secs.  This is fine as the */
   /* max buffer size is around 800ms, so should be no overflows.             */
   Get_GPSTime(PktTimerVal,&TSecs,&TnSecs) ;
   DAC_TStamp = (TSecs%4)*1000000000+TnSecs ;

#if 1
   /* Check on the integrity of the timestamp, it should be 20ms from the     */
   /* last one.                                                               */
   if (((PktTimerVal-LastTmrVal)<799900) || ((PktTimerVal-LastTmrVal)>800100))
   {
      DLogger_Event(DLOGGER_TXDACTERR,PktTimerVal-LastTmrVal) ;
   }

   LastTmrVal = PktTimerVal ;
#endif

   /* I now have the timestamp for the upcoming DMA packet and the index      */
   /* of where that data will go.  Let the TxFIFO enqueuer know.  There       */
   /* can be race conditions here!  This task is a higher priority than       */
   /* the enqueuer, so it clears FIFO_PtrUpdateFlag, reads the data, then     */
   /* checks FIFO_PtrUpdateFlag again.  If it stayed 0, it has a valid        */
   /* read.  I've had weird optimizer issues, so all three variables          */
   /* below are cast as volatile.                                             */
   PPPIndex = PktIndex   ;
   PPPTime  = DAC_TStamp ;
   FIFO_PtrUpdateFlag++  ;

   /* Point to the source data even if we aren't going to be transmitting.    */
   /* In that case it is just silence going to the DAC.                       */
   SrcData = TxFIFO[PktIndex] ;

   /* If the current buffer to be copied has data in it (noted by             */
   /* TxFIFO_Busy[]), then light things up!  Also light things up if test     */
   /* tones are enabled.                                                      */
   if ((TxFIFO_Busy[PktIndex]) || (TONE_BYPASS != TTone_Context.mix))
   {
      Show_State(TX_STATE,true) ;
      PTT_State(true) ;

      /* ******************************************************************** */
      /* THIS IS THE MAIN TRANSMITTER COMPUTATIONAL SEQUENCE!!  Here is where */
      /* we convert IP-received data to DAC samples!!!                        */
      /* ******************************************************************** */
      /* After each step I have ProbeCheck().  This allows the user to "probe"*/
      /* the audio signal after each step in the chain and see the results on */
      /* DAC2.  What to probe is a CLI command.                               */
      /* ******************************************************************** */

      ProbeCheck(SrcData,PROBE_TXSRC ,PROBE_AUDIO) ;
      /* Coming Maybe?: Pre-emphasis               ; */
      AddCTCSS   (SrcData,  Tx_ppbuf1)             ;
      AddTTone   (Tx_ppbuf1,Tx_ppbuf1)             ;
      MakeDAClike(Tx_ppbuf1,TargetBuf,MAINBUF)     ;

      /* Add the debug channel data. */
      HandleDebugData(TargetBuf) ;

   }
   else
   {
      /* If not busy, make sure the DAC output buffer is filled with silence  */
      /* and turn off PTTs (both of them)                                     */
      MakeDAClike(SrcData,TargetBuf,MAINBUF) ;
      Show_State(TX_STATE,false) ;
      PTT_State(false) ;
   }

   /* Now that we are done with the packet in the TxFIFO, (used or not) go    */
   /* ahead and clear it out to "0V".  That way if we stop getting data in,   */
   /* we'll keep sending out silence and any misaligned packets getting       */
   /* added later will be surrounded by silnece at both ends.                 */
   /* Also, mark the packet as no longer busy (active audio data)             */
   for (i=0;i<APKT_SAMPLES;i++) TxFIFO[PktIndex][i] = ADAC_0V ;
   TxFIFO_Busy[PktIndex] = false ;

   /* And finally increment and wrap the index counter */
   PktIndex = (PktIndex+1)%TXFIFO_NBUFS ;
}

/*******************************************************************************
* Routine  : MakeDAClike
* Gazintas : SignedData Audio samples in 16-bit signed format
*          : Buffer - which buffer (main vs debug)
* IOs      : DACData - Audio samples in unsigned 12-bit offset format
* Returns  : Nothing
* Globals  : None
*
* This routine converts the 16-bit signed data with 0V at 0 used by the DSP
* routines into DAC format which is 12-bit unsigned, with 0V at the mid way
* point.
* This routine also takes care of the interleaving between the main and debug
* channels.
*
* The Voter/RTCM send the audio through an inverting amplifier whereas the
* Voter2 uses a non-inverting amplifier.  the #define INVERTED_OUTPUT handles
* this.
*
* Execution time with C code: 1.77us max.
* Execution time with CMSIS: N/A
*******************************************************************************/
static void MakeDAClike(int16_t* SignedData,uint16_t* DACData,int buffer)
{
   int i = 0 ;

   ProbeCheck(SignedData,PROBE_TXOUT,PROBE_AUDIO) ;

   for (i=0;i<APKT_SAMPLES;i++)
   {
#ifndef INVERTED_OUTPUT
      DACData[(i*2)+buffer] = (uint16_t)((SignedData[i]>>4)+2048) ;
#else
      DACData[(i*2)+buffer] = (uint16_t)(2048-(SignedData[i]>>4)) ;
#endif
   }
}

/*******************************************************************************
* Routine  : Tx_AddTones
* Gazintas : in - audio samples before adding CTCSS
* IOs      : out - audio samples with CTCSS added
* Returns  : Nothing
* Globals  : Settings, DIAL_State
*
* This routine adds test and/or CTCSS tones to the packet of audio if requested.
* Test tones replace any incoming audio completely with the frequency and
* amplitude called out in Settings.  CTCSS tones are only applicable in local
* mode.  The frequency and volume are called out in local Settings.  If the
* CTCSS volume is 0, that means CTCSS is disabled.
*
* Execution time with C code: 0us min, 14.2us max.
* Execution time with CMSIS: N/A
*******************************************************************************/
#if 0
static void Tx_AddTones (int16_t* in,int16_t* out)
{
   static uint32_t ttphase = 0 ; /* Phase accumulator of the test tone */
   static uint32_t phase   = 0 ; /* Phase accumulator of the PL tone   */
   int             degonly = 0 ; /* Phase in unit degrees only         */
   int16_t         tone    = 0 ; /* Tone voltage level                 */
   int             i       = 0 ; /* General counter                    */
   int32_t         tmp     = 0 ; /* 32-bit temp value (no overflows!)  */

   /* If test tones are enabled, replace the incoming audio with the test tone*/
   if (TTONE_NONE!=Settings.TTone_lvl)
   {
      for (i=0;i<APKT_SAMPLES;i++)
      {
         /* Increment the test tone phase based on the selected frequency and */
         /* handle wrap-around (360 degrees in 1000ths of a degree)           */
         /* NOTE: freq*45 is simplified freq/8000*360000 to avoid overflows   */
         ttphase = (ttphase + Settings.TTone_freq*45)%360000 ;

         /* Get just integer degrees and then do the four quadrants of the    */
         /* sine wave table.                                                  */
         degonly = ttphase/1000 ;
              if (degonly< 90) tone =  sinetable[degonly    ] ;
         else if (degonly<180) tone =  sinetable[180-degonly] ;
         else if (degonly<270) tone = -sinetable[degonly-180] ;
         else                  tone = -sinetable[360-degonly] ;

         /* Figger it out in 32-bit space where it may overflow intermediately*/
         /* before putting it back in 16-bit space.                           */
         tmp = tone*Settings.TTone_lvl ;
         in[i] = tmp>>12 ;
      }
   }

   /* If DIAL active (not local mode), or if local and the CTCSS volume level */
   /* is 0, then just copy samples.                                           */
   if ((DIAL_ACTIVE) || (0==Local_PLL_Lvl))
   {
      memcpy(out,in,APKT_SAMPLES*2) ;
   }
   else
   {
      for (i=0;i<APKT_SAMPLES;i++)
      {
         /* Increment the PL tone phase based on the selected frequency and   */
         /* handle wrap-around (360 degrees in 100ths of a degree)            */
         phase = (phase + CTCSS_Deltas[Local_PLL_Freq])%36000 ;

         /* Get just integer degrees and then do the four quadrants of the    */
         /* sine wave table.                                                  */
         degonly = phase/100 ;
              if (degonly< 90) tone =  sinetable[degonly    ] ;
         else if (degonly<180) tone =  sinetable[180-degonly] ;
         else if (degonly<270) tone = -sinetable[degonly-180] ;
         else                  tone = -sinetable[360-degonly] ;

         /* I was getting set up to do some fancy logarithmic volume mixing,  */
         /* but that looked really messy and so just going to try linear      */
         /* volume mixing first.                                              */
         /* Volumes 0-10 will be 0%-100% tone respectively with the incoming  */
         /* audio decreased by the inverse (100-x) amount to ensure no        */
         /* overflow.                                                         */

         /* Figger it out in 32-bit space where it may overflow intermediately*/
         /* before putting it back in 16-bit space.                           */
         tmp = (tone*Local_PLL_Lvl + in[i]*(10-Local_PLL_Lvl)) ;
         out[i] = tmp/10 ;
      }
   }

   /* Check for probing */
   ProbeCheck(out,PROBE_TXPL,PROBE_AUDIO) ;
}
#endif

/*******************************************************************************
* Routine  : AddCTCSS
* Gazintas : in - Packet source (16-bit samples)
* IOs      : out - Packet destination (16-bit samples)
* Returns  : Nothing
* Globals  : CTCSS_Context
*
* If CTCSS is enabled, this routine adds a CTCSS tone to the audio.
*******************************************************************************/
static void AddCTCSS(int16_t* in,int16_t* out)
{
   if ((DIAL_ACTIVE) || (0==Local_CTCSS_Lvl))
   {
      /* If in DIAL mode or local PLL disabled, don't do nuthin. */
      /* This extra compare saves adding a "silent" tone every   */
      /* packet in local mode if CTCSS isn't enabled.            */
      CTCSS_Context.mix = TONE_BYPASS ;
   }
   else
   {
      /* Add a tone! */
      CTCSS_Context.mix   = TONE_ADD ;
   }

   CTCSS_Context.freq  = CTCSS_Deltas[Local_CTCSS_Freq] ;
   CTCSS_Context.level = Local_CTCSS_Lvl                ;
   AddATone16s(in,out,&CTCSS_Context )                  ;

   ProbeCheck(out,PROBE_TXPL,PROBE_AUDIO) ;
}

/*******************************************************************************
* Routine  : AddTTone
* Gazintas : in - Packet source (16-bit samples)
* IOs      : out - Packet destination (16-bit samples)
* Returns  : Nothing
* Globals  : TTone_Context
*
* If test tone is enabled, this routine replaces any audio in the packet with a
* test tone per the user parameters.  This supports AddATone's in==out pointer
* mode.
*******************************************************************************/
static void AddTTone(int16_t* in,int16_t* out)
{
   AddATone16s(in,out,&TTone_Context ) ;
   ProbeCheck(out,PROBE_TXTONE,PROBE_AUDIO) ;
}

/*******************************************************************************
* Routine  : AddATone16s, AddATone12u
* Gazintas : in - Packet source (16-bit samples, signed or unsigned based on routine)
* IOs      : out - Packet destination (16-bit samples, signed or unsigned based on routine)
*          : context - Tone generator context
* Returns  : Nothing
* Globals  : None (importantly)
*
* This routine adds a tone to an audio packet. This tone can be merged with or
* fully replace the incoming audio.  This tone generator is needed in several
* places and must preserve its state for each context to ensure a clean tone.
* The context structure contains that state.  The parameters are:
*  - freq:  Frequency of the tone in 1/100ths of a Hz. (1Hz to 4000Hz)
*  - level: Amplitude in % of full scale (0-100)
*  - mix:   Mix mode, TONE_BYPASS,TONE_REPLACE, TONE_ADD, or TONE_MIX
*           TONE_BYPASS: don't add a tone, just copy audio in to out
*           TONE_REPLACE: incoming audio is discarded, only tone out
*           TONE_ADD: add the tone to the audio, do not attenuate audio
*           TONE_MIX: proportionally attenuate the audio by the mix amplitude
*  - phase: Maintained by AddATone between packets to keep a continuous phase
*
* AddATone16s deals with 16-bit signed audio samples with 0V at 0.
* AddATone12u deals with 12-bit unsigned audio samples with 0V at 2048 (mid point)
*             Note that the math gets a bit weird as we attenuate around the
*             mid point of 2048 to keep 0V there.
*
* NOTE1: This routine supports the in and out pointers being the same!
*        If tones enabled, new values get safely written back to the same
*        buffer, but more importantly, if tones are disabled, I don't do the
*        memcpy from in to out, saving CPU cycles.
*
* NOTE2: With TONE_ADD it is possible to get overflows since it is a pure
*        addition of two signals that could be more than half full scale!
*        TONE_MIX avoids this my scaling audio down by the amplitude of the
*        tone so overflows are not possible.  Mix responsibly!
*******************************************************************************/
extern void AddATone16s(int16_t* in,int16_t* out,TONE_CONTEXT* context)
{
   int     degonly = 0 ; /* Phase in unit degrees only         */
   int16_t tone    = 0 ; /* Tone voltage level                 */
   int     i       = 0 ; /* General counter                    */
   int32_t tmp     = 0 ; /* 32-bit temp value (no overflows!)  */

   /* For what is likely the 99% case of no tone being added, just copy in to */
   /* out and exit, but only if the in and out pointers are different!.       */
   if (TONE_BYPASS==context->mix)
   {
      if (in != out) memcpy(out,in,APKT_SAMPLES*2) ;
   }
   else
   {
      /* For all other options we need a tone! Time to loop through all the   */
      /* samples in the audio packet                                          */
      for (i=0;i<APKT_SAMPLES;i++)
      {
         /* Increment the test tone phase based on the selected frequency and */
         /* handle wrap-around (360 degrees in 100ths of a degree)            */
         /* NOTE: freq*45 is simplified freq/8000*360000 to avoid overflows   */
         context->phase = (context->phase + (context->freq*45)/1000)%36000 ;

         /* Get just integer degrees and then do the four quadrants of the    */
         /* sine wave table.                                                  */
         degonly = context->phase/100 ;
                 if (degonly< 90) tone =  sinetable_16s[degonly    ] ;
            else if (degonly<180) tone =  sinetable_16s[180-degonly] ;
            else if (degonly<270) tone = -sinetable_16s[degonly-180] ;
            else                  tone = -sinetable_16s[360-degonly] ;

         /* Now mix the tone with the audio based on the mix mode.            */
         /* This needs to be 32-bit math for the mixing, then scaled back     */
         /* down to 16-bits for the output.                                   */
         switch(context->mix)
         {
            case TONE_REPLACE : tmp = tone*context->level                                   ; break ;
            case TONE_ADD     : tmp = tone*context->level + in[i]*100                       ; break ;
            case TONE_MIX     : tmp = tone*context->level + in[i]*(100-tone*context->level) ; break ;
            default           : tmp = 0 /* Not used, TONE_BYPASS handled above */           ; break ;
         }
         out[i] = tmp/100 ;
      }
   }
}

extern void AddATone12u(uint16_t* in,uint16_t* out,TONE_CONTEXT* context)
{
   int     degonly = 0 ; /* Phase in unit degrees only         */
   int16_t tone    = 0 ; /* Tone voltage level                 */
   int     i       = 0 ; /* General counter                    */
   int32_t tmp     = 0 ; /* 32-bit temp value (no overflows!)  */

   /* For what is likely the 99% case of no tone being added, just copy in to */
   /* out and exit, but only if the in and out pointers are different!.       */
   if (TONE_BYPASS==context->mix)
   {
      if (in != out) memcpy(out,in,APKT_SAMPLES*2) ;
   }
   else
   {
      /* For all other options we need a tone! Time to loop through all the   */
      /* samples in the audio packet                                          */
      for (i=0;i<APKT_SAMPLES;i++)
      {
         /* Increment the test tone phase based on the selected frequency and */
         /* handle wrap-around (360 degrees in 100ths of a degree)            */
         /* NOTE: freq*45 is simplified freq/8000*360000 to avoid overflows   */
         context->phase = (context->phase + (context->freq*45)/1000)%36000 ;

         /* Get just integer degrees and then do the four quadrants of the    */
         /* sine wave table.                                                  */
         /* For here, keeping it signed so attenuation math works.            */
         degonly = context->phase/100 ;
                  if (degonly< 90) tone =  sinetable_12u[degonly    ] ;
             else if (degonly<180) tone =  sinetable_12u[180-degonly] ;
             else if (degonly<270) tone = -sinetable_12u[degonly-180] ;
             else                  tone = -sinetable_12u[360-degonly] ;

         /* For attenuation math, make 0V 0.                                  */
         tmp = in[i]-2048 ;

         /* Now mix the tone with the audio based on the mix mode.            */
         /* This needs to be 32-bit math for the mixing, then scaled back     */
         /* down to 12-bits for the output.                                   */
         switch(context->mix)
         {
            case TONE_REPLACE : tmp = tone*context->level                                   ; break ;
            case TONE_ADD     : tmp = tone*context->level + in[1]*100                       ; break ;
            case TONE_MIX     : tmp = tone*context->level + in[1]*(100-tone*context->level) ; break ;
            default           : tmp = 0 /* Not used, TONE_BYPASS handled above */           ; break ;
         }
         out[i] = (tmp/100)+2048 ;
      }
   }
}

/*******************************************************************************
* Routine  : ProbeCheck
* Gazintas : src - Packet source (16-bit samples)
*          : channel - the Probe channel being offered
*          : format - the data format, either signed audio or raw DAC samples
* IOs      : None
* Returns  : Nothing
* Globals  : AnalogProbe, ProbeBuf
*
* This routine gets called after each stage of the Rx and Tx DSP routines to
* see if the data should be sent to the debug DAC.  If the current Probe
* setting matches the source data, then the data is copied to the ProbeBuf
* buffer to be sent to the DAC.  There are two data types, signed audio or
* unsigned Raw DAC data.
*******************************************************************************/
void ProbeCheck(void* src,int8_t channel,int format)
{
   int      i    = 0   ; /* loop counter   */
   int16_t* isrc = src ; /* Correctly cast */

   if (AnalogProbe==channel)
   {
      if (PROBE_RAW==format)
      {
         memcpy(ProbeBuf,src,APKT_SAMPLES*2) ;
      }
      else /* it is signed audio data */
      {
         for (i=0;i<APKT_SAMPLES;i++)
         {
            ProbeBuf[i] = (uint16_t)((isrc[i]>>4)+2048) ;
         }
      }
   }
}

/*******************************************************************************
* Routine  : HandleDebugData
* Gazintas : Target - The target output buffer (ping or pong)
* IOs      : None
* Returns  : Nothing
* Globals  : AnalogProbe, ProbeBuf
*
* This routine copies the debug data (if any) to the right area of the ping or
* pong buffer to be sent out the debug DAC.  If nothing is being probed, it
* makes sure the debug data is cleared.  There is a boundary case where if I
* change from another probe to a Tx.. probe and we are not transmitting that
* stale data is left in ProbeBuf.  I handle that below by simply clearing
* ProbeBuf on any change in the Probe value.
*******************************************************************************/
static void HandleDebugData(uint16_t* Target)
{
   static uint8_t LastProbe = PROBE_NONE ; /* Last probe value */
   int            i         = 0          ; /* loop counter     */

   if (AnalogProbe != LastProbe)
   {
      for (i=0;i<APKT_SAMPLES;i++)
      {
         ProbeBuf[i] = ADAC_0V ;
      }
   }

   if (PROBE_NONE==AnalogProbe)
   {
      Tx_ClearPacket(Target,DEBUGBUF) ;
   }
   else
   {
      for (i=0;i<APKT_SAMPLES;i++)
      {
         Target[(i*2)+1] = ProbeBuf[i] ;
      }
   }
   LastProbe = AnalogProbe ;
}
