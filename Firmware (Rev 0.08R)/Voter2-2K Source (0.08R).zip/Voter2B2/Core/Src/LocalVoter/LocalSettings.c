/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/* ************************************************************************** */
/* This is the LocalSettings file, in charge of the settings for local mode.  */
/* The settings for local mode are separated from the main set/show/settings  */
/* code as there can be different local modes and each will have different    */
/* settings structures.  These are the settings for the "default" Voter2      */
/* mode unless replaced by something else.                                    */
/* This contains the segregated code that would be the equivalent of what is  */
/* in the set/show commands and settings commands.                            */
/******************************************************************************/
/* Public routines are:                                                       */
/*  - LocalSettingsInit - Set factory defaults.                               */
/*  - LocalSettingsRead - process and NVM TLV read                            */
/*  - LocalSettingsWrite - Write settings to NVM                              */
/*  - SetLocal - CLI Change local mode settings                               */
/*  - ShowLocal - CLI Display local mode settings                             */
/*  - Backup_Local - For TFTP backup of local settings                        */
/*                                                                            */
/******************************************************************************/
// To Do:
//  -

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>

#include "Options.h"
#ifdef LOCALVOTER

#include "Utils.h"
#include "ConsoleTask.h"
#include "Settings.h"
#include "LocalVoter/LocalSettings.h"
#include "Setshow.h"
#include "AnalogIO.h"
#include "Rx_DSP.h"
#include "Tx_DSP.h"
#include "Backup.h"

/******************************************************************************/
/* Local defines (including enums)                                            */
/******************************************************************************/
#define MAX_SET_LINE 50

enum
{
   LOC_MODE = 1,
   LOC_CWSPEED,
   LOC_PLFREQ,
   LOC_DEEMPH,
   LOC_PRECW,
   LOC_POSTCW,
   LOC_IDTIME,
   LOC_HANGTIME,
   LOC_TXDLY,
   LOC_PLL,
   LOC_ID,
   LOC_PROC,
} LOCALBLOCK_ENUMS ;

enum
{
   TLVT_LOCMODE = 1,
   TLVT_LOCCWS = 2,
   TLVT_LOCPLF = 3,
   TLVT_LOCDEEMPH = 4,
   TLVT_LOCPRECW = 5,
   TLVT_LOCPOSTCW = 6,
   TLVT_LOCIDTIME = 7,
   TLVT_LOCHANGTIME = 8,
   TLVT_LOCPLL = 9,
   TLVT_LOCID = 10,
   TLVT_LOCPROC = 11,
   TLVT_LOCTXDLY = 12,
} OFFLINE_TLVTS ;

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
LOCALSETTINGS LocalSettings = {0} ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST LocalCliCmds[] =
{
   {"mode"    ,"mod",LOC_MODE    },
   {"cwspd"   ,"cws",LOC_CWSPEED },
   {"plfreq"  ,"plf",LOC_PLFREQ  },
   {"deemph"  ,"dmp",LOC_DEEMPH  },
   {"precw"   ,"prc",LOC_PRECW   },
   {"postcw"  ,"poc",LOC_POSTCW  },
   {"idtime"  ,"idl",LOC_IDTIME  },
   {"hangtime","htm",LOC_HANGTIME},
   {"txdly"   ,"txd",LOC_TXDLY   },
   {"pllevel" ,"pll",LOC_PLL     },
   {"id"      ,"id" ,LOC_ID      },
   {"proc"    ,"prc",LOC_PROC    },
   {NULL      ,NULL, 0           }
} ;

static TOKENLIST OfflineModes[] =
{
   {"none"    ,"non",OFF_NONE    },
   {"simplex" ,"smp",OFF_SIM     },
   {"trigger" ,"trg",OFF_TRIGGER },
   {"repeater","rpt",OFF_REPEATER},
   {NULL      ,0           }
};

static TOKENLIST PLTones[] =
{
   {"67.0" ,NULL,CTCSS_670},
   {"71.9" ,NULL,CTCSS_719},
   {"74.4" ,NULL,CTCSS_744},
   {"77.0" ,NULL,CTCSS_770},
   {"79.7" ,NULL,CTCSS_797},
   {"82.5" ,NULL,CTCSS_825},
   {"85.4" ,NULL,CTCSS_854},
   {"88.5" ,NULL,CTCSS_885},
   {"91.5" ,NULL,CTCSS_915},
   {"94.8" ,NULL,CTCSS_948},
   {"97.4" ,NULL,CTCSS_974},
   {"100.0",NULL,CTCSS_1000},
   {"103.5",NULL,CTCSS_1035},
   {"107.2",NULL,CTCSS_1072},
   {"110.9",NULL,CTCSS_1109},
   {"114.8",NULL,CTCSS_1148},
   {"118.8",NULL,CTCSS_1188},
   {"123.0",NULL,CTCSS_1230},
   {"127.3",NULL,CTCSS_1273},
   {"131.8",NULL,CTCSS_1318},
   {"136.5",NULL,CTCSS_1365},
   {"141.3",NULL,CTCSS_1413},
   {"146.2",NULL,CTCSS_1462},
   {"151.4",NULL,CTCSS_1514},
   {"156.7",NULL,CTCSS_1567},
   {"162.2",NULL,CTCSS_1622},
   {"167.9",NULL,CTCSS_1679},
   {"173.8",NULL,CTCSS_1738},
   {"179.9",NULL,CTCSS_1799},
   {"186.2",NULL,CTCSS_1862},
   {"192.8",NULL,CTCSS_1928},
   {"203.5",NULL,CTCSS_2035},
   {"210.7",NULL,CTCSS_2107},
   {"218.1",NULL,CTCSS_2181},
   {"225.7",NULL,CTCSS_2257},
   {"233.6",NULL,CTCSS_2336},
   {"241.8",NULL,CTCSS_2418},
   {"250.3",NULL,CTCSS_2503},
   {NULL   ,NULL,0         }
} ;

/* WARNING! If you mess with LOCALBLOCK_ENUMS, keep this in sync with it!! */
static char* LocalHelpTopics[] =
   {/* NOT_USED    */ "N/A", /* Index of 0 not used */
    /* LOC_MODE    */ "local mode [none|simplex|trigger|repeater] - Sets the repeater mode when in\n"
                      "   local mode.  Local modes are:\n"
                      " - none - disabled. If not connected to a DIAL server, the Voter2 is silent\n"
                      " - simplex - Only sends disconnect ID and CW ID tones\n"
                      " - trigger - Only sends disconnect ID tone\n"
                      " - repeater - Becomes a local repeater\n",
    /* LOC_CWSPEED */ "local cwspd [speed] The local IDer CW speed in WPM (5-50)\n",
    /* LOC_PLFREQ  */ "local plfreq [freq] - The local PL (CTCSS) frequency. To disable the tone,\n"
                      "   set the PL level (pllevel) to 0.  Valid frequencis are:\n"
                      "   67.0 71.9 74.4 77.0 79.7 82.5 85.4 88.5 91.5 94.8 97.4 100.0 103.5 107.2\n"
                      "   110.9 114.8 118.8 123.0 127.3 131.8 136.5 141.3 146.2 151.4 156.7 162.2\n"
                      "   167.9 173.8 179.9 186.2 192.8 203.5 210.7 218.1 225.7 233.6 241.8 250.3\n",
    /* LOC_DEEMPH  */ "local deemph [on|off] - Sets De-emphasis for local mode\n",
    /* LOC_PRECW   */ "local precw [ms] - Delay from audio to CW tones (100-500ms)\n",
    /* LOC_POSTCW  */ "local postcw [ms] - Delay between proceed ID and Station ID (100-5000 ms)\n",
    /* LOC_IDTIME  */ "local idtime [sec] - Time between CW IDs (60-600sec)\n",
    /* LOC_HANGTIME*/ "local hangtime [ms] - Delay from last audio to PTT de-assertion (100-5000ms)\n",
    /* LOC_TXDLY   */ "local txdly [ms] - Audio in-out delay. (60-800ms)\n",
    /* LOC_PLL     */ "local pllevel [%] - PL tone level (0-30 (percent full scale))\n",
    /* LOC_ID      */ "local id [callsign] - The station ID (callsign)\n",
    /* LOC_PROC    */ "local proc [text] - Proceed ID (at the end of each transmission)\n"
   };

/******************************************************************************/
/* External globals. CubeMX has you define them as externs in each file       */
/* instead of an include file, weird.                                         */
/******************************************************************************/

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/
static void SyncSettings(void) ;
static void CheckCWids(void) ;

/*******************************************************************************
* Routine  : LocalSettingsInit
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : LocalSettings
*
* This routine fills in the LocalSettings structure with the factory default
* settings.  If LOCALVOTER is defined (enabling the default local mode), then
* SettingsInit calls this routine on power-up if NVM is corrupted.
*******************************************************************************/
void LocalSettingsInit(void)
{
   LocalSettings.OfflineMode    = OFF_REPEATER ; /* Repeater mode        */
   LocalSettings.OffinePLF      = CTCSS_885    ; /* Offline CTCSS Freq   */

   LocalSettings.OffineCwSpd    =   20 ; /* Offline CW speed (WPM)       */
   LocalSettings.OffineDeemph   = true ; /* Offline Rx De-emphasis (TF)  */
   LocalSettings.OffinePreCw    =  500 ; /* Offline Pre CW delay (ms)    */
   LocalSettings.OffinePostCw   =  500 ; /* Offline Post CW delay (ms)   */
   LocalSettings.OffineTxDly    =  100 ; /* Offline Tx Delay buffer (ms) */
   LocalSettings.OffineIdTime   =  600 ; /* Offline ID period (secs)     */
   LocalSettings.OffineHangTime = 1500 ; /* Offline Rx Hang time (ms)    */
   LocalSettings.OffinePLL      =    3 ; /* Offline CTCSS level (int)    */

   strcpy(LocalSettings.OfflineID  ,"N0CALL/R") ; /* Offline station ID  */
   strcpy(LocalSettings.OfflineProc,"L"       ) ; /* Offline Proceed ID  */

   /* Finally, sync up the global versions of some local settings */
   SyncSettings() ;
} ;

/*******************************************************************************
* Routine  : LocalSettingsRead
* Gazintas : tag - The TLV T (tag) value
*          : buf - the TLV V data  (note L is implied by this point)
* IOs      : None
* Returns  : Nothing
* Globals  : LocalSettings
*
* This routine processes Local Mode settings being read from NVM.  As entries
* are read, the main code looks at the group setting and if for local mode,
* calls this routine to process it.
*******************************************************************************/
void LocalSettingsRead(uint8_t tag,uint8_t* buf)
{
   switch (tag)
   {
      case TLVT_LOCMODE    : memcpy(&LocalSettings.OfflineMode     ,buf,1) ; break ;
      case TLVT_LOCCWS     : memcpy(&LocalSettings.OffineCwSpd     ,buf,1) ; break ;
      case TLVT_LOCPLF     : memcpy(&LocalSettings.OffinePLF       ,buf,1) ; break ;
      case TLVT_LOCDEEMPH  : memcpy(&LocalSettings.OffineDeemph    ,buf,1) ; break ;
      case TLVT_LOCPRECW   : memcpy(&LocalSettings.OffinePreCw     ,buf,2) ; break ;
      case TLVT_LOCPOSTCW  : memcpy(&LocalSettings.OffinePostCw    ,buf,2) ; break ;
      case TLVT_LOCIDTIME  : memcpy(&LocalSettings.OffineIdTime    ,buf,2) ; break ;
      case TLVT_LOCHANGTIME: memcpy(&LocalSettings.OffineHangTime  ,buf,2) ; break ;
      case TLVT_LOCTXDLY   : memcpy(&LocalSettings.OffineTxDly     ,buf,2) ; break ;
      case TLVT_LOCPLL     : memcpy(&LocalSettings.OffinePLL       ,buf,1) ; break ;
      case TLVT_LOCID      : memcpy(&LocalSettings.OfflineID       ,buf,SETTINGS_CWID_LEN) ; break ;
      case TLVT_LOCPROC    : memcpy(&LocalSettings.OfflineProc     ,buf,SETTINGS_CWID_LEN) ; break ;
      default              :                                                 break ;
   }

   /* Finally, sync up the global versions of some local settings.  Yea, this */
   /* seems a bit inefficient to resync all settings after every single       */
   /* settings read, but reality is the sync time is rounding error compared  */
   /* to the NVM read, so not too worried about it.                           */
   SyncSettings() ;
}

/*******************************************************************************
* Routine  : LocalSettingsWrite
* Gazintas : None
* IOs      : memaddr
* Returns  : Nothing
* Globals  : LocalSettings
*
* This routine gets called by the 'settings save' command to save all the local
* settings if local mode is enabled.  memaddr is the I2C write address that
* gets incremented after each write based on the bytes in the TLV entry.
*******************************************************************************/
void LocalSettingsWrite(uint32_t* memaddr)
{
   write_tlv_i1 (memaddr,TGRP_LOCAL,TLVT_LOCMODE    ,&LocalSettings.OfflineMode     ) ;
   write_tlv_i1 (memaddr,TGRP_LOCAL,TLVT_LOCCWS     ,&LocalSettings.OffineCwSpd     ) ;
   write_tlv_i1 (memaddr,TGRP_LOCAL,TLVT_LOCPLF     ,&LocalSettings.OffinePLF       ) ;
   write_tlv_i1 (memaddr,TGRP_LOCAL,TLVT_LOCPLL     ,&LocalSettings.OffinePLL       ) ;
   write_tlv_i1 (memaddr,TGRP_LOCAL,TLVT_LOCDEEMPH  ,&LocalSettings.OffineDeemph    ) ;
   write_tlv_i2 (memaddr,TGRP_LOCAL,TLVT_LOCPRECW   ,&LocalSettings.OffinePreCw     ) ;
   write_tlv_i2 (memaddr,TGRP_LOCAL,TLVT_LOCPOSTCW  ,&LocalSettings.OffinePostCw    ) ;
   write_tlv_i2 (memaddr,TGRP_LOCAL,TLVT_LOCIDTIME  ,&LocalSettings.OffineIdTime    ) ;
   write_tlv_i2 (memaddr,TGRP_LOCAL,TLVT_LOCHANGTIME,&LocalSettings.OffineHangTime  ) ;
   write_tlv_i2 (memaddr,TGRP_LOCAL,TLVT_LOCTXDLY   ,&LocalSettings.OffineTxDly     ) ;
   write_tlv_str(memaddr,TGRP_LOCAL,TLVT_LOCID      ,&LocalSettings.OfflineID       ,SETTINGS_CWID_LEN) ;
   write_tlv_str(memaddr,TGRP_LOCAL,TLVT_LOCPROC    ,&LocalSettings.OfflineProc     ,SETTINGS_CWID_LEN) ;
}

/*******************************************************************************
* Routine  : SetLocal
* Gazintas : argc - argument count for the whole line including "set local"
*          : argv - arguments (argv[0]="set", argv[1] = "local")
* IOs      : None
* Returns  : Nothing
* Globals  : Settings
*
* This is the CLI support routine for local mode settings.  If the CLI code
* gets 'set local' it just defers to this routine for any subsequent parsing.
* It only does that is LOCALVOTER is defined just as any of this code only gets
* compiled if LOCALVOTER is defined.
*******************************************************************************/
void SetLocal (int argc,char** argv)
{
   int     error = false ; /* Parsing error flag */
   int     Token = 0     ; /* Command token      */
   int32_t tmp   = 0     ; /* Temporary value    */

   /* Argument count should be exactly four */
   if (4!=argc) error = true ;

   /* See which setting command */
   stolower(argv[2]) ; /* To lower case first */
   if (!error) Token = parse_token(LocalCliCmds,argv[2],&error) ;

   if (error)
   {
      Console_printf("Not a recognized local setting, enter 'show local' for list.\n") ;
   }
   else
   {
      switch(Token)
      {
         case LOC_MODE     : SetList ("Voter2 Local Mode:"                 ,argv[3],                 &LocalSettings.OfflineMode,OfflineModes,true) ; break ;
         case LOC_CWSPEED  : SetNum  ("Voter2 Local CW Speed (wpm):"       ,argv[3],  5,  50,&tmp) ;  LocalSettings.OffineCwSpd = tmp              ; break ;
         case LOC_PLFREQ   : SetList ("Voter2 Local CTCSS Freq (hz):"      ,argv[3],                 &LocalSettings.OffinePLF,PLTones,true)        ; break ;
         case LOC_DEEMPH   : SetOnOff("Voter2 Local De-Emphasis:"          ,argv[3],                 &LocalSettings.OffineDeemph)                  ; break ;
         case LOC_PRECW    : SetNum  ("Voter2 Local Pre-CW delay (ms):"    ,argv[3],100,5000,&tmp) ;  LocalSettings.OffinePreCw = tmp              ; break ;
         case LOC_POSTCW   : SetNum  ("Voter2 Local Post-CW delay (ms):"   ,argv[3],100,5000,&tmp) ;  LocalSettings.OffinePostCw = tmp             ; break ;
         case LOC_IDTIME   : SetNum  ("Voter2 Local ID spacing (sec):"     ,argv[3], 60, 600,&tmp) ;  LocalSettings.OffineIdTime = tmp             ; break ;
         case LOC_HANGTIME : SetNum  ("Voter2 Local hang time (ms):"       ,argv[3],100,5000,&tmp) ;  LocalSettings.OffineHangTime = tmp           ; break ;
         case LOC_TXDLY    : SetNum  ("Voter2 Local Tx Delay (ms):"        ,argv[3], 65, 800,&tmp) ;  LocalSettings.OffineTxDly = tmp              ; break ;
         case LOC_PLL      : SetNum  ("Voter2 Local PL tone volume (0-10):",argv[3],  0,  30,&tmp) ;  LocalSettings.OffinePLL = tmp                ; break ;
         case LOC_ID       : SetStr  ("Voter2 Local CW ID:"                ,argv[3],                  LocalSettings.OfflineID,SETTINGS_CWID_LEN)   ; break ;
         case LOC_PROC     : SetStr  ("Voter2 Local Proceed ID:"           ,argv[3],                  LocalSettings.OfflineProc,SETTINGS_CWID_LEN) ; break ;
         default           : /* Unsupported tokens */                                                                                                break ;
      }
      /* Check the CW ID strings to be sure they are valid */
      CheckCWids() ;

      /* Finally, sync up the global versions of some local settings */
      SyncSettings() ;
   }
}

/*******************************************************************************
* Routine  : ShowLocal
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : Settings
*
* This is the CLI support routine for displaying mode settings.  If the CLI code
* gets 'show local' it just defers to this routine for any subsequent parsing.
* Since there are relatively few local mode settings, there are no parameters,
* I just display them all.
* The main CLI code only does this if LOCALVOTER is defined just as any of this
* code only gets compiled if LOCALVOTER is defined.
*******************************************************************************/
void ShowLocal (void)
{
   /* For showing local settings, just show them all */
   Console_printf("              Local Mode - %8s (%3s): %s\n",LocalCliCmds[ 0].token,LocalCliCmds[ 0].shortcut,OfflineModes[LocalSettings.OfflineMode].token ) ;
   Console_printf(" Local ID CW Speed (wpm) - %8s (%3s): %d\n",LocalCliCmds[ 1].token,LocalCliCmds[ 1].shortcut,             LocalSettings.OffineCwSpd        ) ;
   Console_printf("        Local CTCSS Freq - %8s (%3s): %s\n",LocalCliCmds[ 2].token,LocalCliCmds[ 2].shortcut,PLTones     [LocalSettings.OffinePLF].token   ) ;
   Console_printf("       Local De-Emphasis - %8s (%3s): %s\n",LocalCliCmds[ 3].token,LocalCliCmds[ 3].shortcut,Booleans    [LocalSettings.OffineDeemph].token) ;
   Console_printf(" Local Pre-CW delay (ms) - %8s (%3s): %d\n",LocalCliCmds[ 4].token,LocalCliCmds[ 4].shortcut,             LocalSettings.OffinePreCw        ) ;
   Console_printf("Local Post-CW delay (ms) - %8s (%3s): %d\n",LocalCliCmds[ 5].token,LocalCliCmds[ 5].shortcut,             LocalSettings.OffinePostCw       ) ;
   Console_printf(" Local ID Interval (sec) - %8s (%3s): %d\n",LocalCliCmds[ 6].token,LocalCliCmds[ 6].shortcut,             LocalSettings.OffineIdTime       ) ;
   Console_printf("    Local Hang Time (ms) - %8s (%3s): %d\n",LocalCliCmds[ 7].token,LocalCliCmds[ 7].shortcut,             LocalSettings.OffineHangTime     ) ;
   Console_printf("     Local Tx Delay (ms) - %8s (%3s): %d\n",LocalCliCmds[ 8].token,LocalCliCmds[ 8].shortcut,             LocalSettings.OffineTxDly        ) ;
   Console_printf("Local CTCSS level (0-10) - %8s (%3s): %d\n",LocalCliCmds[ 9].token,LocalCliCmds[ 9].shortcut,             LocalSettings.OffinePLL          ) ;
   Console_printf("       Local callsign ID - %8s (%3s): %s\n",LocalCliCmds[10].token,LocalCliCmds[10].shortcut,             LocalSettings.OfflineID          ) ;
   Console_printf("        Local Proceed ID - %8s (%3s): %s\n",LocalCliCmds[11].token,LocalCliCmds[11].shortcut,             LocalSettings.OfflineProc        ) ;
   CheckCWids() ;
}

/*******************************************************************************
* Routine  : SyncSettings
* Gazintas : None
* IOs      : None
* Returns  : Nothing
* Globals  : Settings
*
* This syncs up the necessary global settings after any update to the local
* settings.  Because there can be different local mode implementations, each
* with their own settings structures, the common code needs some shared global
* settings to react to no matter which local implementation is being used.
* These are those common settings.
*******************************************************************************/
static void SyncSettings(void)
{
   LocalDeemph       = LocalSettings.OffineDeemph ;
   Local_CTCSS_Lvl   = LocalSettings.OffinePLL ;
   Local_CTCSS_Freq  = LocalSettings.OffinePLF ;

   /* For txdly there is an inherent processing delay that needs subtracting  */
   /* (45ms), then it needs converting to ns.                                 */
   GlobLocTxBufDly = (LocalSettings.OffineTxDly-45)*1000000 ;
}

/*******************************************************************************
* Routine  : CheckCWids
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : LocalSettings.OfflineID, LocalSettings.OfflineProc
*
* This routine checks the above two settings to make sure they are decent for
* sending out as Morse Code.  That is, upper case A-Z, 0-9, and /.  I support
* some other characters too, but warn the user if they are getting into iffy
* characters.
*******************************************************************************/
void CheckCWids(void)
{
   int i = 0 ;
   int uhoh = false ;

   while ((i<SETTINGS_CWID_LEN) && (LocalSettings.OfflineID[i]))
   {
      /* Yea, this is some pretty crazy logic that needed some formatted      */
      /* parsing to get it right.  Weird part is I got it right on the first  */
      /* try!                                                                 */
      if (!(
             ((LocalSettings.OfflineID[i]>='0') && (LocalSettings.OfflineID[i]<='9')) ||
             ((LocalSettings.OfflineID[i]>='A') && (LocalSettings.OfflineID[i]<='Z')) ||
              (LocalSettings.OfflineID[i]=='/')
        ))
      {
        uhoh = true ;
      }
      i++ ;
   }

   i = 0 ;
   while ((i<SETTINGS_CWID_LEN) && (LocalSettings.OfflineProc[i]))
   {
      if (!(
             ((LocalSettings.OfflineProc[i]>='0') && (LocalSettings.OfflineProc[i]<='9')) ||
             ((LocalSettings.OfflineProc[i]>='A') && (LocalSettings.OfflineProc[i]<='Z')) ||
              (LocalSettings.OfflineProc[i]=='/')
        ))
      {
        uhoh = true ;
      }
      i++ ;
   }

   if (uhoh)
   {
      Console_printf("\nWARNING: The Repeater callsign or proceed ID has characters\n"
                  "outside upper case A-Z, 0-9, or /.\n"
                  "This may have unpredictable results.\n\n") ;
   }
}

/*******************************************************************************
* Routine  : LocalSettingsHelp
*   Inputs : cmd - setting to get help on
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This routine displays the help text for the supplied local setting parameter
* (assuming it is valid, an error message is displayed if not.
*******************************************************************************/
void LocalSettingsHelp(char* cmd)
{
   int token = 0     ; /* Parsed token              */
   int error = false ; /* Parsing error flag        */

   /* See if we got a match */
   token = parse_token(LocalCliCmds,cmd,&error) ;

   if (!error)
   {
      Console_puts(LocalHelpTopics[token]) ;
   }
   else
   {
      /* If no match, try to be helpful */
      Console_printf("Local setting command not found.  Type 'help show local' for a full list.\n") ;
   }
}

/*******************************************************************************
* Routine  : Backup_Local
*   Inputs : first - first call flag
*      IOs : setting - setting string
*  Returns : setting string length, 0 for all done.
*  Globals : LocalSettings
*
* This routine gets called repeatedly by Settings_Backup() to return local
* settings to be backed up.  It is called first with the first flag set (!),
* then called repeatedly until a parameter string length of 0 is returned,
* meaning all local settings have been returned for backing up.
*******************************************************************************/
int Backup_Local(char* Setting, int first)
{
   static int param = 0 ; /* parameter counter */

   int  paramlen =  0  ; /* Parameter string length */

   /* If first call, reset parameter index to 0 */
   if (first) param = 0 ;

   switch (param)
   {
      case  0 : paramlen=Backup_list(Setting,"local mode",    LocalSettings.OfflineMode,OfflineModes) ; break ;
      case  1 : paramlen=Backup_int (Setting,"local cwspd",   LocalSettings.OffineCwSpd             ) ; break ;
      case  2 : paramlen=Backup_list(Setting,"local plfreq",  LocalSettings.OffinePLF,PLTones       ) ; break ;
      case  3 : paramlen=Backup_list(Setting,"local deemph",  LocalSettings.OffineDeemph,Booleans   ) ; break ;
      case  4 : paramlen=Backup_int (Setting,"local precw",   LocalSettings.OffinePreCw             ) ; break ;
      case  5 : paramlen=Backup_int (Setting,"local postcw",  LocalSettings.OffinePostCw            ) ; break ;
      case  6 : paramlen=Backup_int (Setting,"local idtime",  LocalSettings.OffineIdTime            ) ; break ;
      case  7 : paramlen=Backup_int (Setting,"local hangtime",LocalSettings.OffineHangTime          ) ; break ;
      case  8 : paramlen=Backup_int (Setting,"local txdly",   LocalSettings.OffineTxDly             ) ; break ;
      case  9 : paramlen=Backup_int (Setting,"local pllevel", LocalSettings.OffinePLL               ) ; break ;
      case 10 : paramlen=Backup_str (Setting,"local id",      LocalSettings.OfflineID               ) ; break ;
      case 11 : paramlen=Backup_str (Setting,"local proc",    LocalSettings.OfflineProc             ) ; break ;
      default : paramlen=0                                                                            ; break ;
   }

   param++ ;
   return(paramlen) ;
}

#endif /* #ifdef LOCALVOTER */
