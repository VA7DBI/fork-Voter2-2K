/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Status file.  It is in charge of the CLI status command.       */
/* I have a feeling some other background monitoring tasks may get added later*/
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_status - Status CLI command                                         */
/*                                                                            */
/******************************************************************************/
// TO DO:
//
/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"
#include "netif/ethernet.h"
#include "task.h"

#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "AnalogIO.h"
#include "Gpio.h"
#include "GPS.h"
#include "Timers.h"
#include "Rx_DSP.h"
#include "DialTaskOut.h"
#include "DialTaskIn.h"
#include "LocalMode.h"
#include "Settings.h"
#include "EthernetTask.h"
#include "KSZ8081.h"
#include "I2C.h"
#include "Vcxo.h"
#include "Utils.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern ADC_HandleTypeDef hadc3;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
enum
{
   CMD_OOPS = 0,
   CMD_14V,
   CMD_DIAL,
   CMD_GPS,
   CMD_POWER,
   CMD_RSSI,
   CMD_ALEVEL,
   CMD_SYNC,
   CMD_TEMPR,
   CMD_UPTIME,
   CMD_ETHERNET,
   CMD_RTOS,
   CMD_RXFFT,
   CMD_10MHZ
} STATUS_ENUMS ;

#define TEMPR_ADDRESS0 0x90 /* Shifted Address for on-board sensor  */
#define TEMPR_ADDRESS1 0x92 /* Shifted Address for off-board sensor */
#define TEMPR_ADDRESS2 0x94 /* Shifted Address for off-board sensor */
#define TEMP_CONV_MS     10 /* Max ms for temperature conversion    */

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_status_cmd   = "status" ;
char* cmd_status_cmdsc = "sta" ;
char* cmd_status_help  = "status - [10mhz|14v|dial|ethernet|gps|power|rssi|rtos|rxfft|sync|tempr|uptime]\n"
                         "Show Voter2 status info\n"
                         "         10mhz (10m) - 10MHz clock frequency (vs GPS 1PPS)\n"
                         "         14v - check 14V supply\n"
                         "         dial - check DIAL connection status\n"
                         "         ethernet (eth) - Ethernet port status\n"
                         "         gps - check GPS status\n"
                         "         power (pwr) - check repeater AC power\n"
                         "         level (lvl) - Check analog input level\n"
                         "         rssi (rsi) - display 'live' RSSI value\n"
                         "         rtos - RTOS task CPU utilization\n"
                         "         rxfft (fft) - FFT of Rx signal (debug only)\n"
                         "         sync (syn) - check GPS vs DIAL sync\n"
                         "         tempr (tpr) - check MCU/PCB temperature\n"
                         "         uptime (upt) - time since last boot\n" ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST StatCmds[] =
{
   {"14v"     ,NULL,CMD_14V       },
   {"dial"    ,NULL,CMD_DIAL      },
   {"gps"     ,NULL,CMD_GPS       },
   {"power"   ,"pwr",CMD_POWER    },
   {"rssi"    ,"rsi",CMD_RSSI     },
   {"level"   ,"lvl",CMD_ALEVEL   },
   {"sync"    ,"syn",CMD_SYNC     },
   {"rtos"    ,NULL ,CMD_RTOS     },
   {"rxfft"   ,"fft",CMD_RXFFT    },
   {"tempr"   ,"tpr",CMD_TEMPR    },
   {"uptime"  ,"upt",CMD_UPTIME   },
   {"ethernet","eth",CMD_ETHERNET },
   {"10mhz"   ,"10m",CMD_10MHZ    },
   {NULL      ,NULL ,0            }
} ;

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void RssiBar(int,char*) ;
static void RssiBar2(int,int,int,char*) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/
void Stat_14V(void) ;
void Stat_DIAL(void) ;
void Stat_GPS(void) ;
void Stat_Power(void) ;
void Stat_RSSI(void) ;
void Stat_level(void) ;
void Stat_Sync(void) ;
void Stat_Tempr(void) ;
void Stat_Uptime(void) ;
void Stat_Ethernet(void) ;
void Stat_RTOS(void) ;
void Stat_RxFFT(void) ;
void Stat_10MHz(void) ;

/*******************************************************************************
* Routine  : Cmd_status
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command sets or shows the time from the RTC.
*******************************************************************************/
int Cmd_status(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag */
   int Token = 0     ; /* Command token      */

   /* See which status command */
   if (2==argc)
   {
      stolower(argv[1]) ; /* To lower case first */
      Token = parse_token(StatCmds,argv[1],&error) ;
   }
   else
   {
      error = true ;
   }

   if (error)
   {
      Console_printf("Invalid parameter, see help.\n") ;
   }
   else
   {
      switch(Token)
      {
         case CMD_14V      : Stat_14V()      ; break ;
         case CMD_DIAL     : Stat_DIAL()     ; break ;
         case CMD_GPS      : Stat_GPS()      ; break ;
         case CMD_POWER    : Stat_Power()    ; break ;
         case CMD_RSSI     : Stat_RSSI()     ; break ;
         case CMD_ALEVEL   : Stat_level()    ; break ;
         case CMD_SYNC     : Stat_Sync()     ; break ;
         case CMD_TEMPR    : Stat_Tempr()    ; break ;
         case CMD_UPTIME   : Stat_Uptime()   ; break ;
         case CMD_ETHERNET : Stat_Ethernet() ; break ;
         case CMD_RTOS     : Stat_RTOS()     ; break ;
         case CMD_RXFFT    : Stat_RxFFT()    ; break ;
         case CMD_10MHZ    : Stat_10MHz()    ; break ;
         default           :                   break ; /* Shouldn't happen */
      }
   }

   return (0) ;
}

/*******************************************************************************
* Routine  : Stat_14V
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command checks the comparator that is checking the 14V supply. It
* triggers at 11.9V
*******************************************************************************/
void Stat_14V(void)
{
   Console_printf("The 14V supply is %c the 11.9V threshold.\n",V14_State()?'>':'<');
}

/*******************************************************************************
* Routine  : Stat_DIAL
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command reports back the DIAL connection status
*******************************************************************************/
void Stat_DIAL(void)
{
   Console_printf("DIAL Connection state: %s\n\n",DIAL_AUTHORIZED?"Connected":"Not Connected (local mode)") ;

   /* If connected, show the status byte */
   if (DIAL_AUTHORIZED)
   {
      Console_printf("         DIAL Flag Byte : 0x%2.2x\n",DIAL_flagbyte) ;
      Console_printf("          Flat Audio (1): %s\n",DIAL_FLATAUDIO?"Yes":"No (de-emphasized)") ;
      Console_printf("   Send Audio Always (2): %s\n",DIAL_ALWAYSAUDIO?"Yes":"No") ;
      Console_printf("   Don't filter CTCSS(4): %s\n",DIAL_NOSUBAUDIO?"Yes (don't filter)":"No (filter it)") ;
      Console_printf("Master Timing Source (8): %s\n",DIAL_IMMASTER?"Yes":"No") ;
      Console_printf("        Audio Codec (16): %s\n",DIAL_USEADPCM?"ADPCM":"uLaw") ;
      Console_printf("        Timing Mode (32): %s\n",DIAL_GENPURPOSE?"General Purpose":"GPS Timed") ;
      Console_printf("           Reserved (64): %d\n",(DIAL_flagbyte&64)/64) ;
      Console_printf("          Reserved (128): %d\n",(DIAL_flagbyte&128)/128) ;
   }
}

/*******************************************************************************
* Routine  : Stat_GPS
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command reports the status of the GPS receiver.
*******************************************************************************/
void Stat_GPS(void)
{
   int i = 0 ; /* counter */
   int j = 0 ; /* counter */

   Console_printf("    GPS 1PPS: %s\n",GPSLocked?"Locked":"Not Locked");
   Console_printf("Sample Clock: %s\n",GPSUsed?"GPS Synchronized":"Local Crystal");

   /* While it was a HW issue, I had a case where there was NO data at all    */
   /* coming from the GPS, so the status byte was still NULL.  Handling that  */
   /* case here too just in case.                                             */
   if (!GPSData.Status)
   {
      Console_printf("  GPS Status: No NMEA Data.\n");
   }
   else
   {
      Console_printf("  GPS Status: \"%c\" (A=Valid, V=Invalid)\n",GPSData.Status);
   }

   if ('A'==GPSData.Status)
   {
      Console_printf("   Longitude: %s%c\n",GPSData.Longitude,GPSData.LongDir);
      Console_printf("    Latitude: %s%c\n",GPSData.Latitude,GPSData.LatDir);
      Console_printf("    Altitude: %dm (%dft)\n",GPSData.Altitude,(GPSData.Altitude*328)/100) ;
      Console_printf("    UTC Date: %2.2d/%2.2d/%2.2d\n",GPSData.UTC_Year,GPSData.UTC_Month,GPSData.UTC_Day) ;
      Console_printf("    UTC Time: %2.2d:%2.2d:%2.2d.%3.3d\n\n",GPSData.UTC_Hour,GPSData.UTC_Min,GPSData.UTC_Sec,GPSData.UTC_mSec) ;

      Console_printf("   # of Sats: %d\n",SatStatus.nSats);
      Console_printf("        HDOP: %d.%2.2dm\n",SatStatus.hdop/100,SatStatus.hdop%100);
      Console_printf("       Speed: %d.%1.1dkts :)\n",SatStatus.Speed/10,SatStatus.Speed%10);

      Console_printf("  Sat Signal: [CH#, Sat#, SNR] for 12 max");
      for (i=0;i<MAXSATS;i=i+3)
      {
         Console_printf("\n              ");
         for (j=i;j<i+3;j++)
         {
            if (j<SatStatus.nSats)
            {
               Console_printf("[%2d %2d %2d] ",j,SatStatus.SatDat[j].SatNum,SatStatus.SatDat[j].SatSNR);
            }
         }
      }
      Console_printf("\n");
   }
}

/*******************************************************************************
* Routine  : Stat_Power
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command reports the Repeater power state (just the state of the
* ACFAIL signal.
*******************************************************************************/
void Stat_Power(void)
{
    if (ACFAIL_State())
    {
       Console_printf("AC has failed, repeater must be on battery power!\n") ;
    }
    else
    {
	   Console_printf("Repeater running normally on AC.\n") ;
    }
}

/*******************************************************************************
* Routine  : Stat_RSSI
*   Inputs : level
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command shows the RSSI in DAC value and HPF value until the user presses
* a key to stop.
*******************************************************************************/
void Stat_RSSI(void)
{
   char     abar[27]    = {0}   ;
   char     hbar[27]    = {0}   ;

   /* Enable all Rx filters--even if not needed for audio */
   RxDiags = true ;

   /* Purge any leftovers in the console queue so that kbhit() below waits on */
   /* a new character being received.                                         */
   Consoleio_purge() ;
   Console_printf("Press any key to stop...\n") ;
   osDelay(2000) ;

   while (!Consoleio_kbhit())
   {
      /* Analog RSSI value */
      RssiBar(Get_Analog_RSSI(ANALOG_RSSI_INTERPOLATED),abar) ;
      Console_printf("RSSI ADC: %3d %26s ",Get_Analog_RSSI(ANALOG_RSSI_INTERPOLATED),abar);

      /* HPF RSSI value */
      RssiBar(Hpf_RSSI,hbar) ;
      Console_printf("HPF %3d %26s ",Hpf_RSSI,hbar);

      /* COR and RDSTAT (CTCSS) states */
      Console_printf("%c %c\n",COR_State()?'C':'.',RDSTAT_State()?'R':'.');

      osDelay(200) ; /* Approx 10 packets at 20ms each */
   }

   /* Purge the key that stopped the reporting */
   Consoleio_purge() ;

   /* All done, only enable all Rx filters needed */
   RxDiags = false ;

}

/*******************************************************************************
* Routine  : Stat_level
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command shows the live analog level status.
* NOTE: While audio samples are converted to 16-bit signed values, the VinPP
* code in Rx_DSP is based on DAC values so full scale is 4096, not 65536.
*******************************************************************************/
#define VPP_TARG 14328 /* Rx Vpp target value     */
#define VPP_RANGE 2000 /* Range for display meter */
void Stat_level(void)
{
   uint8_t  level    =  0  ; /* Interim Rx level value */
   char     abar[27] = {0} ; /* Bar chart buffer       */

   /* Enable all Rx filters--even if not needed for audio */
   RxDiags = true ;

   /* Purge any leftovers in the console queue so that kbhit() below waits on */
   /* a new character being received.                                         */
   Consoleio_purge() ;
   Console_printf("Press any key to stop...\n") ;
   osDelay(2000) ;
   VinPP_Max = 0 ;

   while (!Consoleio_kbhit())
   {
      osDelay(200) ;
      level = VinPP_Max/16 ;
      RssiBar(level,abar) ;
      Console_printf("Audio: %3d %26s ",level,abar);
      RssiBar2(VPP_TARG,VPP_RANGE,PreComp_Vpp,abar) ;
      Console_printf("3kHz Cal: %5d %21s\n",PreComp_Vpp,abar);

      /* Reset these max values to zero, the ISRs will then start over finding*/
      /* the next max value.                                                  */
      VinPP_Max = 0 ;
      PreComp_Vpp = 0 ;
   }

   /* Purge the key that stopped the reporting */
   Consoleio_purge() ;

   /* All done, only enable all Rx filters needed */
   RxDiags = false ;
}

/*******************************************************************************
* Routine  : RssiBar
*   Inputs : level (0-255)
*      IOs : bar (the signal strength bar)
*  Returns : Nothing
*  Globals : None
*
* This routine creates a signal strength bar with one character per 10 points
* on the bar, so 26 chars max for 0-255.  The incoming string should be 27
* characters for the EOS.
*******************************************************************************/
static void RssiBar(int level,char* bar)
{
   int i = 0 ;

   /* Bound it just in case, I make a direct access below */
   if (level<  0) level = 0   ;
   if (level>255) level = 255 ;

   /* Make the core part of the bar */
   for (i=0;i<26;i++)
   {
      bar[i] = (i<level/10)?'=':'.' ;
      if ((i%5)==0) bar[i] = '|' ;
   }

   /* Put the tip on the bar and terminate the string */
   bar[level/10]='>' ;
   bar[26] = 0 ;
}

/*******************************************************************************
* Routine  : RssiBar2
*   Inputs : targ - target value (centerline of bar)
*          : range - range to display (bar will be +- half of this)
*          : value - value to display
*      IOs : bar (the voltage strength bar)
*  Returns : Nothing
*  Globals : None
*
* This routine creates a signal strength bar centered around the target value
* plus or minus half the range.  This is for precise calibrating, so the actual
* level can be way outside these bounds, so need to handle that gracefully.
* The incoming string should be 22 characters for the EOS.
*******************************************************************************/
static void RssiBar2(int targ, int range, int value, char* bar)
{
   int i     = 0 ; /* general counter */
   int index = 0 ; /* Index for level */

   /* Make the core part of the bar */
   for (i=0;i<21;i++)
   {
      bar[i] = ((i%5)==0)?'|':'.' ;
   }
   bar[21] = 0 ;

   /* Take care of the two extremes, and if not those, figger the position */
   if (value<=(targ-range/2))
   {
      bar[0] = '<' ;
      bar[1] = '<' ;
   }
   else if (value>=(targ+range/2))
   {
      bar[19] = '>' ;
      bar[20] = '>' ;
   }
   else
   {
      /* Precedence order matters to avoid integer rounding issues! */
      index =10+(value-targ)/(range/20) ;
      //index =10+(((value-targ)*10/2)/range) ;
      /* Debugging check */
      if ((index<0)||(index>20))
      {
         bar[10]='!' ;
      }
      else
      {
         bar[index]='^' ;
      }
   }
}

/*******************************************************************************
* Routine  : Stat_Sync
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command checks the local GPS time vs the time from the DIAL server.  It
* does this by setting a flag for the DIALTask to send an auth packet.  The
* return auth packet has the servers timestamp.  The DIALTask captures the
* local timestamp of when that Auth packet comes back and the two are compared
* below.  About 1ms later is normal for network delay on a home network.
*******************************************************************************/
void Stat_Sync(void)
{
   int     i      = 0 ; /* Just a counter    */
   int32_t delta  = 0 ; /* DIAL-GPS    delta */
   int32_t delta1 = 0 ; /* DIAL-GPS s  delta */
   int32_t delta2 = 0 ; /* DIAL-GPS ns delta */

   /* Fire of the Sync Check (runs in the DIALTask) */
   SyncCheck = SYNCCHECK_START ;

   /* Wait for it to complete, should take less than 1 sec */
   while ((i++<100)&&(SyncCheck!=SYNCCHECK_IDLE)) osDelay(10) ;

   if (SYNCCHECK_IDLE==SyncCheck)
   {
      Console_printf("DIAL Time:%10.10u.%9.9u\r\n",DSSecs,DSnSecs) ;
      Console_printf("  MY Time:%10.10u.%9.9u\r\n",MySecs,MynSecs) ;

      /* Figger out the delta and print it.  This is messy as I'm trying to   */
      /* do 64-bit math, but can't figure out how to get printf to support    */
      /* 64 bit integers.  Not helping is wanting to do signed math with      */
      /* unsigned values!  I'm sure there is a cleaner way.                   */
      delta1 = ((int32_t)MySecs-(int32_t)DSSecs)*1000000  ; /* Iffy conversion*/
      delta2 = ((int32_t)MynSecs-(int32_t)DSnSecs)/1000 ;   /* Safe conversion*/
      delta  = delta1+delta2 ;
      Console_printf("Local vs DIAL Time delta (us): %d\r\n",delta) ;
   }
   else
   {
      Console_printf("Sync Check failed, no DIAL server response.\n");
      SyncCheck=SYNCCHECK_IDLE ;
   }
}

/*******************************************************************************
* Routine  : Stat_Tempr
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This command reads and displays the temperature of the on-board P3T1755
* temperature sensor.  It also reads the STM32s internal temperature sensor.
* I do share the I2C1 hardware with the NVM code in settings.c, but can't yet
* see a way they could conflict.  Both are CLI-driven routines and only one
* CLI command can be run at a time.
*******************************************************************************/
void Stat_Tempr(void)
{
   static int8_t i2c_tempr IN_DMADD2  = 0 ; /* DMAable buffer for I2C read    */
   uint16_t      itemp_ADCv           = 0 ; /* Internal temperature ADC value */
   int           itemp                = 0 ; /* Internal temperature (integer) */
   int           i                    = 0 ; /* General counter                */
   int           err                  = 0 ; /* Error accumulator              */
   uint16_t      *TS_CAL1=(uint16_t *)0x1FF1E820; /* Ref Temp value at  30C   */
   uint16_t      *TS_CAL2=(uint16_t *)0x1FF1E840; /* Ref Temp value at 110C   */

   /* First do an ADC calibration in single-ended mode. Yea this only needs   */
   /* to be done once, this is going to be run rarely.                        */
   if (HAL_ADCEx_Calibration_Start(&hadc3, ADC_CALIB_OFFSET_LINEARITY, ADC_SINGLE_ENDED) != HAL_OK) err++ ;

   /* Start the conversion */
   if (!err)
   {
	   if (HAL_ADC_Start(&hadc3) != HAL_OK) err++ ;
   }

   /* Wait for up to 10ms for the end of conversion */
   if (!err)
   {
      i = 0 ; /* redundant, but I like it */
      while ((HAL_ADC_PollForConversion(&hadc3,0) != HAL_OK) && (i<TEMP_CONV_MS))
      {
         i++ ;
         osDelay(1) ;
      }

      /* If we got to TEMP_CONV_MS, OOPS! */
      if (TEMP_CONV_MS==i) err++ ;
   }

   /* If we got this far without error, all set! */
   if (!err)
   {
      /* Get the converted value of regular channel */
      itemp_ADCv = HAL_ADC_GetValue(&hadc3);

      /* During production, ST measures the A/D conversion value for          */
      /* temperature at 30C (TS_CAL1) and 110C (TS_CAL2).  Linearly           */
      /* extrapolate using those two points to convert the current reading to */
      /* temperature.                                                         */
      /* The example code uses floating point math.  Yea the H750 does        */
      /* floating point (and does it fast), but I just like integer arithmetic*/
      /* for something this simple.  Main thing to not get tripped up is to   */
      /* do all the multiplies first to get big numbers before dividing.      */
      /* That avoids weird rounding errors                                    */
      itemp = 30+(80*(itemp_ADCv-*TS_CAL1))/(*TS_CAL2-*TS_CAL1) ;

      Console_printf("MCU temperature:  %2dC, %3dF.\n",itemp,(itemp*9)/5+32) ;
   }
   else
   {
      Console_printf("Error reading MCU temperature.\n") ;
   }

   /* Read the two bytes of PCB temperature sensor register address 0.        */
   /* (the temperature)                                                       */
   I2C_SharedMemRead(TEMPR_ADDRESS0,0,I2C_MEMADD_SIZE_8BIT,(uint8_t*)&i2c_tempr,1,true) ;

   Console_printf("PCB temperature:  %2dC, %3dF.\n",i2c_tempr,(i2c_tempr*9)/5+32) ;

   /* Those are the guaranteed temperature sensors.  Now go scan for any more */
   /* P3T1755s that may have been added externally.  Up to 7 more.            */

   for (i=1;i<8;i++)
   {
      /* Temp sensor I2C address is base plus index times two */
	   if (I2C_SharedIsReady(TEMPR_ADDRESS0+i*2,2,3,true))
      {
         /* Read the two bytes of off-board temperature sensor register       */
	     /*address 0. (the temperature)                                       */
	      I2C_SharedMemRead(TEMPR_ADDRESS0+i*2,0,I2C_MEMADD_SIZE_8BIT,(uint8_t*)&i2c_tempr,1,true) ;
         Console_printf("Ext temperature%d: %2dC, %3dF.\n",i,i2c_tempr,(i2c_tempr*9)/5+32) ;
      }
   }
}

/*******************************************************************************
* Routine  : Stat_Uptime
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command looks at the localmode packet counter that increments by 1 every
* 20ms (50 times/sec) no matter what and uses it to report the time since boot.
* The localmode code also sets a bit if that counter wraps--at 944 days!
*******************************************************************************/
void Stat_Uptime(void)
{
   uint32_t count    = 0     ; /* Local mode count */
   uint8_t  overflow = false ; /* Overflow flag    */
   int updays        = 0     ; /* Days             */
   int uphours       = 0     ; /* Hours            */
   int upminutes     = 0     ; /* Minutes          */
   int upseconds     = 0     ; /* Seconds          */

   /* Get the data */
   GetLocalModeCounter(&count,&overflow) ;

   if (overflow)
   {
      Console_printf("Uptime >994 days! (that's my trackers limit).\n") ;
   }
   else
   {
      updays    = count/4320000 ; count %= 4320000 ;
      uphours   = count/180000  ; count %= 180000  ;
      upminutes = count/3000    ; count %= 3000    ;
      upseconds = count/50      ;
      Console_printf("Uptime: %d days %2.2d:%2.2d:%2.2d.\n",updays,uphours,upminutes,upseconds) ;
   }
}

/*******************************************************************************
* Routine  : Stat_Ethernet
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command displays the Ethernet link status.  Obviously useful only if
* you are using the USB/UART console as if you have Ethernet issues, Telent
* ain't gonna be working! :) The stats I can report are if the link is up, the
* link rate, and the resolved IP address.
*******************************************************************************/
void Stat_Ethernet(void)
{
   int      i      = 0 ;
   int32_t  link   = 0 ;
   uint32_t duplex = 0 ;
   uint32_t speed  = 0 ;

   Console_printf(" Voter2 MAC Address : ") ;
   for (i=0;i<5;i++) Console_printf("%2.2x:",Settings.MyMACAddr[i]) ;
   Console_printf("%2.2x\n",Settings.MyMACAddr[5]) ;


   /* Get the link state from the PHY directly */
   KSZ8081_GetLinkState(&link,&duplex,&speed) ;

   if (KSZ8081_LINK_DOWN==link)
   {
      Console_printf("      Ethernet link : Disconnected, Link Not Active\n") ;
   }
   else
   {
      Console_printf("      Ethernet link : Connected\n") ;
      Console_printf("   Connection Speed : %d Mbit\n",(ETH_SPEED_10M==speed)?10:100) ;
      Console_printf("  Connection Duplex : %s Duplex\n",(ETH_HALFDUPLEX_MODE==duplex)?"Half":"Full") ;
      Console_printf("Resolved IP address : %s\n",ActualIPstr()) ;
      Console_printf("   Resolved Netmask : %s\n",ActualNMstr()) ;
      Console_printf("   Resolved Gateway : %s\n",ActualGWstr()) ;
      Console_printf("       Resolved DNS : %s\n",ActualDNstr()) ;
   }
}

/*******************************************************************************
* Routine  : Stat_RTOS
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : None (directly)
*
* This command displays the RTOS task list and task CPU utilization (I think).
* FreeRTOS (once set up correctly) provides a single convenient command to
* show this, curious how well it works! :)
*******************************************************************************/
#define MAXTASKS 15 /* Max supported tasks */

void Stat_RTOS(void)
{
   char TaskList[MAXTASKS*40] = {0} ; /* Docs say 40 bytes per task */

   Console_printf("Stats are:\n") ;

   vTaskGetRunTimeStats(TaskList) ;
   /* !!! If/when I stop calling vTaskGetRunTimeStats() above, un-define      */
   /* configUSE_STATS_FORMATTING_FUNCTIONS in FreeRTOSConfig.h.               */
   Console_puts(TaskList) ;
}

/*******************************************************************************
* Routine  : Stat_RxFFT
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : TBD
*
* This command tries to show the result of the FFT of the Rx incoming data.
* This is kind hard to do in text form over a console.  This is also for me
* only for debugging DSP/BEW mode, I can't see it being useful for anyone else.
* The FFT result is 16x 250Hz frequency bins.  On a single line I will
* represent each bin by the character A-P.  The amplitude of that bin
* will be represented by its location along the line.  I also show the
* BEW event flag as well as the FFT sum value for debugging.
*******************************************************************************/
#define FFT_BARLEN 40

void Stat_RxFFT(void)
{
   int  i               =  0  ; /* General counter */
   char freqid          =  0  ; /* Frequency ID    */
   int  freqlvl         =  0  ; /* Frequency level */
   char FFT_BarText[FFT_BARLEN] = {0} ; /* My VU bar */

   /* Enable all Rx filters--even if not needed for audio */
   RxDiags = true ;

   /* Purge any leftovers in the console queue so that kbhit() below waits on */
   /* a new character being received.                                         */
   Consoleio_purge() ;
   Console_printf("Press any key to stop...\n") ;
   osDelay(2000) ;

   while (!Consoleio_kbhit())
   {
      /* First fill in the VU bar background */
      for (i=0;i<FFT_BARLEN;i++) FFT_BarText[i] = '.' ;
      FFT_BarText[ 0] = '|'  ; /* Left edge  */
      FFT_BarText[33] = '|'  ; /* Right edge */
      FFT_BarText[34] = ' '  ; /* Separator  */
      FFT_BarText[36] =  0   ; /* EOS        */

      /* Plunk in a letter for each frequency bin at its relative amplitude   */
      for(i=0;i<FFT_BINLEN;i++)
      {
         freqid  = (i<26)?'A'+i:'0'+i-26    ;
         freqlvl = (RxFFT_Bins[i]/100000)+1 ; /* Arbitrary divisor */
         if (freqlvl< 1) freqlvl = 1        ;
         if (freqlvl>32) freqlvl = 32       ;
         FFT_BarText[freqlvl]= freqid       ;
      }

      /* IF a BEW event, flag it. */
      if (BEW_Event) FFT_BarText[35] = 'B' ;

      Console_printf("%s %d\n",FFT_BarText,RxFFT_SigSum) ;
      osDelay(200) ;
   }

   /* Purge the key that stopped the reporting */
   Consoleio_purge() ;

   /* All done, only enable all Rx filters needed */
   RxDiags = false ;

}

/*******************************************************************************
* Routine  : Stat_10MHz
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : ClocksP1PPS New_CP1PPS
*
* This command shows the 10MHz clock frequency using the GPS1PPs as the
* reference.  For Voter2s with crystals, this is "interesting", but not much
* can be done.  For Voter2s with OCVCXOs this shows how well the control loop
* is closing.
*******************************************************************************/
void Stat_10MHz(void)
{
   uint32_t ClkMHz   = 0 ; /* Clock MHz count */
   uint32_t ClkkHz   = 0 ; /* Clock kHz count */
   uint32_t ClkHz    = 0 ; /* Clock Hz count  */
   uint32_t ClkmHz   = 0 ; /* Clock mHz count */
   int32_t  ppc      = 0 ; /* Error in clocks */
   int32_t  ppb      = 0 ; /* Error in ppb    */
   int32_t  ppm      = 0 ; /* Error in ppm    */
   char     pps      = 0 ; /* Error sign      */

   int      i        = 0 ; /* General couner                     */
   int32_t  FreqSum  = 0 ; /* Sum of historical frequencies      */
   uint32_t FreqInt  = 0 ; /* Avg Frequency integer part         */
   uint32_t FreqFrac = 0 ; /* Avg Frequency fractional part      */
   int32_t  PPTDelta = 0 ; /* Delta from ideal frequency (PPT)   */


   /* For this to work, GPS needs to be locked. */
   if (!GPSLocked)
   {
      Console_printf("This status requires a locked GPS signal to work.\n") ;
   }
   else
   {
      /* Purge any leftovers in the console queue so that kbhit() below waits on */
      /* a new character being received.                                         */
      Consoleio_purge() ;
      Console_printf("Press any key to stop...\n") ;
      osDelay(2000) ;

      /* Clear out any stagnant flags first */
      New_CP1PPS_D = false ;
      VcxoDValid   = false ;

      while (!Consoleio_kbhit())
      {
         if (!Vcxo_present && New_CP1PPS_D) /* XO clock source */
         {
            /* Fancy math to get clock frequency components */
            ClkMHz = (ClocksP1PPS)/4000000      ; /* MHz component */
            ClkkHz = (ClocksP1PPS%4000000)/4000 ; /* kHz component */
            ClkHz  = (ClocksP1PPS%4000)/4       ; /* Hz  component */
            ClkmHz = (ClocksP1PPS%4)*25         ; /* cHz component */

            /* Even fancier math for ppm error.  To get components right I need  */
            /* all positive numbers or it gets weird.                            */
            ppc = ((int32_t)ClocksP1PPS-(int32_t)40000000) ; /* Error in ticks   */
            pps = (ppc<0)?'-':'+'  ; /* Sign handling      */
            if (ppc<0) ppc = - ppc ; /* Sign handling      */
            ppm = ppc/40           ; /* parts per million  */
            ppb = (ppc%40)*25      ; /* parts per trillion */

            /* Show results! */
            Console_printf("Clock (XO): %2d,%3.3d,%3.3d.%2.2d (%c%d.%3.3dppm)\n",ClkMHz,ClkkHz,ClkHz,ClkmHz,pps,ppm,ppb) ;
            New_CP1PPS_D = false ;
         }
         else if (Vcxo_present && VcxoDValid) /* VCXO clock source */
         {
            /* Add up the last 25 clock counts */
            FreqSum  = 0 ;
            for (i=0;i<DISP_HISTORY;i++) FreqSum += disp_history[i] ;

            /* Calculate the delta in PPT (yes, trillion!) */
            PPTDelta = ((FreqSum-40000000*DISP_HISTORY)*PPT_PHZ)/DISP_HISTORY ;

            /* Now get the averaged frequency integer and fractional (1000th)    */
            /* parts.  Order matters to minimize integer rounding errors         */
            FreqInt  = FreqSum/DISP_HISTORY ;
            FreqFrac = ((FreqSum-(FreqInt*DISP_HISTORY))*1000)/DISP_HISTORY ;

            /* Fancy math to get clock frequency components */
            ClkMHz = (FreqInt)/4000000          ; /* MHz component */
            ClkkHz = (FreqInt%4000000)/4000     ; /* kHz component */
            ClkHz  = (FreqInt%4000)/4           ; /* Hz  component */
            ClkmHz = (FreqInt%4)*250+FreqFrac/4 ; /* mHz component */

            /* Show results! */
            Console_printf("Clock (VCXO): %2d,%3.3d,%3.3d.%2.3dHz (%dppb)\n",ClkMHz,ClkkHz,ClkHz,ClkmHz,PPTDelta/1000) ;
            VcxoDValid = false ;
         }

         osDelay(200) ;
      }

      /* Purge the key that stopped the reporting */
      Consoleio_purge() ;
   }
}
