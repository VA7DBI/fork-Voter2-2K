/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Backup file.  It manages backing up settings to a TFTP server  */
/* and restoring settings from a TFTP server.  The filename used is fixed at  */
/* "Voter2-2K_SN#####.txt" where ##### is the Voter2s serial number.          */
/* The file contents are ASCII, consisting of CLI set commands for all        */
/* the settings, so easy to hand edit if needed.  The restore command reads   */
/* these commands and sends them to the CLI interpreter.                      */
/******************************************************************************/
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Settings_Backup - Send settings to TFTP server for backup               */
/*  - Settings_Restore - Read settings file from TFTP server.                 */
/*  - Backup_getc - For the CLI to get commands during restore                */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "lwip.h"
#include "lwip/api.h"


#include "string.h"
#include "Options.h"
#include "main.h"
#include "ConsoleTask.h"
#include "Tftp.h"
#include "Utils.h"
#include "Settings.h"
#include "SetShow.h"
#include "Backup.h"

#ifdef LOCALVOTER
#include "LocalVoter/LocalSettings.h"
#endif

#ifndef NODIALTASK
#include "DialSettings.h"
#endif

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
#define MAX_SET_LINE 50

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TFTP_CONTEXT Restore_Context = {0}   ; /* TFTP Restore session context */
static int Pkt_Size = 0 ; /* Current packet size. (if <512, last packet!      */
static int Pkt_idx  = 0 ; /* Current index into the packet.                   */

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void strcatu32(char* fname,uint32_t num) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Settings_Backup
*   Inputs : ufname - NULL for default, not NULL overrides it
*      IOs : None
*  Returns : Bytes written
*  Globals : Settings
*
* This routine writes all the Voter2 settings to a file on the server via TFTP.
* The filename will be VOter2-2K_SN####.txt where #### is the Voter2 serial
* number. Hooks are in place for the optional DIAL and Local settings.
*
* The settings are stored as CLI commands.
*******************************************************************************/
int Settings_Backup(char* ufname)
{
   TFTP_CONTEXT Context        = {0}   ; /* TFTP Session context    */
   char  fname[FNAMELEN]       = {0}   ; /* Project filename        */
   char  Setting[MAX_SET_LINE] = {0}   ; /* Buffer for a setting    */
   int   ByteCount             =  0    ; /* Byte count              */
   int   BlockCount            =  0    ; /* Block counter           */
   int   tftp_bytes            =  0    ; /* TFTP packet byte count  */
   int   Done                  = false ; /* Done flag               */
   int   param                 =  0    ; /* Parameter counter       */
   int   paramlen              =  0    ; /* Parameter string length */

   /* Saving settings is for root mode only, not guest */
   if (!RootMode)
   {
      Console_printf("Sorry, this command isn't available in guest mode.\n") ;
   }
   else
   {
      if (NULL==ufname) /* No user override for filename */
      {
         /* The file we want is Voter2-2K_SN#####.txt */
         strcpy(fname,"Voter2-2K_SN") ;
         strcatu32(fname,Settings.MySerialNum) ;
         strcat(fname,".txt") ;
      }
      else /* Users override filename */
      {
         strntcpy(fname,ufname,FNAMELEN) ;
      }

      /* Contact the TFTP Server... */
      ShowIP("Contacting TFTP server at",Settings.TFTP_Addr) ;
      Console_printf("Backup file will be %s\n",fname) ;

      /* Initialize things and send a write request */
      TFTP_Init(Settings.TFTP_Addr,&Context) ;
      TFTP_SendRWRQ(fname,TFTP_WRQ,TFTP_MODE_ASCII,&Context) ;

      /* The response to a write request is an ack.             */
      TFTP_GetData(&Context) ; /* Hopefully get an ACK          */
      /* Make sure the ACK has a block number of 0              */
      if (0!=Context.Block) Context.Error=TFTPERR_BADBLOCK ;
      Show_TFTP_Err(&Context) ; /* Prints error if one happened */

      /* TFTP server ready, start filling the buffer with setting commands.      */
      /* Each setting gets put in a buffer, then that setting text gets put in   */
      /* the TFTP buffer up to 512 bytes. If the TFTP buffer fills, we write it  */
      /* out and put any remaining text into the next buffer.                    */
      /* After the last command, we set the Done flag and exit, writing out any  */
      /* remaining text.                                                         */
      while (!Context.Error && !Done)
      {
         paramlen = 0 ; /* default to no parameter for non-supported cases */
         switch (param)
         {
            case  0 : paramlen=Backup_IP   (Setting,"mystaticip" ,Settings.My_StaticIP          ) ; param++ ; break ;
            case  1 : paramlen=Backup_IP   (Setting,"mystaticsn" ,Settings.My_StaticSubnet      ) ; param++ ; break ;
            case  2 : paramlen=Backup_IP   (Setting,"mystaticgw" ,Settings.My_StaticGateway     ) ; param++ ; break ;
            case  3 : paramlen=Backup_IP   (Setting,"mystaticdns",Settings.My_StaticDNS         ) ; param++ ; break ;
            case  4 : paramlen=Backup_IP   (Setting,"tftpaddr"   ,Settings.TFTP_Addr            ) ; param++ ; break ;
            case  5 : paramlen=Backup_int  (Setting,"gpsbaud"    ,Settings.GPS_Baud             ) ; param++ ; break ;
            case  6 : paramlen=Backup_list (Setting,"gpsedge"    ,Settings.GPS_PPSEdge,GPS_Edges) ; param++ ; break ;
            case  7 : paramlen=Backup_str  (Setting,"guestpwd"   ,Settings.Guest_Password       ) ; param++ ; break ;
            case  8 : paramlen=Backup_str  (Setting,"rootpwd"    ,Settings.Root_Password        ) ; param++ ; break ;
            case  9 : paramlen=Backup_str  (Setting,"myname"     ,Settings.Voter_Name           ) ; param++ ; break ;
            case 10 : paramlen=Backup_list (Setting,"myipmode"   ,Settings.My_IPMode,MyIPModes  ) ; param++ ; break ;
            case 11 : paramlen=Backup_int  (Setting,"s2nport"    ,Settings.S2N_Port             ) ; param++ ; break ;
            case 12 : paramlen=Backup_int  (Setting,"s2nptime"   ,Settings.S2N_PollTime         ) ; param++ ; break ;
            case 13 : paramlen=Backup_list (Setting,"rxmode"     ,Settings.RxMode,RxModes       ) ; param++ ; break ;
            case 14 : paramlen=Backup_list (Setting,"rssimode"   ,Settings.RssiMode,RssiModes   ) ; param++ ; break ;
#ifdef LOCALVOTER
            case 15 : paramlen=Backup_Local(Setting,true)                                         ; param++ ; break ; /* First call         */
            case 16 : paramlen=Backup_Local(Setting,false) ; if (0==paramlen) param++                       ; break ; /* Subsequent calls   */
#else
            case 15 :                                                                               param++ ; break ; /* Unused if no local */
            case 16 :                                                                               param++ ; break ; /* Unused if no local */
#endif
#ifndef NODIALTASK
            case 17 : paramlen=Backup_DIAL(Setting,true)                                          ; param++ ; break ;
            case 18 : paramlen=Backup_DIAL(Setting,false) ; if (0==paramlen) param++                        ; break ;
#else
            case 17 :                                                                               param++ ; break ;
            case 18 :                                                                               param++ ; break ;
#endif
            default : Done = true                                                                           ; break ;
         }

         /* Keep a tally of bytes written */
         ByteCount+= paramlen ;

         /* If the new parameter doesn't fill up the buffer, just add it on      */
         if (tftp_bytes+paramlen<512)
         {
            memcpy(TFTP_PAYLOAD+tftp_bytes,Setting,paramlen) ;
            tftp_bytes+=paramlen ;
         }
         else
         /* OK, the current parameter will fill up the current buffer, copy what */
         /* we can, write that buffer, then put any remainder into the following */
         /* buffer.                                                              */
         {
            /* Copy what parameter text we can up to the limit of the TFTP buffer*/
            /* and write it out to the server.                                   */
            memcpy(TFTP_PAYLOAD+tftp_bytes,Setting,512-tftp_bytes) ;
            TFTP_SendData(&Context,512) ; /* Send the packet              */
            TFTP_GetData(&Context)      ; /* Hopefully get an ACK         */
            BlockCount++ ;
            /* Make sure the ACK has the right block number               */
            if (BlockCount!=Context.Block) Context.Error=TFTPERR_BADBLOCK ;
            Show_TFTP_Err(&Context)     ; /* Prints error if one happened */

            /* Now copy any remaining parameter text to the next fill of the     */
            /* buffer.                                                           */
            tftp_bytes = paramlen-(512-tftp_bytes) ;
            memcpy(TFTP_PAYLOAD,Setting+(paramlen-tftp_bytes),tftp_bytes) ;
         }
      }

      /* Done! Write out the last buffer and wait for the ACK              */
      TFTP_SendData(&Context,tftp_bytes) ; /* Send the packet              */
      TFTP_GetData(&Context) ;             /* Hopefully get an ACK         */
      Show_TFTP_Err(&Context) ;            /* Prints error if one happened */

      /* For the boundary case where we ended up with a buffer of exactly 512 */
      /* bytes, send a zero-byte packet before terminating.                   */
      if (512==tftp_bytes)
      {
         TFTP_SendData(&Context,0) ; /* Send the empty packet        */
         TFTP_GetData(&Context)    ; /* Hopefully get an ACK         */
         Show_TFTP_Err(&Context)   ; /* Prints error if one happened */
      }

      /* All done, shut down the port. */
      TFTP_Terminate(&Context) ;
   }
   return (ByteCount) ;
}

/*******************************************************************************
* Routine  : Settings_Restore
*   Inputs : ufname - NULL for default, not NULL overrides it
*      IOs : None
*  Returns : Bytes read
*  Globals : Pkt_Size, Pkt_idx
*
*
* This routine opens up a Voter2 settings file on the FTP server (see backup
* comments for filename) and reads in the settings info and feeds it to the
* CLI interpreter for processing.
*******************************************************************************/
int Settings_Restore(char* ufname)
{
   char fname[FNAMELEN] = {0}   ; /* Project filename */
   int  ByteCount       =  0    ; /* Byte count       */
   int  BlockCount      =  0    ; /* Block counter    */

   if (NULL==ufname) /* No user override for filename */
   {
      /* The file we want is Voter2-2K_SN#####.txt */
      strcpy(fname,"Voter2-2K_SN") ;
      strcatu32(fname,Settings.MySerialNum) ;
      strcat(fname,".txt") ;
   }
   else /* Users override filename */
   {
      strntcpy(fname,ufname,FNAMELEN) ;
   }


   /* Contact the TFTP Server... */
   ShowIP("Contacting TFTP server at",Settings.TFTP_Addr) ;
   Console_printf("Restore file is %s\n",fname) ;

   /* Initialize things and send a read request */
   TFTP_Init(Settings.TFTP_Addr,&Restore_Context) ;
   TFTP_SendRWRQ(fname,TFTP_RRQ,TFTP_MODE_ASCII,&Restore_Context) ;

   /* The response to a read request is the first packet                      */
   Pkt_Size=TFTP_GetData(&Restore_Context) ; /* Hopefully data                */
   BlockCount++ ;
   /* Make sure we get back the right block number                            */
   if (BlockCount!=Restore_Context.Block) Restore_Context.Error=TFTPERR_BADBLOCK ;
   Show_TFTP_Err(&Restore_Context) ;         /* Prints error if one happened  */
   if (!Restore_Context.Error) TFTP_SendAck(&Restore_Context) ;

   /* TFTP server ready and (unless an open error) we have the first buffer   */
   /* of settings commands.                                                   */
   if (!Restore_Context.Error)
   {
      /* The way this works is I set the flag below that tells the ConsoleTask*/
      /* to get characters from the scripting buffer instead of Telnet/UART,  */
      /* then simply return.  With that flag set, the Console will instead    */
      /* get commands from Backup_getc() below until the file is processed.   */
      /* The size of the first TFTP packet was set above, set the index to 0  */
      /* for the start of this first packet.                                  */
      Pkt_idx = 0 ;
      Console_Script = true ;
   }

    return (ByteCount) ; /* doesn't work in this case, will be 0 */
}

/*******************************************************************************
* Routine  : Backup_getc
*   Inputs : None
*      IOs : None
*  Returns : Next byte in buffer (or 0x00 for EOF)
*  Globals : Console_Script, Pkt_Size, Pkt_idx, TFFTP_Buf
*
* This is the routine called by the CLI interpreter to get "user input" if
* Console_Script is true.  Essentially scripting support.
*******************************************************************************/
char Backup_getc()
{
   char rval = 0 ;

   /* If we are in the middle of a buffer, just return a single byte from it. */
   if (Pkt_idx<Pkt_Size)
   {
      rval = (char)*(TFTP_PAYLOAD+Pkt_idx) ;
      Pkt_idx++ ;
   }
   else
   {
      /* If we got the end of a packet and it was a full (512 byte) packet,   */
      /* that means get another packet.  If it was a less than full packet,   */
      /* that is the end of the file, so stop getting packets.                */
      if (Pkt_Size<512)
      {
         rval = 0 ;
         Console_Script = false ;
         TFTP_Terminate(&Restore_Context) ;
      }
      else
      {
         Pkt_Size=TFTP_GetData(&Restore_Context) ; /* Get next packet         */
         Show_TFTP_Err(&Restore_Context) ;         /* Prints error if one     */
         if (!Restore_Context.Error) TFTP_SendAck(&Restore_Context) ; /* Ack  */
         rval = (char)*(TFTP_PAYLOAD) ;            /* return next packet char */
         Pkt_idx = 1 ;                             /* reset char pointer      */
      }
   }

   return(rval) ;
}

/*******************************************************************************
* Routine  : strcatu32
*   Inputs : num - integer to add to the string
*      IOs : str - string to add the number to
*  Returns : Nothing
*  Globals : None
*
* This routine adds a number (in ASCII) to the end of a string.  The number is
* a uin32_t, so no negatives! The number is truncated to the minimum number of
* digits needed.
*******************************************************************************/
static void strcatu32(char* dst,uint32_t num)
{
   char asciival[11] = {0} ; /* 4 billion = 10 digits plus EOS */
   int  i            =  0  ; /* General counter                */
   int firstdig      =  0  ; /* Pointer to first non-0 digit   */

   /* Convert the number to ASCII, noting the first non-zero digit */
   for (i=9;i>0;i--)
   {
      asciival[i] = num%10+'0' ;
      if (num>0) firstdig = i  ;
      num = num / 10           ;
   }

   /* Copy just the non-zero digits */
   strcat(dst,asciival+firstdig) ;

}

/*******************************************************************************
* Routine  : Backup_IP, Backup_int, Backup_list, Backup_str
*   Inputs : id - parameter identifier
*          : IP_addr - IP address (Backup_IP)
*          : val - integer parameter (Backup_int)
*          : entry, Tokens Token list and entry number (Backup_list)
*          : value - string (Backup_str)
*      IOs : dest - Setting string
*  Returns : length of the string
*  Globals : None
*
* These routines creates a setting string for the various parameter types
*******************************************************************************/
int Backup_IP(char* dest, char* id ,uint32_t IPAddr)
{
   sprintf(dest,"set %s %ld.%ld.%ld.%ld\n",id,IPAddr>>24,(IPAddr>>16)&0xff,(IPAddr>>8)&0xff,(IPAddr)&0xff) ;
   return(strlen(dest)) ;
}

int Backup_int(char* dest, char* id ,int val)
{
   sprintf(dest,"set %s %d\n",id,val) ;
   return(strlen(dest)) ;
}

int Backup_list(char* dest, char* id, int entry,TOKENLIST* Tokens)
{
   sprintf(dest,"set %s %s\n",id,Tokens[entry].token) ;
   return(strlen(dest)) ;
}

int Backup_str(char* dest, char* id, char* value)
{
   sprintf(dest,"set %s %s\n",id,value) ;
   return(strlen(dest)) ;
}
