/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the Histograms file.  It is in charge of the CLI jitter and        */
/* netdelay commands that log and displays audio packet jitter and network    */
/* delays.                                                                    */
/* - The Jitter histogram measures just packet-packet jitter. Ideally a packet*/
/* arrives every 20/40ms regardless of mode (GPS vs General).  This measures  */
/* the time between packets and creates a histogram of the inter-packet time. */
/* - The NetDelay histogram measures the difference between a GPS-timed packet*/
/* timestamp and the local (super-accurate) GPS time as that packets gets     */
/* received via Ethernet.  As a packet gets its timestamp from a GPS at its   */
/* creation, this is a good measure of round trip delay of that audio packet  */
/* from the source Voter, through the DIAL server, and to this Voter2.  Note  */
/* that the actual presentation of that packets data is delayed by the dial   */
/* txbuf commands delay setting.  Clearly, this only works with GPS-timed     */
/* packets.                                                                   */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - Cmd_jitter   - CLI command for jitter info                              */
/*  - Cmd_netdelay - CLI command for netdelay info                            */
/*  - Jitter_Log   - Called by IP processing routine on receipt a packet.     */
/*  - NetDelay_Log - Called by IP processing routine on receipt a packet.     */
/*                                                                            */
/******************************************************************************/
// TO DO:
//
/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include "cmsis_os.h"
#include "string.h" /* for memset */

#include "Options.h"
#include "main.h"
#include "Utils.h"
#include "ConsoleTask.h"
#include "GPS.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/
extern TIM_HandleTypeDef htim2 ;

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
enum
{
   CMD_OOPS = 0,
   CMD_START,
   CMD_STOP,
   CMD_RESET,
   CMD_SHOW
} JITTER_ENUMS ;

#define JITTER_ENTRIES 25
#define JITTER_BINSIZE 4 /* in ms */

#define NETDELAY_ENTRIES 25
#define NETDELAY_BINSIZE 40 /* in ms */

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
char* cmd_jitter_cmd   = "jitter" ;
char* cmd_jitter_cmdsc = "jit"    ;
char* cmd_jitter_help  = "jitter - [start|stop|reset|show] Audio packet jitter measurer controls\n"
                         "         start - start measuring\n"
                         "         stop - stop measuring\n"
                         "         reset - reset counters\n"
                         "         show - show jitter histogram\n" ;

char* cmd_netdelay_cmd   = "netdelay" ;
char* cmd_netdelay_cmdsc = "ndl"      ;
char* cmd_netdelay_help  = "netdelay - [start|stop|reset|show] Audio packet network delay measurer controls\n"
                           "           start - start measuring\n"
                           "           stop - stop measuring\n"
                           "           reset - reset counters\n"
                           "           show - show netdelay histogram\n" ;

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/
static TOKENLIST JitterCmds[] =
{
   {"start",NULL,CMD_START},
   {"stop" ,NULL,CMD_STOP },
   {"reset",NULL,CMD_RESET},
   {"show" ,NULL,CMD_SHOW },
   {NULL   ,NULL,0        }
} ;

/* The histogram tables */
static uint16_t Jitter_Histogram[JITTER_ENTRIES] = {0}   ; /* The table       */
static int      Measure_Jitter                   = false ; /* On/off flag     */

static uint16_t NetDelay_Histogram[NETDELAY_ENTRIES] = {0}   ; /* The table   */
static int      Measure_NetDelay                     = false ; /* On/off flag */

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
static void Jitter_Reset(void) ;
static void Jitter_Show(void) ;
static void Histo_Graph(int,int) ;

static void NetDelay_Reset(void) ;
static void NetDelay_Show(void) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : Cmd_jitter
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command manages the gathering and displaying of the jitter data.
*******************************************************************************/
int Cmd_jitter(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag */
   int Token = 0     ; /* Command token      */

   /* See which jitter command */
   if (2==argc)
   {
      stolower(argv[1]) ; /* To lower case first */
      Token = parse_token(JitterCmds,argv[1],&error) ;
   }
   else
   {
      error = true ;
   }

   if (error)
   {
      Console_printf("Invalid parameter, see help.\n") ;
   }
   else
   {
      switch(Token)
      {
         case CMD_START : Measure_Jitter = true  ; break ;
         case CMD_STOP  : Measure_Jitter = false ; break ;
         case CMD_RESET : Jitter_Reset()         ; break ;
         case CMD_SHOW  : Jitter_Show()          ; break ;
         default        :                          break ; /* Shouldn't happen */
      }
   }

   return (0) ;
}

/*******************************************************************************
* Routine  : Jitter_Reset
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : Jitter_Histogram
*
* This function clears out the Jitter table.
*******************************************************************************/
static void Jitter_Reset(void)
{
   memset(Jitter_Histogram,0,sizeof(Jitter_Histogram)) ;
}

/*******************************************************************************
* Routine  : Jitter_Show
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : Jitter_Histogram
*
* This function displays the histogram contents.
*******************************************************************************/
static void Jitter_Show(void)
{
   int i   = 0 ; /* General counter                            */
   int max = 0 ; /* Max value in histogram table (for scaling) */

   /* Go find the max value */
   for (i=0;i<JITTER_ENTRIES;i++)
   {
      if (Jitter_Histogram[i]>max) max = Jitter_Histogram[i] ;
   }

   /* The fixed header info... */
   Console_printf("Audio Packet Jitter Histogram\n") ;
   Console_printf("  ms    count graph\n") ;
   Console_printf("======= ===== ==================================================\n") ;

   /* For all but the last entry... */
   for (i=0;i<JITTER_ENTRIES-1;i++)
   {
      Console_printf("%3d-%3d %5d ",i*JITTER_BINSIZE,(i+1)*JITTER_BINSIZE-1,Jitter_Histogram[i]) ;
      Histo_Graph(Jitter_Histogram[i],max) ;
   }

   /* The last entry is the "everything greater" bin, so different formatting */
   Console_printf("   >%3d %5d ",JITTER_BINSIZE*(JITTER_ENTRIES-1),Jitter_Histogram[JITTER_ENTRIES-1]) ;
   Histo_Graph(Jitter_Histogram[i],max) ;
}

/*******************************************************************************
* Routine  : Histso_Graph
*   Inputs : value - value to graph
*          : max - max value (represents full [50 char]) graph
*      IOs : None
*  Returns : Nothing
*  Globals : None
*
* This function displays a line of asterisk's proportional to the max value,
* so if value = max, 50 stars, if 1/2 of max, 25 stars.
*******************************************************************************/
static void Histo_Graph(int value, int max)
{
   int  nstars  =  0  ; /* Stars to print        */
   char bar[52] = {0} ; /* String of those stars */

   /* Compute star count.  There are some weird cases where value>max, so     */
   /* just to be sure, make sure nstars can't be >50.                         */
   nstars = (value*50)/max ;
   if (nstars>50) nstars = 50 ;

   /* bar is already 52 nulls, so just memset the number of stars, terminate  */
   /* it with an LF and print it.  There will always be a null at the end.    */
   memset(bar,'*',nstars) ;
   bar[nstars] = '\n' ;
   Console_printf("%s",bar) ;
}

/*******************************************************************************
* Routine  : Jitter_Log
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : Jitter_Histogram
*
* This is the function called by the Ethernet packet handling routines, both
* uLaw and ADPCM.  I just get the TIM2 counter value incrementing ever 25ns and
* compare it to the previously read value to get the delta and then increment
* that histogram bin value.  If any of the entries gets to 50K before being
* stopped by the user I stop there automatically to preserve the integrity of
* the histogram.
*******************************************************************************/
void Jitter_Log(void)
{
   static uint32_t LastCount = 0 ; /* Last counter value to get a delta */

   uint32_t CurrentCount = 0 ; /* Current counter value */
   uint32_t Delta        = 0 ; /* Delta in ms           */
   int      bin          = 0 ; /* Histogram bin number  */

   /* Get the current count of Timer 2.                             */
   /* No need to worry about rollover, it's a feature not a bug! :) */
   CurrentCount = htim2.Instance->CNT ;

   /* Always get the current count (and save it below) so that even on first  */
   /* activation, we'll have an accurat delta.  Only do something with it if  */
   /* we are actually measuring.                                              */
   if (Measure_Jitter)
   {
      Delta = CurrentCount - LastCount ;

      /* The delta is in 25ns ticks, convert to ms */
      Delta = Delta/40000 ;

      /* Convert to a bin number and take care of a bin number overflow */
      bin = Delta/JITTER_BINSIZE ;
      if (bin>JITTER_ENTRIES-1) bin = JITTER_ENTRIES-1 ;

      /* Increment the bin unless any bin exceeds the max. */
      if (Jitter_Histogram[bin]<50000)
      {
         Jitter_Histogram[bin]++ ;
      }
      else
      {
         Measure_Jitter = false ;
      }
   }

   /* Save the count so we can get delta to the next sample */
   LastCount = CurrentCount ;
}

/*******************************************************************************
* Routine  : Cmd_netdelay
*   Inputs : argc - number of arguments
*          : argv - list of arguments
*      IOs : None
*  Returns : 0 for success always
*  Globals : None
*
* This command manages the gathering and displaying of NetDelay data.
*******************************************************************************/
int Cmd_netdelay(int argc, char* argv[])
{
   int error = false ; /* Parsing error flag */
   int Token = 0     ; /* Command token      */

   /* See which command */
   if (2==argc)
   {
      /* Same commands as the jitter command */
      stolower(argv[1]) ; /* To lower case first */
      Token = parse_token(JitterCmds,argv[1],&error) ;
   }
   else
   {
      error = true ;
   }

   if (error)
   {
      Console_printf("Invalid parameter, see help.\n") ;
   }
   else
   {
      switch(Token)
      {
         case CMD_START : Measure_NetDelay = true  ; break ;
         case CMD_STOP  : Measure_NetDelay = false ; break ;
         case CMD_RESET : NetDelay_Reset()         ; break ;
         case CMD_SHOW  : NetDelay_Show()          ; break ;
         default        :                            break ; /* Shouldn't happen */
      }
   }

   return (0) ;
}

/*******************************************************************************
* Routine  : NetDelay_Reset
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : NetDelay_Histogram
*
* This function clears out the NetDelay table.
*******************************************************************************/
static void NetDelay_Reset(void)
{
   memset(NetDelay_Histogram,0,sizeof(NetDelay_Histogram)) ;
}

/*******************************************************************************
* Routine  : NetDelay_Show
*   Inputs : None
*      IOs : None
*  Returns : Nothing
*  Globals : NetDelay_Histogram
*
* This function displays the histogram contents.
*******************************************************************************/
static void NetDelay_Show(void)
{
   int i   = 0 ; /* General counter                            */
   int max = 0 ; /* Max value in histogram table (for scaling) */

   /* Go find the max value */
   for (i=0;i<NETDELAY_ENTRIES;i++)
   {
      if (NetDelay_Histogram[i]>max) max = NetDelay_Histogram[i] ;
   }

   /* The fixed header info... */
   Console_printf("Audio Packet Network Delay Histogram\n") ;
   Console_printf("   ms     count graph\n") ;
   Console_printf("========= ===== ==================================================\n") ;

   /* For all but the last entry... */
   for (i=0;i<NETDELAY_ENTRIES-1;i++)
   {
      Console_printf("%4d-%4d %5d ",i*NETDELAY_BINSIZE,(i+1)*NETDELAY_BINSIZE-1,NetDelay_Histogram[i]) ;
      Histo_Graph(NetDelay_Histogram[i],max) ;
   }

   /* The last entry is the "everything greater" bin, so different formatting */
   Console_printf("    >%4d %5d ",NETDELAY_BINSIZE*(NETDELAY_ENTRIES-1),NetDelay_Histogram[NETDELAY_ENTRIES-1]) ;
   Histo_Graph(NetDelay_Histogram[i],max) ;
}

/*******************************************************************************
* Routine  : NetDelay_Log
*   Inputs : Pkt_TS - Packet time stamp (modulo 4s)
*      IOs : None
*  Returns : Nothing
*  Globals : NetDelay_Histogram, Measure_NetDelay
*
* This is the function called by the audio processing routines (uLaw and ADPCM)
* in DialTasks routines getting data from the DIAL server.  This routine gets
* the packets timestamp.  It is compared to the "right now" time to see how
* delayed from real time the packets timestamp is.  This is effectively the
* network round trip delay.  That information (if logging is enabled) is then
* logged in a histogram.
*******************************************************************************/
void NetDelay_Log(uint32_t Pkt_TS)
{
   uint32_t GPSNow_Sec = 0 ; /* Current GPS Time (seconds)   */
   uint32_t GPSNow_ns  = 0 ; /* Current GPS Time (ns)        */
   uint32_t GPSNow_TS  = 0 ; /* Current GPS Time (Timestamp) */
   uint32_t Delta_ns   = 0 ; /* Packet/GPS time delta        */
   int      bin        = 0 ; /* Histogram bin number         */

   /* Get the current GPS time and get the modulo 4s timestamp value */
   Get_GPSTimeNow(&GPSNow_Sec,&GPSNow_ns) ;
   GPSNow_TS = ((GPSNow_Sec%4)*1000000000+GPSNow_ns)%4000000000 ;

   /* Get the delta in ns */
   Delta_ns = GPSNow_TS-Pkt_TS ;

   if (Measure_NetDelay)
   {
      /* Convert to a bin number and take care of a bin number overflow */
      bin = (Delta_ns/1000000)/NETDELAY_BINSIZE ;
      if (bin>NETDELAY_ENTRIES-1) bin = NETDELAY_ENTRIES-1 ;

      /* Increment the bin unless any bin exceeds the max. */
      if (NetDelay_Histogram[bin]<50000)
      {
         NetDelay_Histogram[bin]++ ;
      }
      else
      {
         Measure_NetDelay = false ;
      }
   }
}
