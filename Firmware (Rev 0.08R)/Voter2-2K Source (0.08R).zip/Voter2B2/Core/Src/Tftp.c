/* ************************************************************************** */
/* VOTER2 Client System Firmware for VOTER2 series of boards                  */
/*                                                                            */
/* Copyright (C) 2026                                                         */
/* Will Beals N0XGA (willcfj@beals5.com)                                      */
/*                                                                            */
/* Based on the original VOTER firmware                                       */
/* Copyright (C) 2011-2015                                                    */
/* Jim Dixon, WB6NIL (SK) Also published under GPL2                           */
/*                                                                            */
/* This file is part of the VOTER2 System Project                             */
/*                                                                            */
/*   The VOTER2 System is free software: you can redistribute it and/or modify*/
/*   it under the terms of the GNU General Public License as published by     */
/*   the Free Software Foundation, either version 2 of the License, or        */
/*   (at your option) any later version.                                      */
/*                                                                            */
/*   Voter System is distributed in the hope that it will be useful,          */
/*   but WITHOUT ANY WARRANTY; without even the implied warranty of           */
/*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            */
/*   GNU General Public License for more details.                             */
/*                                                                            */
/*   You should have received a copy of the GNU General Public License        */
/*   along with this project.  If not, see <http://www.gnu.org/licenses/>.    */
/*                                                                            */
/******************************************************************************/
/* This is the TFTP file.  It is my implementation of a TFTP client using     */
/* LwIPs netconn API.                                                         */
/*  - Hooks, but no support for write requests yet.                           */
/*  - Hooks, but no support for octet (binary) mode yet.                      */
/*                                                                            */
/* This is my first real attempt at using a state context which in theory     */
/* could allow multiple sessions.  It seems pretty cool, but I'm probably not */
/* doing it quite right yet.                                                  */
/******************************************************************************/
/*                                                                            */
/* Public routines are:                                                       */
/*  - TFTP_Init - Initialize the TFTP port                                    */
/*                                                                            */
/*  - TFTP_SendRWRQ - Initiate a Read or Write Request                        */
/*  - TFTP_GetData  - Wait for a data packet (for read request)               */
/*  - TFTP_SendData - Send a data packet (for write request - later)          */
/*  - TFTP_SendAck  - Send Ack (for read request)                             */
/*                                                                            */
/*  - TFTP_SendError - Send an error packet to the server                     */
/*                                                                            */
/******************************************************************************/
// TO DO:

/******************************************************************************/
/* Includes                                                                   */
/******************************************************************************/
#include <string.h>

#include "lwip.h"
#include "lwip/api.h"

#include "Options.h"
#include "main.h"
#include "Logger2rt.h"
#include "Debugging.h"
#include "Settings.h"
#include "ConsoleTask.h"
#include "Tftp.h"

/******************************************************************************/
/* STM32 weird way of handling HW handles                                     */
/******************************************************************************/

/******************************************************************************/
/* Local defines                                                              */
/******************************************************************************/
#define TFTP_PORT 69 /* Starting port */
#define RRQPKTLEN (FNAMELEN+16)
#define ACKPKTLEN 4
#define ERRPKTLEN 32
#define TFTP_TIMEOUT 5000 /* Timeout in ms */
#define TFTP_RETRIES 5 /* Retries */

//#define TFTP2 /* For TFTP Phase 2 */

/******************************************************************************/
/* Structures/Definitions                                                     */
/******************************************************************************/

/******************************************************************************/
/* Global globals                                                             */
/******************************************************************************/
uint8_t TFTP_Buf[TFTP_BUFLEN] = {0} ; /* Shared buffer for all TFTP data ops  */

/******************************************************************************/
/* Local globals                                                              */
/******************************************************************************/

/******************************************************************************/
/* Local routine prototypes                                                   */
/******************************************************************************/
#ifdef TFTP2
static void my_netconn_callback(struct netconn *conn, enum netconn_evt evt, u16_t len) ;
#endif

static void SendTFTPPacket(TFTP_CONTEXT*,uint8_t*,uint32_t,uint16_t) ;

/******************************************************************************/
/* Local routines                                                             */
/******************************************************************************/

/*******************************************************************************
* Routine  : TFTP_Init
*   Inputs : Addr - TFTP Server IP address
*      IOs : Context - TFTP session context
*  Returns : Nothing
*  Globals : TBD
*
* This routine initializes the TFTP port.  Note that weirdly, this routine
* cannot fail!  For LwIPs UDP interface, there is no actual comms attempt on
* connecting, so "connecting" passes even if the server (or even Ethernet) is
* not connected!
*******************************************************************************/
void TFTP_Init(uint32_t Addr,TFTP_CONTEXT* Context)
{
   /* Get the IP address in the right format */
   IP_ADDR4(&(Context->TFTP_Server_IP),(Addr>>24) & 0xff,
                                       (Addr>>16) & 0xff,
                                       (Addr>> 8) & 0xff,
                                       (Addr    ) & 0xff) ;

#ifndef TFTP2
   /* Connect to the TFTP server using UDP.                                */
   /* Note that this doesn't actually establish or confirm a connection!   */
   /* It "connects" even if a server isn't there.  This is normal.         */
   Context->TFTPconn = netconn_new(NETCONN_UDP);
   Logger2_Msg(Logger.Tftp,LOG_SUPPORT,LOG_TIME,"TFTP: netconn_new (0x%8.8x)\r\n",(uint32_t)Context->TFTPconn) ;
   netconn_connect(Context->TFTPconn,&(Context->TFTP_Server_IP),TFTP_PORT);
   Logger2_Msg(Logger.Tftp,LOG_SUPPORT,LOG_TIME,"TFTP: netconn_connect (0x%8.8x)\r\n",(uint32_t)Context->TFTPconn) ;
#else
   /* "don't connect" attempt */
   Context->TFTPconn = netconn_new(NETCONN_UDP);
   Logger2_Msg(Logger.Tftp,LOG_SUPPORT,LOG_TIME,"TFTP: netconn_new (0x%8.8x)\r\n",(uint32_t)Context->TFTPconn) ;
   netconn_connect(Context->TFTPconn,&(Context->TFTP_Server_IP),0);
   Logger2_Msg(Logger.Tftp,LOG_SUPPORT,LOG_TIME,"TFTP: netconn_connect (0x%8.8x)\r\n",(uint32_t)Context->TFTPconn) ;
#if 0 /* Failed NETCONN_RAW attempt */

   Context->TFTPconn = netconn_new_with_callback(NETCONN_RAW, my_netconn_callback);
   netconn_bind(Context->TFTPconn, IP_ADDR_ANY,0) ; /* Manuel's AI-suggested adder  */
   Logger2_Msg(Logger.Tftp,LOG_SUPPORT,LOG_TIME,"TFTP: netconn_new (0x%8.8x)\r\n",(uint32_t)Context->TFTPconn) ;
   netconn_connect(Context->TFTPconn,&(Context->TFTP_Server_IP),TFTP_PORT);
   Logger2_Msg(Logger.Tftp,LOG_SUPPORT,LOG_TIME,"TFTP: netconn_connect (0x%8.8x)\r\n",(uint32_t)Context->TFTPconn) ;
#endif
#endif

   /* Finally, set the timeout period--important part of TFTP! */
   netconn_set_recvtimeout(Context->TFTPconn,TFTP_TIMEOUT) ;
}

#ifdef TFTP2
static void my_netconn_callback(struct netconn *conn, enum netconn_evt evt, u16_t len)
{
   switch (evt)
   {
      case NETCONN_EVT_RCVPLUS:
           Logger2_Msg(Logger.Tftp,LOG_SUPPORT,LOG_TIME,"TFTP: netconn RX+ Callback (%d)\r\n",len) ;
           break;
      case NETCONN_EVT_ERROR:
           // Error event
           // Handle errors
           break;
      // Other events can be handled as needed
      default:
           break;
   }
}
#endif

/*******************************************************************************
* Routine  : TFTP_SendRWRQ
*   Inputs : fname - file name to read
*          : dir - Direction, read or write
*          : fmode - file mode (ascii vs binary)
*      IOs : Context - TFTP session context
*  Returns : Nothing
*  Globals : None?
*
* This routine creates and sends the TFTP Read Request (RRQ) or Write Request
* (WRQ) packet to the TFTP server.
*******************************************************************************/
void TFTP_SendRWRQ(char* fname, int dir, int fmode, TFTP_CONTEXT* Context)
{
   uint8_t RWRQ_Packet[RRQPKTLEN] = {0} ; /* The assembled packet  */
   int     len1                   =  0  ; /* Packet length tracker */
   int     len2                   =  0  ; /* Packet length tracker */

   /* Build up the read request packet */
   RWRQ_Packet[0] = (dir>>8)&0xff ; /* Read Request Opcode (MSB) */
   RWRQ_Packet[1] = (dir   )&0xff ; /* Read Request Opcode (LSB) */
   strncpy((char*)RWRQ_Packet+2,fname,RRQPKTLEN-2) ;
   len1 = 3 + strlen(fname) ; /* Opcode + filename + eos */

   switch (fmode)
   {
      case TFTP_MODE_ASCII: strcat((char*)RWRQ_Packet+len1,"netascii") ; len2 = len1+9 ; break ;
      case TFTP_MODE_OCTET: strcat((char*)RWRQ_Packet+len1,"octet"   ) ; len2 = len1+6 ; break ;
      default             :                                                              break ;
   }

   Logger2_Msg(Logger.Tftp,LOG_REGIO,LOG_TIME,"TFTP: RRQ file '%s', mode %s\r\n",RWRQ_Packet+2,RWRQ_Packet+len1) ;

   /* Packet is ready, send it to the well known TFTP port! */
   SendTFTPPacket(Context,RWRQ_Packet,len2,TFTP_PORT) ;

   /* Expecting Block #1 as the reply if a Read request, 0 if a write request */
   /* I pre-increment read block numbers, so the initial block number here is */
   /* zero either way.                                                        */
   Context->Block = 0 ;
}

/*******************************************************************************
* Routine  : TFTP_GetData
*   Inputs : None
*      IOs : Context - TFTP session context
*  Returns : Byte count
*  Globals : TFTP_Buf - Data returned.
*
* This routine gets (well, waits for) a data packet from the TFTP server.
* Results can be data (yay for reads!), ACK (yay for writes), an error packet,
* or timeout. If an error, the "payload" is the optional error message.
*
* IMPORTANT: Data in TFTP_Buf is the whole packet including TFTP headers!
*            The actual payload starts at the fifth byte.
*
* TO DO STILL: Block ID tracking (I just log it now)
*******************************************************************************/
int TFTP_GetData(TFTP_CONTEXT* Context)
{
   err_t         err       = 0    ; /* Result code                  */
   int           RxBytes   = 0    ; /* Received bytes               */
   uint16_t      delta     = 0    ; /* Incremental length value     */
   uint16_t      len       = 0    ; /* Intermediate length value    */
   struct netbuf *buf      = NULL ; /* Buffer for incoming TCP data */
   uint16_t      BlockID   = 0    ; /* TFTP packet Block ID         */
 //uint16_t      NewPort   = 0    ; /* New Port number              */
 //ip_addr_t     NewAddr   = {0}  ; /* New (??) Remote IP addr      */
   void         *Packet_data = NULL  ; /* Telnet data to Console    */

#ifndef TFTP2
   /* TEMPORARY CHEAT!!!  I fix the TFTP server's reply port to 30,000 */
   Context->TFTPconn->pcb.udp->remote_port=30000 ;
#else

#endif

   /* Wait for some data (or a timeout) */
   err = netconn_recv(Context->TFTPconn, &buf) ;
   if (ERR_OK!=err)
   {
      IncErrLog(ERRLOG_TFTP_GETDATA_NETCONN_RECV,ERRLOG_SHOW) ;
      Context->Error=TFTPERR_TIMEOUT ;
      Context->TFTP_Error = err ;
      Logger2_Msg(Logger.Tftp,LOG_MAJOR,LOG_TIME,"TFTP: UDP Error %d (%d bytes)\r\n",err,RxBytes) ;
   }
   else
   {
      RxBytes = buf->p->len ;
   }

   /* If no error, that means we got data! */
   if (ERR_OK==err)
   {
      /* Quick sanity check on the packet length (including header) */
      if ((RxBytes<4) || (RxBytes>516))
      {
         Context->Error = TFTPERR_BADLEN ;
      }
      else
      {
         /* Not sure this is needed given the max packet size is 516 bytes,   */
         /* but an Ethernet frame can span multiple LwIP pbufs, so assemble   */
         /* them into the TFTP_Buf if that happens.                           */
         do
         {
            /* get the payload and plunk it into the common buffer */
            netbuf_data(buf,&Packet_data, &delta);
            memcpy(TFTP_Buf+len,Packet_data,delta) ;
            len += delta ;
         } while (netbuf_next(buf) >= 0);

         BlockID = (TFTP_Buf[2]<<8) + TFTP_Buf[3] ;
         Logger2_Msg(Logger.Tftp,LOG_REGIO,LOG_TIME,"TFTP: UDP Response %d bytes, block %d (%d)\r\n",RxBytes,BlockID,err) ;

         /* OK, we have the data, let's see what we got.  The first two bytes */
         /* are the Opcode.  Only legit opcodes are data, ack, or error.      */
         Context->Opcode = TFTP_Buf[0]*256 + TFTP_Buf[1] ;

         if (TFTP_OPCODE_DATA==Context->Opcode) /* Data */
         {
            /* If it's the first block coming back after a read request, that */
            /* is the destination TID for the file transfer, save it.         */
            /* If not the first, it had better be the same as the first!      */
            if (0x0001==BlockID)
            {
               Context->SrcTID = buf->port ;
            }
            else if (buf->port!=Context->SrcTID)
            {
               Context->Error = TFTPERR_BADTID ;
               RxBytes = 0 ;
            }

#if 0 /* This is the old pre-checking Block numbers code */
            RxBytes -= 4 ; /* Data bytes are total bytes minus header */
            Context->Block = BlockID ; /*Save for next time */
#else
            /* Time to do some block number checking */
            if (BlockID == Context->Block+1) /* The happy path */
            {
               Context->Block = BlockID ; /*Save for next time */
               RxBytes -= 4 ; /* Data bytes are total bytes minus header */
            }
            else if (BlockID == Context->Block) /* A repeat packet */
            {
               RxBytes = TFTP_DUP ; /* Flag as a duplicate packet */
               IncErrLog(ERRLOG_TFTP_DUPLICATE_BLOCKNUM,ERRLOG_SHOW) ;
            }
            else /* anything else is very bad */
            {
               Context->Error = TFTPERR_BADBLOCK ;
               RxBytes = 0 ;
            }
#endif
         }

         else if (TFTP_OPCODE_ACK==Context->Opcode) /* ACK */
         {
            /* An ACK packet better be exactly 4 bytes of payload */
            if (RxBytes!=4)
            {
               Context->Error = TFTPERR_BADLEN ;
            }
            else
            {
               /* If it's the first block coming back after a write request,  */
               /* that is the destination TID for the file transfer, save it. */
               /* If not the first, it had better be the same as the first!   */
               if (0x0000==BlockID)
               {
                  Context->SrcTID = buf->port ;
               }
               else if (buf->port!=Context->SrcTID)
               {
                  Context->Error = TFTPERR_BADTID ;
               }


               /* Do Block ID error checking here later         */
               Context->Block = BlockID ; /* Save for next time */
               RxBytes        = 0       ; /* No data            */
            }
         }

         else if (TFTP_OPCODE_ERR==Context->Opcode) /* Error */
         {
            /* If an error packet, set the error flags and leave the error    */
            /* text (if any) in the data field.                               */
            Context->Error = TFTPERR_TFTPCODE ;
            Context->TFTP_Error = (TFTP_Buf[2]<<8) + TFTP_Buf[3] ;
            RxBytes -= 4 ; /* Data bytes are total bytes minus header */
         }

         /* If anything else, something very weird happened!  Just call it a  */
         /* bad header since nothing was recognized.                          */
         else
         {
            Context->Error = TFTPERR_BADHDR ;
         }
      } /* Rational packet size */
   } /* Got data */
#if 0
   else if (ERR_TIMEOUT==err)
   {
      /* If the first packet back, I need to rejigger the server port number  */
      if (1==Context->Block)
      {
         memcpy(&NewAddr,netbuf_fromaddr(buf),sizeof(ip_addr_t)) ;
         NewPort = netbuf_fromport(buf);

         /* Connect to the server's transfer port (which is different from 69)*/
         netconn_disconnect(Context->TFTPconn);
         err = netconn_connect(Context->TFTPconn,&NewAddr,NewPort);
         Logger2_Msg(Logger.Tftp,LOG_REGIO,LOG_TIME,"TFTP: Reconnecting to TFTP server port %d (%d)\r\n",NewPort,err) ;
      }
      Context->Error = TFTPERR_TIMEOUT ;
   }
#endif

   /* If we got a netbuf, free it, and finally return the byte count. */
   if (buf) netbuf_delete(buf) ;
   return (RxBytes) ;
}

/*******************************************************************************
* Routine  : TFTP_SendAck
*   Inputs : None
*      IOs : Context - TFTP session context
*  Returns : Nothing
*  Globals : None.
*
* This routine sends an ACK packet.  Pretty simple, the Block ID got stored in
* the context, so just ack that block number to the source TID (port).
*******************************************************************************/
void TFTP_SendAck(TFTP_CONTEXT* Context)
{
   uint8_t ACK_Packet[ACKPKTLEN] = {0} ; /* The assembled packet  */

   /* Build up the Ack packet */
   ACK_Packet[0] = 0x00                       ; /* Ack Opcode (MSB)  */
   ACK_Packet[1] = 0x04                       ; /* Ack Opcode (LSB)  */
   ACK_Packet[2] = ((Context->Block)>>8)&0xff ; /* Ack Block # (MSB) */
   ACK_Packet[3] = ( Context->Block    )&0xff ; /* Ack Block # (LSB) */

   /* Packet is ready, send it to the TFTP data port! */
   SendTFTPPacket(Context,ACK_Packet,ACKPKTLEN,Context->SrcTID) ;
}

/*******************************************************************************
* Routine  : TFTP_SendData
*   Inputs : len - Bytes to send
*      IOs : Context - TFTP session context
*  Returns : Nothing
*  Globals : None.
*
* This routine sends a packet of data.  The calling routine should put payload
* data starting at the 5th byte! Use the TFTP_PAYLOAD #define for this.  This
* routine takes care of the block number and  fills out the header before
* sending the data on.  Note that a length of anything less than 512 bytes means
* the end of sending data.
*******************************************************************************/
void TFTP_SendData(TFTP_CONTEXT* Context, int len)
{
   /* Increment the block number */
   Context->Block = Context->Block + 1 ;

   /* Fill in the header (payload already set) */
   TFTP_Buf[0] = 0x00                       ; /* Data Opcode (MSB) */
   TFTP_Buf[1] = 0x03                       ; /* Data Opcode (LSB) */
   TFTP_Buf[2] = ((Context->Block)>>8)&0xff ; /* Block # (MSB)     */
   TFTP_Buf[3] = ( Context->Block    )&0xff ; /* Block # (LSB)     */

   /* Packet is ready, send it to the TFTP data port! */
   SendTFTPPacket(Context,TFTP_Buf,len+4,Context->SrcTID) ;
}

/*******************************************************************************
* Routine  : TFTP_SendErr
*   Inputs : None
*      IOs : Context - TFTP session context
*  Returns : Nothing
*  Globals : None.
*
* This routine sends an Error packet.  Whatever error is already in the Context
* state.  Main tricky bit is mapping my internal errors to TFTP error numbers
* where I can.  Where I can't I just report Error #0 and hope the error text
* gets reported on the other side.
*******************************************************************************/
void TFTP_SendErr(TFTP_CONTEXT* Context)
{
   uint8_t ERR_Packet[ERRPKTLEN] = {0} ; /* The assembled packet  */
   int     len                   =  0  ; /* String length         */

   /* Build up the Ack packet */
   ERR_Packet[0] = 0x00 ; /* Error Opcode (MSB)  */
   ERR_Packet[1] = 0x05 ; /* Error Opcode (LSB)  */
   ERR_Packet[2] = 0x00 ; /* Error code   (MSB)  */

   /* Map my internal error codes to TFTP error codes and add text.           */
   /* TRFT_ERRNONE and TFTP_TFTPCODE don't map, so get default treatment.    */
   switch (Context->Error)
   {
      case TFTPERR_TIMEOUT : ERR_Packet[3] = 0x00 ; strcat((char*)ERR_Packet+4,"Timeout")           ; break ;
      case TFTPERR_BADTID  : ERR_Packet[3] = 0x05 ; strcat((char*)ERR_Packet+4,"TID Error")         ; break ;
      case TFTPERR_BADHDR  : ERR_Packet[3] = 0x04 ; strcat((char*)ERR_Packet+4,"Bad header")        ; break ;
      case TFTPERR_BADLEN  : ERR_Packet[3] = 0x04 ; strcat((char*)ERR_Packet+4,"Bad Packet Length") ; break ;
      case TFTPERR_BADSREC : ERR_Packet[3] = 0x00 ; strcat((char*)ERR_Packet+4,"Bad S-Record")      ; break ;
      default              : ERR_Packet[3] = 0x00 ; strcat((char*)ERR_Packet+4,"Unexpected Error")  ; break ;
   }

   /* The message length is the four header bytes plus the error message plus */
   /* the EOS at the end                                                      */
   len = 5 + strlen((char*)ERR_Packet+4) ;

   /* Packet is ready, send it to the TFTP data port! */
   SendTFTPPacket(Context,ERR_Packet,len,Context->SrcTID) ;
}

/*******************************************************************************
* Routine  : TFTP_Terminate
*   Inputs : None
*      IOs : Context - TFTP session context
*  Returns : Nothing
*  Globals :
*
* This closes the TFTP connection.  I go ahead and clear out the context too.
*******************************************************************************/
void TFTP_Terminate(TFTP_CONTEXT* Context)
{
   /* If a connection existed, delete it */
   if (Context->TFTPconn) netconn_delete(Context->TFTPconn) ;

   /* and clear out the old context */
   memset(Context,0,sizeof(TFTP_CONTEXT)) ;
}

/*******************************************************************************
* Routine  : SendTFTPPacket
*   Inputs : packet - data to send
*          : len - number of bytes to send
*          : SrvrTID - TID (UDP Port) to send to
*      IOs : None
*  Returns : Nothing
*  Globals : TFTP_Server_IP, TFTP_conn
*
* This is the routine to actually send the UDP packet to the server.
*******************************************************************************/
static void SendTFTPPacket(TFTP_CONTEXT* Context,uint8_t* packet, uint32_t len,uint16_t SrvrTID)
{
   struct netbuf *tx_buf = NULL    ; /* Tx packet buffer handle    */
   err_t err = 0 ;
   uint16_t      BlockID   = 0    ; /* TFTP packet Block ID         */

   tx_buf = netbuf_new();
   if (NULL==tx_buf)
   {
      IncErrLog(ERRLOG_SENDTFTPPACKET_NETBUF_NEW,ERRLOG_SHOW) ;
   }
   else
   {
      netbuf_alloc(tx_buf,len);
      if (NULL==tx_buf)
      {
         IncErrLog(ERRLOG_SENDTFTPPACKET_NETBUF_ALLOC,ERRLOG_SHOW) ;
      }
      else
      {
         err=pbuf_take(tx_buf->p, (const void *)packet,len);
         if (ERR_OK!=err)
         {
            IncErrLog(ERRLOG_SENDTFTPPACKET_PBUF_TAKE,ERRLOG_SHOW) ;
         }
         else
         {
            err = netconn_sendto(Context->TFTPconn,tx_buf,&(Context->TFTP_Server_IP),SrvrTID);
            if (ERR_OK!=err)
            {
               IncErrLog(ERRLOG_SENDTFTPPACKET_NETCONN_SENDTO,ERRLOG_SHOW) ;
            }
         }
      }
      /* Even if errors after netbuf_new, always delete the netbuf */
      netbuf_delete(tx_buf);
   }

   BlockID = (packet[2]<<8) + packet[3] ;
   Logger2_Msg(Logger.Tftp,LOG_REGIO,LOG_TIME,"TFTP: Sent UDP block %d,len %d (%d)\r\n",BlockID,len,err) ;
}

/*******************************************************************************
* Routine  : Show_TFTP_Err
*   Inputs : Context
*      IOs : None
*  Returns : Nothing
*  Globals : TBD
*
* If there is any kind of error condition, it is printed out in text.  This
* includes both my errors as well as TFTP protocol error messages.
*******************************************************************************/
void Show_TFTP_Err(TFTP_CONTEXT* Context)
{
   if ((Context->Error)||(Context->TFTP_Error))
   {
      switch (Context->Error)
      {
         case TFTPERR_TFTPCODE : Console_printf("TFTP error (%d.%d) Server Error %s.\n"  ,Context->Error,Context->TFTP_Error,TFTP_Buf+4) ; break ;
         case TFTPERR_TIMEOUT  : Console_printf("TFTP error (%d.%d) Timeout.\n"          ,Context->Error,Context->TFTP_Error) ; break ;
         case TFTPERR_BADTID   : Console_printf("TFTP error (%d.%d) TID Error.\n"        ,Context->Error,Context->TFTP_Error) ; break ;
         case TFTPERR_BADHDR   : Console_printf("TFTP error (%d.%d) Bad header.\n"       ,Context->Error,Context->TFTP_Error) ; break ;
         case TFTPERR_BADLEN   : Console_printf("TFTP error (%d.%d) Bad Packet Length.\n",Context->Error,Context->TFTP_Error) ; break ;
         case TFTPERR_BADBLOCK : Console_printf("TFTP error (%d.%d) Bad Block number.\n" ,Context->Error,Context->TFTP_Error) ; break ;
         case TFTPERR_BADSREC  : Console_printf("TFTP error (%d.%d) Bad SREC format.\n"  ,Context->Error,Context->TFTP_Error) ; break ;
         case TFTPERR_BADADDR  : Console_printf("TFTP error (%d.%d) Bad SREC Address.\n" ,Context->Error,Context->TFTP_Error) ; break ;
         default               : Console_printf("TFTP error (%d.%d) Unexpected Error.\n" ,Context->Error,Context->TFTP_Error) ; break ;
      }
   }
}
